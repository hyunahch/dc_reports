const NAVIGATION_SELECTOR = [
  '[data-shell-tab]',
  '#mobileFlowModeSwitch button',
  '#appFlowModeSwitch button',
  '[data-first-guide]',
  '#mobileScenarioBack',
  '#scenarioBack',
  '.scenarioBack',
  '.back',
].join(',');

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[char]));
}

function youtubeIdFromIframe(iframe) {
  const src = String(iframe?.getAttribute('src') || '');
  const match = src.match(/youtube(?:-nocookie)?\.com\/embed\/([^?&#/]+)/i);
  return match?.[1] || '';
}

function restoreMedia(media) {
  if (!media) return false;
  const iframe = media.querySelector('iframe');
  if (!iframe) return false;

  const card = media.closest('[data-beginner-video-card]');
  const itemId = String(card?.dataset.beginnerVideoCard || '');
  const youtubeId = youtubeIdFromIframe(iframe);
  if (!itemId || !youtubeId) {
    iframe.remove();
    return true;
  }

  const fallbackTitle = card?.querySelector('h4')?.textContent?.trim() || 'YouTube 영상';
  const title = String(iframe.title || fallbackTitle).replace(/\s*YouTube 영상\s*$/, '') || fallbackTitle;
  media.innerHTML = `
    <img src="https://i.ytimg.com/vi/${escapeHtml(youtubeId)}/hqdefault.jpg" alt="${escapeHtml(title)} YouTube 썸네일" loading="lazy" decoding="async">
    <button class="beginnerVideoPlay" type="button" data-beginner-video-play="${escapeHtml(itemId)}">인앱에서 보기</button>`;
  return true;
}

function stopAllVideos() {
  let stopped = 0;
  document.querySelectorAll('[data-beginner-video-media]').forEach(media => {
    if (restoreMedia(media)) stopped += 1;
  });
  return stopped;
}

function stopInvisibleVideos() {
  let stopped = 0;
  document.querySelectorAll('[data-beginner-video-media]').forEach(media => {
    if (!media.querySelector('iframe')) return;
    if (!media.isConnected || media.getClientRects().length === 0) {
      if (restoreMedia(media)) stopped += 1;
    }
  });
  return stopped;
}

let queuedVisibilityCheck = false;
function queueVisibilityCheck() {
  if (queuedVisibilityCheck) return;
  queuedVisibilityCheck = true;
  requestAnimationFrame(() => {
    queuedVisibilityCheck = false;
    stopInvisibleVideos();
  });
}

document.addEventListener('click', event => {
  const target = event.target;
  if (target?.closest?.(NAVIGATION_SELECTOR)) stopAllVideos();
}, true);

window.addEventListener('popstate', stopAllVideos);
window.addEventListener('hashchange', stopAllVideos);
window.addEventListener('pagehide', stopAllVideos);
document.addEventListener('visibilitychange', () => {
  if (document.hidden) stopAllVideos();
});

const observer = new MutationObserver(queueVisibilityCheck);
observer.observe(document.documentElement, {
  childList: true,
  subtree: true,
  attributes: true,
  attributeFilter: ['class', 'style', 'hidden'],
});

globalThis.__BJJ_BEGINNER_VIDEO_LIFECYCLE__ = {
  version: 'v0.1',
  stopAllVideos,
  stopInvisibleVideos,
  activeCount: () => document.querySelectorAll('[data-beginner-video-media] iframe').length,
};
