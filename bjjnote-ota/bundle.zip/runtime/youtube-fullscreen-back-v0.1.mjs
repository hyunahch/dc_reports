const YOUTUBE_IFRAME_SELECTOR = [
  'iframe.youtubeFrame',
  'iframe[src*="youtube.com/embed/"]',
  'iframe[src*="youtube-nocookie.com/embed/"]',
].join(',');

let lastFullscreenIframe = null;
let pauseCount = 0;

function fullscreenElement() {
  return document.fullscreenElement || document.webkitFullscreenElement || null;
}

function isYouTubeIframe(iframe) {
  if (!iframe || iframe.tagName !== 'IFRAME') return false;
  const src = String(iframe.getAttribute('src') || '');
  return /youtube(?:-nocookie)?\.com\/embed\//i.test(src);
}

function normalizeIframe(iframe) {
  if (!isYouTubeIframe(iframe)) return false;
  let url;
  try {
    url = new URL(iframe.getAttribute('src') || '', location.href);
  } catch {
    return false;
  }

  let changed = false;
  if (url.searchParams.get('enablejsapi') !== '1') {
    url.searchParams.set('enablejsapi', '1');
    changed = true;
  }
  if ((location.protocol === 'http:' || location.protocol === 'https:') && !url.searchParams.get('origin')) {
    url.searchParams.set('origin', location.origin);
    changed = true;
  }
  if (changed) iframe.src = url.toString();
  iframe.dataset.bjjYoutubeJsapi = '1';
  return true;
}

function normalizeAll(root = document) {
  if (root?.matches?.(YOUTUBE_IFRAME_SELECTOR)) normalizeIframe(root);
  root?.querySelectorAll?.(YOUTUBE_IFRAME_SELECTOR).forEach(normalizeIframe);
}

function pauseYouTubeIframe(iframe) {
  if (!isYouTubeIframe(iframe) || !iframe.contentWindow) return false;
  let targetOrigin = '*';
  try {
    targetOrigin = new URL(iframe.getAttribute('src') || '', location.href).origin;
  } catch {}
  try {
    iframe.contentWindow.postMessage(
      JSON.stringify({ event: 'command', func: 'pauseVideo', args: [] }),
      targetOrigin,
    );
    pauseCount += 1;
    return true;
  } catch {
    return false;
  }
}

function fullscreenYouTubeIframe() {
  const current = fullscreenElement();
  if (!current) return null;
  if (isYouTubeIframe(current)) return current;
  const nested = current.querySelector?.(YOUTUBE_IFRAME_SELECTOR);
  if (nested) return nested;
  if (lastFullscreenIframe?.isConnected) return lastFullscreenIframe;
  return null;
}

function activeYouTubeIframe() {
  return fullscreenYouTubeIframe()
    || (lastFullscreenIframe?.isConnected ? lastFullscreenIframe : null)
    || document.querySelector('#detail.active iframe.youtubeFrame')
    || document.querySelector(YOUTUBE_IFRAME_SELECTOR)
    || null;
}

function pauseActivePlayer() {
  const iframe = activeYouTubeIframe();
  return iframe ? pauseYouTubeIframe(iframe) : false;
}

function exitFullscreen() {
  const exit = document.exitFullscreen || document.webkitExitFullscreen || document.webkitCancelFullScreen;
  if (typeof exit !== 'function') return false;
  try {
    const result = exit.call(document);
    result?.catch?.(() => {});
    return true;
  } catch {
    return false;
  }
}

function handleBackFromFullscreen() {
  if (!fullscreenElement()) return false;
  pauseActivePlayer();
  exitFullscreen();
  return true;
}

function rememberFullscreenIframe() {
  const current = fullscreenElement();
  if (!current) return;
  if (isYouTubeIframe(current)) {
    lastFullscreenIframe = current;
    return;
  }
  const nested = current.querySelector?.(YOUTUBE_IFRAME_SELECTOR);
  if (nested) lastFullscreenIframe = nested;
}

document.addEventListener('fullscreenchange', rememberFullscreenIframe);
document.addEventListener('webkitfullscreenchange', rememberFullscreenIframe);

const observer = new MutationObserver(records => {
  for (const record of records) {
    if (record.type === 'attributes') {
      normalizeIframe(record.target);
      continue;
    }
    record.addedNodes.forEach(node => {
      if (node.nodeType === Node.ELEMENT_NODE) normalizeAll(node);
    });
  }
});
observer.observe(document.documentElement, {
  childList: true,
  subtree: true,
  attributes: true,
  attributeFilter: ['src'],
});
normalizeAll();

globalThis.__BJJ_YOUTUBE_FULLSCREEN_BACK__ = {
  version: 'v0.2',
  handleBack: handleBackFromFullscreen,
  pauseActive: pauseActivePlayer,
  normalizeAll,
  pauseYouTubeIframe,
  get pauseCount() { return pauseCount; },
};
