import { buildAllLearningFlows } from './learning-flow-v0.1.mjs';
import { COMPETITION_SCENARIOS } from './competition-scenarios-v0.1.mjs';
import { getCompetitionFinishPlan } from './competition-finish-plans-v0.1.mjs';

function findBottomButton(label) {
  return [...document.querySelectorAll('.bottom button')].find(button => button.textContent.trim() === label) || null;
}

function setBottomActive(activeButton) {
  document.querySelectorAll('.bottom button').forEach(button => button.classList.toggle('active', button === activeButton));
}

function activatePanel(panel) {
  document.querySelectorAll('.panel').forEach(item => item.classList.remove('active'));
  panel.classList.add('active');
}

function ensureFlowPanel() {
  let panel = document.getElementById('flowAppPanel');
  if (panel) return panel;
  panel = document.createElement('section');
  panel.id = 'flowAppPanel';
  panel.className = 'panel';
  document.querySelector('main')?.appendChild(panel);
  return panel;
}

function install() {
  const recovery = globalThis.__recovery;
  const flowButton = findBottomButton('흐름');
  const techniqueButton = findBottomButton('기술');
  const indexPanel = document.getElementById('index');
  if (!recovery || !flowButton || !techniqueButton || !indexPanel) return false;

  const panel = ensureFlowPanel();
  const flows = buildAllLearningFlows(recovery.TECHNIQUES);
  let activeFlowIndex = 0;
  let flowMode = 'learning';
  let activeScenarioId = null;

  function techniqueName(flow, techniqueId) {
    return flow.nodes.find(node => node.techniqueId === techniqueId)?.nameKo || techniqueId;
  }

  function restoreFlowBackButton() {
    const back = document.querySelector('#detailRoot .back');
    if (!back) return;
    back.textContent = '← 흐름';
    back.onclick = event => {
      event.preventDefault();
      showFlow();
    };
  }

  function openTechniqueFromFlow(button) {
    recovery.openTechnique({
      techniqueId: button.dataset.tech,
      selectedEntryRouteId: button.dataset.route || null,
    });
    setBottomActive(flowButton);
    restoreFlowBackButton();
    window.scrollTo(0, 0);
  }

  function modeSwitch() {
    return `
      <div class="catalogSwitch" id="appFlowModeSwitch">
        <button class="${flowMode === 'learning' ? 'active' : ''}" data-flow-mode="learning">기술 흐름</button>
        <button class="${flowMode === 'competition' ? 'active' : ''}" data-flow-mode="competition">시합 시나리오</button>
      </div>`;
  }

  function renderLearningFlow() {
    const flow = flows[activeFlowIndex];
    return `
      <div class="hint">상대 반응 → 내 대응 → 다음 기술을 같은 canonical 데이터에서 연결</div>
      <div class="chips" id="appFlowPicker">
        ${flows.map((item, index) => `<button class="${index === activeFlowIndex ? 'active' : ''}" data-flow="${index}">${item.title}</button>`).join('')}
      </div>
      <div class="context"><b>${flow.title}</b><br>${flow.description}</div>
      <div class="section">
        <h2>기술 연결</h2>
        <div class="chips" id="appFlowNodes">
          ${flow.nodes.map(node => `<button data-tech="${node.techniqueId}" data-route="${node.selectedEntryRouteId}">${node.nameKo}</button>`).join('')}
        </div>
      </div>
      <div class="section">
        <h2>상대 반응별 선택</h2>
        <div class="list" id="appFlowEdges">
          ${flow.edges.map(edge => `
            <div class="card flowEdge" data-from="${edge.fromTechniqueId}">
              <b>${techniqueName(flow, edge.fromTechniqueId)} · ${edge.opponentReaction}</b>
              <small>${edge.responseSummary}</small>
              <div class="meta">
                <span class="mini">${edge.scope === 'core' ? 'Core 반응' : 'Entry 반응'}</span>
                ${edge.toTechniqueId ? `<button class="mini flowNext" data-tech="${edge.toTechniqueId}" data-route="${edge.toEntryRouteId || ''}">→ ${techniqueName(flow, edge.toTechniqueId)}</button>` : edge.outcomePositionId ? `<span class="mini">→ ${edge.outcomePositionId}</span>` : '<span class="mini">→ 현재 컨트롤 유지 / 재선택</span>'}
              </div>
            </div>`).join('')}
        </div>
      </div>`;
  }

  function scenarioStatusLabel(status) {
    if (status === 'planned') return '다음 시나리오 예정';
    if (status === 'loop') return '같은 단계 반복';
    if (status === 'candidate') return '공격 선택';
    if (status === 'scenario') return '시나리오 이동';
    if (status === 'outcome') return '포지션 전환';
    return status || '';
  }

  function renderScenarioIndex() {
    return `
      <div class="hint">상황 → 상대 행동 → 내 판단 → 다음 포지션으로 이어지는 개인 경기 운영 지도</div>
      <div class="context"><b>내 시합 플랜</b><br>빠른 선공 경쟁보다 안정 → 제거 → 공격 순서로 판단 시간을 줄이는 A-Game을 만든다.</div>
      <div class="section">
        <h2>경기 시작</h2>
        <div class="list" id="appScenarioList">
          ${COMPETITION_SCENARIOS.map(scenario => `
            <button class="card scenarioCard" data-scenario="${scenario.id}">
              <b>${scenario.shortTitle || scenario.title}</b>
              <small>${scenario.summary}</small>
              <div class="meta"><span class="mini">${scenario.phaseLabel}</span><span class="mini">${scenario.badge}</span></div>
            </button>`).join('')}
        </div>
      </div>`;
  }

  function renderFinishPlan(finish) {
    if (!finish) return '';
    return `
      <div class="section" id="appScenarioFinish" data-finish="${finish.id}">
        <h2>주력 싱글렉 마무리</h2>
        <div class="drillHero">
          <div class="label">${finish.badge}</div>
          <p><b>${finish.title}</b><br>${finish.entryCondition}</p>
          <p>${finish.summary}</p>
        </div>
        <div style="margin-top:12px"><iframe data-finish-video="${finish.video.youtubeId}" src="${finish.video.embedUrl}?playsinline=1&rel=0" title="${finish.video.title}" style="width:100%;aspect-ratio:16/9;border:0;border-radius:14px" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></div>
        <div class="points"><ul>${finish.cues.map(item => `<li>${item}</li>`).join('')}</ul></div>
        <div class="steps" id="appFinishSteps">
          ${finish.steps.map((step, index) => `
            <div class="step scenarioStep" data-finish-step="${step.id}">
              <div class="num">${index + 1}</div>
              <div><b>${step.title}</b><p>${step.instruction}</p></div>
            </div>`).join('')}
        </div>
        <div class="points"><b>안전</b><br>${finish.safety}</div>
      </div>`;
  }

  function renderScenarioDetail(scenario) {
    const finish = getCompetitionFinishPlan(scenario.id);
    return `
      <button class="back" id="scenarioBack">← 시합 시나리오</button>
      <div class="context"><b>${scenario.phaseLabel}</b> · ${scenario.badge}<br>${scenario.goal}</div>
      <h1 class="title">${scenario.title}</h1>
      <div class="sub">상대 선공을 받아낸 뒤 내가 두 번째 교환부터 주도하는 반응형 루트</div>
      <div class="drillHero">
        <div class="label">성공 기준</div>
        <p>${scenario.successCriteria}</p>
      </div>
      <div class="section">
        <h2>기본 원칙</h2>
        <div class="points"><ul>${scenario.principles.map(item => `<li>${item}</li>`).join('')}</ul></div>
      </div>
      <div class="section">
        <h2>진행 순서</h2>
        <div class="steps" id="appScenarioSteps">
          ${scenario.steps.map((step, index) => `
            <div class="step scenarioStep" data-step="${step.id}">
              <div class="num">${index + 1}</div>
              <div><b>${step.title}</b><p>${step.instruction}</p><small>${step.cue}</small></div>
            </div>`).join('')}
        </div>
      </div>
      ${renderFinishPlan(finish)}
      <div class="section">
        <h2>상대 반응별 선택</h2>
        <div class="branches" id="appScenarioBranches">
          ${scenario.branches.map(branch => `
            <div class="branch scenarioBranch" data-branch="${branch.id}">
              <small>상대가 이렇게 하면</small>
              <b>${branch.when}</b>
              <p>${branch.response}</p>
              <div class="meta">${branch.nextScenarioId ? `<button class="mini scenarioNext" data-next-scenario="${branch.nextScenarioId}">→ ${branch.next}</button>` : `<span class="mini">→ ${branch.next}</span>`}<span class="mini">${scenarioStatusLabel(branch.nextStatus)}</span></div>
            </div>`).join('')}
        </div>
      </div>
      <div class="section">
        <h2>피할 것</h2>
        <div class="points"><ul>${scenario.commonMistakes.map(item => `<li>${item}</li>`).join('')}</ul></div>
      </div>`;
  }

  function render() {
    const scenario = activeScenarioId ? COMPETITION_SCENARIOS.find(item => item.id === activeScenarioId) : null;
    panel.innerHTML = `
      <h2>흐름</h2>
      ${modeSwitch()}
      ${flowMode === 'competition' ? (scenario ? renderScenarioDetail(scenario) : renderScenarioIndex()) : renderLearningFlow()}`;

    panel.querySelectorAll('#appFlowModeSwitch button').forEach(button => {
      button.onclick = () => {
        flowMode = button.dataset.flowMode;
        activeScenarioId = null;
        render();
        window.scrollTo(0, 0);
      };
    });

    if (flowMode === 'learning') {
      panel.querySelectorAll('#appFlowPicker button').forEach(button => {
        button.onclick = () => {
          activeFlowIndex = Number(button.dataset.flow);
          render();
        };
      });
      panel.querySelectorAll('#appFlowNodes button, .flowNext').forEach(button => {
        button.onclick = () => openTechniqueFromFlow(button);
      });
      return;
    }

    panel.querySelectorAll('.scenarioCard').forEach(button => {
      button.onclick = () => {
        activeScenarioId = button.dataset.scenario;
        render();
        window.scrollTo(0, 0);
      };
    });
    panel.querySelectorAll('.scenarioNext').forEach(button => {
      button.onclick = () => {
        activeScenarioId = button.dataset.nextScenario;
        render();
        window.scrollTo(0, 0);
      };
    });
    const scenarioBack = panel.querySelector('#scenarioBack');
    if (scenarioBack) {
      scenarioBack.onclick = () => {
        activeScenarioId = null;
        render();
        window.scrollTo(0, 0);
      };
    }
  }

  function showFlow() {
    activatePanel(panel);
    setBottomActive(flowButton);
    render();
    window.scrollTo(0, 0);
  }

  flowButton.onclick = showFlow;
  techniqueButton.onclick = () => {
    activatePanel(indexPanel);
    setBottomActive(techniqueButton);
    globalThis.setCatalog?.('techniques');
    window.scrollTo(0, 0);
  };

  globalThis.__recoveryFlow = {
    flows,
    scenarios: COMPETITION_SCENARIOS,
    showFlow,
    render,
    showCompetitionScenarios() {
      flowMode = 'competition';
      activeScenarioId = null;
      showFlow();
    },
  };
  return true;
}

if (typeof document !== 'undefined') {
  let attempts = 0;
  const timer = setInterval(() => {
    attempts += 1;
    if (install() || attempts >= 100) clearInterval(timer);
  }, 25);
}
