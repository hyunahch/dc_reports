import { loadTechniqueRecords } from './canonical-data-loader.mjs';
import { loadSoloDrills } from './drill-data-loader.mjs';
import { FLOW_DEFINITIONS, buildAllLearningFlows } from './learning-flow-v0.1.mjs';
import { COMPETITION_SCENARIOS } from './competition-scenarios-v0.1.mjs';

const STORAGE = {
  recent: 'bjjnote.recentTechnique',
  history: 'bjjnote.recentHistory.v1',
  notes: 'bjjnote.notes.v1',
};

const POSITION_LABELS = [
  ['closed-guard', '클로즈드가드'],
  ['closed-guard-top', '클로즈드가드 탑'],
  ['mount', '마운트'],
  ['bottom-mount', '바텀 마운트'],
  ['bottom-side-control', '바텀 사이드'],
  ['top-side-control', '탑 사이드'],
  ['top-half-guard', '탑 하프가드'],
  ['spider-guard', '스파이더가드'],
];

const style = document.createElement('style');
style.textContent = `
.devSwitch{display:none!important}
.top{padding-bottom:12px}.top p{display:none}
.shellPanel{display:none}.shellPanel.active{display:block}
.homeHeader{display:flex;justify-content:space-between;align-items:center;margin:0 0 18px}.homeHeader h1{font-size:22px;margin:0;color:#1C2B44;letter-spacing:-.04em}.homeHeader button{border:0;background:#F2F5F7;border-radius:999px;padding:8px 11px;font-size:10px;font-weight:800;color:#667381}
.shellTitle{display:flex;justify-content:space-between;align-items:end;margin:22px 0 10px}.shellTitle h2{font-size:18px;margin:0}.shellTitle span{font-size:10px;color:#8498A8}
.todayCard{width:100%;border:0;background:#1C2B44;color:#fff;border-radius:22px;padding:19px;text-align:left;position:relative;overflow:hidden}.todayCard::after{content:'→';position:absolute;right:18px;bottom:18px;width:32px;height:32px;border-radius:50%;display:grid;place-items:center;background:rgba(255,255,255,.12);font-size:17px}.todayCard small{font-size:10px;font-weight:800;opacity:.6}.todayCard b{display:block;margin-top:8px;font-size:22px;letter-spacing:-.04em}.todayCard p{font-size:11px;margin:5px 45px 0 0;opacity:.72}.todayCard .emptyToday{font-size:17px}
.actionRow{display:grid;grid-template-columns:repeat(3,1fr);gap:7px;margin-top:9px}.actionRow button{border:1px solid #E3E8EC;background:#fff;border-radius:15px;min-height:66px;padding:10px 6px;color:#1C2B44;font-size:11px;font-weight:800}.actionRow button::before{display:block;font-size:18px;margin-bottom:6px;font-weight:400}.actionRow .findTech::before{content:'⌕'}.actionRow .doDrill::before{content:'↻'}.actionRow .writeNote::before{content:'✎'}
.positionGrid{display:grid;grid-template-columns:repeat(2,1fr);gap:8px}.positionCard{border:1px solid #E3E8EC;background:#fff;border-radius:16px;text-align:left;padding:13px;min-height:72px;color:#1C2B44}.positionCard b{display:block;font-size:13px}.positionCard span{display:block;margin-top:7px;font-size:9px;color:#8498A8;font-weight:700}
.activityList{display:grid;gap:7px}.activityItem{width:100%;border:0;background:#F7F8FA;border-radius:14px;padding:12px;text-align:left;display:flex;justify-content:space-between;align-items:center;color:#1C2B44}.activityItem b{font-size:12px}.activityItem span{display:block;font-size:9px;color:#8498A8;margin-top:3px}.activityItem i{font-style:normal;color:#8498A8}.activityEmpty{border:1px dashed #C8D1D8;border-radius:14px;padding:15px;text-align:center;font-size:10px;color:#8498A8}
.flowList{display:grid;gap:10px}.flowCard{border:1px solid #E3E8EC;border-radius:17px;padding:15px;background:#fff}.flowCard button{width:100%;border:0;background:transparent;padding:0;text-align:left;color:#1A232D}.flowCard .flowHead{display:flex;justify-content:space-between;gap:10px}.flowCard b{font-size:14px}.flowCard small{font-size:10px;color:#8498A8;white-space:nowrap}.flowCard p{font-size:11px;color:#667381;line-height:1.5;margin:5px 0 0}.flowNodes{display:none;gap:6px;flex-wrap:wrap;margin-top:11px;padding-top:11px;border-top:1px solid #E3E8EC}.flowCard.open .flowNodes{display:flex}.flowNodes button{width:auto;border:1px solid #E3E8EC;border-radius:999px;padding:7px 9px;font-size:10px;color:#1C2B44;background:#F7F8FA}
.scenarioCard{width:100%;border:1px solid #E3E8EC;border-radius:17px;padding:15px;background:#fff;text-align:left;color:#1A232D}.scenarioCard b{display:block;font-size:14px}.scenarioCard p{font-size:11px;color:#667381;line-height:1.5;margin:6px 0}.scenarioMeta{display:flex;gap:5px;flex-wrap:wrap;margin-top:9px}.scenarioPill{font-size:9px;padding:5px 7px;border-radius:999px;background:#F2F5F7;color:#667381;font-weight:700;border:0}.scenarioHero{background:#1C2B44;color:#fff;border-radius:18px;padding:16px;margin:14px 0 0}.scenarioHero small{font-size:9px;font-weight:800;opacity:.65}.scenarioHero p{font-size:11px;line-height:1.55;margin:6px 0 0;opacity:.82}.scenarioBack{border:0;background:transparent;padding:0;color:#1C2B44;font-size:12px;font-weight:800;margin:0 0 10px}.scenarioStepList{display:grid;gap:8px}.scenarioStepItem{display:grid;grid-template-columns:28px 1fr;gap:9px;border:1px solid #E3E8EC;border-radius:13px;padding:11px}.scenarioStepNum{width:28px;height:28px;border-radius:8px;background:#1C2B44;color:#fff;display:grid;place-items:center;font-size:10px;font-weight:800}.scenarioStepItem b{font-size:12px}.scenarioStepItem p{font-size:11px;color:#667381;line-height:1.5;margin:4px 0}.scenarioStepItem small{font-size:9px;color:#8498A8}.scenarioPoints{background:#F2F5F7;border-radius:14px;padding:12px 14px;font-size:11px;line-height:1.5}.scenarioPoints ul{margin:4px 0 0;padding-left:18px}.scenarioBranches{display:grid;gap:8px}.scenarioBranch{border:1px solid #E3E8EC;border-left:4px solid #1C2B44;border-radius:0 14px 14px 0;padding:12px}.scenarioBranch small{display:block;color:#8498A8;font-size:9px;font-weight:800}.scenarioBranch b{display:block;font-size:12px;margin:4px 0}.scenarioBranch p{font-size:11px;line-height:1.5;color:#667381;margin:0}.scenarioBranch .scenarioMeta{margin-top:8px}.scenarioNext{text-align:left;cursor:pointer}
.noteComposer{background:#F2F5F7;border-radius:18px;padding:14px}.noteComposer textarea{width:100%;min-height:116px;resize:vertical;border:0;background:#fff;border-radius:13px;padding:12px;font:inherit;font-size:12px;line-height:1.5;outline:none}.noteComposer button{width:100%;height:42px;border:0;border-radius:12px;background:#1C2B44;color:#fff;font-size:12px;font-weight:800;margin-top:8px}.noteList{display:grid;gap:8px;margin-top:12px}.noteItem{border:1px solid #E3E8EC;border-radius:14px;padding:12px}.noteItem time{font-size:9px;color:#8498A8}.noteItem p{font-size:12px;line-height:1.55;margin:5px 0 0;white-space:pre-wrap}.emptyNote{border:1px dashed #8498A8;border-radius:14px;padding:16px;text-align:center;font-size:11px;color:#667381}
.bottom button{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px}.bottom button::before{font-size:17px;line-height:1}.bottom button[data-shell-tab="home"]::before{content:'⌂'}.bottom button[data-shell-tab="tech"]::before{content:'◫'}.bottom button[data-shell-tab="flow"]::before{content:'↝'}.bottom button[data-shell-tab="note"]::before{content:'✎'}
@media(min-width:700px){.positionGrid{grid-template-columns:repeat(3,1fr)}.actionRow{max-width:560px}.todayCard{padding:22px}.shellPanel{max-width:820px;margin:0 auto}}
`;
document.head.appendChild(style);

function safeJson(key, fallback) {
  try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; }
}

function setRecent(payload) {
  try {
    localStorage.setItem(STORAGE.recent, JSON.stringify(payload));
    const history = safeJson(STORAGE.history, []).filter(x => !(x.techniqueId === payload.techniqueId && x.positionId === payload.positionId));
    history.unshift(payload);
    localStorage.setItem(STORAGE.history, JSON.stringify(history.slice(0, 5)));
  } catch {}
}

function getRecent() { return safeJson(STORAGE.recent, null); }
function makeSection(id, html) { const el=document.createElement('section'); el.id=id; el.className='shellPanel'; el.innerHTML=html; return el; }

async function init() {
  const main=document.querySelector('main');
  const bottom=document.querySelector('.bottom');
  const indexPanel=document.getElementById('index');
  const detailPanel=document.getElementById('detail');
  const legacyPanel=document.getElementById('legacy');
  if (!main || !bottom || !indexPanel || !detailPanel) return;

  const techniques=await loadTechniqueRecords();
  const techniqueList=techniques.map(t=>t);
  const techniqueById=new Map(techniqueList.map(t=>[t.id,t]));
  const drillsPayload=await loadSoloDrills();
  const flows=buildAllLearningFlows(Object.fromEntries(techniqueList.map(t=>[t.id,t])),FLOW_DEFINITIONS);
  const positionCounts=Object.fromEntries(POSITION_LABELS.map(([id])=>[id,techniqueList.filter(t=>(t.entryRoutes||[]).some(r=>r.fromPositionId===id)).length]));
  let mobileFlowMode='learning';
  let activeScenarioId=null;

  const home=makeSection('homeShell',`
    <div class="homeHeader"><h1>주짓수 노트</h1><button id="homeRecentButton">최근 기록</button></div>
    <div class="shellTitle" style="margin-top:0"><h2>오늘의 훈련</h2><span>${techniqueList.length}개 기술</span></div>
    <button class="todayCard" id="continueCard"><small>이어서 복습하기</small><b id="continueTitle">기술을 하나 골라보세요</b><p id="continueMeta">오늘 복습할 기술을 찾아 시작해보세요.</p></button>
    <div class="actionRow"><button class="findTech" id="homeFindTech">기술 찾기</button><button class="doDrill" id="homeDrill">드릴 하기</button><button class="writeNote" id="homeWriteNote">훈련 기록</button></div>
    <div class="shellTitle"><h2>포지션에서 찾기</h2><span>${POSITION_LABELS.length}개 포지션</span></div>
    <div class="positionGrid">${POSITION_LABELS.map(([id,label])=>`<button class="positionCard" data-home-position="${id}"><b>${label}</b><span>${positionCounts[id]}개 기술 · 목차 열기</span></button>`).join('')}</div>
    <div class="shellTitle" id="activityAnchor"><h2>최근 활동</h2><span>최근 3개</span></div><div class="activityList" id="activityList"></div>
  `);

  const flow=makeSection('flowShell','');

  const note=makeSection('noteShell',`
    <div class="shellTitle" style="margin-top:0"><h2>훈련 노트</h2><span>이 기기에 저장</span></div>
    <p class="hint">오늘 배운 것, 막힌 것, 다음에 확인할 것을 짧게 남겨보세요.</p>
    <div class="noteComposer"><textarea id="noteInput" placeholder="예: 마운트에서 Americana가 막히면 팔을 억지로 당기지 말고 S-mount로 높여 Armbar 연결 확인"></textarea><button id="saveNote">노트 저장</button></div>
    <div class="shellTitle"><h2>최근 기록</h2><span id="noteCount"></span></div><div class="noteList" id="noteList"></div>
  `);

  main.prepend(home);
  main.append(flow,note);

  const navButtons=[...bottom.querySelectorAll('button')];
  const tabs=['home','tech','flow','note'];
  navButtons.forEach((btn,i)=>{btn.dataset.shellTab=tabs[i];});

  function hideAll(){
    document.querySelectorAll('.panel').forEach(x=>x.classList.remove('active'));
    document.querySelectorAll('.shellPanel').forEach(x=>x.classList.remove('active'));
    if(legacyPanel) legacyPanel.classList.remove('active');
  }

  function show(tab){
    hideAll();
    if(tab==='home') home.classList.add('active');
    if(tab==='tech') indexPanel.classList.add('active');
    if(tab==='flow') flow.classList.add('active');
    if(tab==='note') note.classList.add('active');
    navButtons.forEach(b=>b.classList.toggle('active',b.dataset.shellTab===tab));
    if(tab==='home') renderHome();
    if(tab==='flow') renderFlowShell();
    if(tab==='note') renderNotes();
    window.scrollTo({top:0,behavior:'instant'});
  }

  navButtons.forEach(btn=>btn.addEventListener('click',e=>{e.preventDefault();show(btn.dataset.shellTab);}));

  function openPosition(positionId){
    show('tech');
    document.querySelector(`#positions button[data-id="${positionId}"]`)?.click();
  }

  function openTechnique(techniqueId,positionId){
    openPosition(positionId);
    queueMicrotask(()=>document.querySelector(`#techniques .card[data-tech="${techniqueId}"]`)?.click());
  }

  home.querySelectorAll('[data-home-position]').forEach(btn=>btn.addEventListener('click',()=>openPosition(btn.dataset.homePosition)));
  home.querySelector('#homeFindTech').onclick=()=>show('tech');
  home.querySelector('#homeWriteNote').onclick=()=>show('note');
  home.querySelector('#homeRecentButton').onclick=()=>home.querySelector('#activityAnchor').scrollIntoView({behavior:'smooth'});
  home.querySelector('#homeDrill').onclick=()=>{show('tech');document.querySelector('.catalogSwitch button[data-catalog="drills"]')?.click();};

  function scenarioStatusLabel(status){
    if(status==='planned') return '다음 시나리오 예정';
    if(status==='loop') return '같은 단계 반복';
    if(status==='candidate') return '공격 선택';
    if(status==='scenario') return '시나리오 이동';
    if(status==='outcome') return '포지션 전환';
    return status||'';
  }

  function renderLearningFlowShell(){
    return `
      <div class="shellTitle"><h2>기술 흐름</h2><span>${flows.length}개 흐름</span></div>
      <p class="hint">상대 반응에 따라 이미 검증된 기술 연결만 보여줍니다.</p>
      <div class="flowList">${flows.map((f,i)=>`<div class="flowCard" data-flow-index="${i}"><button class="flowToggle"><div class="flowHead"><b>${f.title}</b><small>${f.nodes.length}개 기술 · ${f.edges.length}개 연결</small></div><p>${f.description}</p></button><div class="flowNodes">${f.nodes.map(n=>`<button data-flow-tech="${n.techniqueId}" data-flow-position="${f.positionId}">${n.nameKo}</button>`).join('')}</div></div>`).join('')}</div>`;
  }

  function renderScenarioIndex(){
    return `
      <div class="shellTitle"><h2>내 시합 플랜</h2><span>${COMPETITION_SCENARIOS.length}개 시나리오</span></div>
      <p class="hint">상황 → 상대 행동 → 내 판단 → 다음 포지션 순서로 경기 운영을 미리 정합니다.</p>
      <div class="context"><b>반응형 A-Game</b><br>빠른 선공 경쟁보다 안정 → 제거 → 공격 순서로 판단 시간을 줄입니다.</div>
      <div class="shellTitle"><h2>경기 시작</h2><span>우선 준비</span></div>
      <div class="flowList" id="mobileScenarioList">${COMPETITION_SCENARIOS.map(s=>`<button class="scenarioCard" data-mobile-scenario="${s.id}"><b>${s.shortTitle||s.title}</b><p>${s.summary}</p><div class="scenarioMeta"><span class="scenarioPill">${s.phaseLabel}</span><span class="scenarioPill">${s.badge}</span></div></button>`).join('')}</div>`;
  }

  function renderScenarioDetail(s){
    return `
      <button class="scenarioBack" id="mobileScenarioBack">← 시합 시나리오</button>
      <div class="context"><b>${s.phaseLabel}</b> · ${s.badge}<br>${s.goal}</div>
      <div class="shellTitle"><h2>${s.title}</h2><span>개인 루트</span></div>
      <p class="hint">상대 선공을 받아낸 뒤 두 번째 교환부터 내가 주도하는 흐름</p>
      <div class="scenarioHero"><small>성공 기준</small><p>${s.successCriteria}</p></div>
      <div class="shellTitle"><h2>기본 원칙</h2><span>${s.principles.length}개</span></div>
      <div class="scenarioPoints"><ul>${s.principles.map(x=>`<li>${x}</li>`).join('')}</ul></div>
      <div class="shellTitle"><h2>진행 순서</h2><span>${s.steps.length}단계</span></div>
      <div class="scenarioStepList" id="mobileScenarioSteps">${s.steps.map((step,i)=>`<div class="scenarioStepItem" data-mobile-scenario-step="${step.id}"><div class="scenarioStepNum">${i+1}</div><div><b>${step.title}</b><p>${step.instruction}</p><small>${step.cue}</small></div></div>`).join('')}</div>
      <div class="shellTitle"><h2>상대 반응별 선택</h2><span>${s.branches.length}개 분기</span></div>
      <div class="scenarioBranches" id="mobileScenarioBranches">${s.branches.map(branch=>`<div class="scenarioBranch" data-mobile-scenario-branch="${branch.id}"><small>상대가 이렇게 하면</small><b>${branch.when}</b><p>${branch.response}</p><div class="scenarioMeta">${branch.nextScenarioId?`<button class="scenarioPill scenarioNext" data-next-scenario="${branch.nextScenarioId}">→ ${branch.next}</button>`:`<span class="scenarioPill">→ ${branch.next}</span>`}<span class="scenarioPill">${scenarioStatusLabel(branch.nextStatus)}</span></div></div>`).join('')}</div>
      <div class="shellTitle"><h2>피할 것</h2><span>${s.commonMistakes.length}개</span></div>
      <div class="scenarioPoints"><ul>${s.commonMistakes.map(x=>`<li>${x}</li>`).join('')}</ul></div>`;
  }

  function renderFlowShell(){
    const scenario=activeScenarioId?COMPETITION_SCENARIOS.find(s=>s.id===activeScenarioId):null;
    flow.innerHTML=`
      <div class="shellTitle" style="margin-top:0"><h2>흐름</h2><span>연결 · 경기 운영</span></div>
      <div class="catalogSwitch" id="mobileFlowModeSwitch"><button class="${mobileFlowMode==='learning'?'active':''}" data-mobile-flow-mode="learning">기술 흐름</button><button class="${mobileFlowMode==='competition'?'active':''}" data-mobile-flow-mode="competition">시합 시나리오</button></div>
      ${mobileFlowMode==='learning'?renderLearningFlowShell():(scenario?renderScenarioDetail(scenario):renderScenarioIndex())}`;

    flow.querySelectorAll('#mobileFlowModeSwitch button').forEach(btn=>btn.onclick=()=>{
      mobileFlowMode=btn.dataset.mobileFlowMode;
      activeScenarioId=null;
      renderFlowShell();
      window.scrollTo({top:0,behavior:'instant'});
    });
    if(mobileFlowMode==='learning'){
      flow.querySelectorAll('.flowToggle').forEach(btn=>btn.addEventListener('click',()=>btn.closest('.flowCard').classList.toggle('open')));
      flow.querySelectorAll('[data-flow-tech]').forEach(btn=>btn.addEventListener('click',()=>openTechnique(btn.dataset.flowTech,btn.dataset.flowPosition)));
      return;
    }
    flow.querySelectorAll('[data-mobile-scenario]').forEach(btn=>btn.onclick=()=>{
      activeScenarioId=btn.dataset.mobileScenario;
      renderFlowShell();
      window.scrollTo({top:0,behavior:'instant'});
    });
    flow.querySelectorAll('.scenarioNext').forEach(btn=>btn.onclick=()=>{
      activeScenarioId=btn.dataset.nextScenario;
      renderFlowShell();
      window.scrollTo({top:0,behavior:'instant'});
    });
    flow.querySelector('#mobileScenarioBack')?.addEventListener('click',()=>{
      activeScenarioId=null;
      renderFlowShell();
      window.scrollTo({top:0,behavior:'instant'});
    });
  }

  document.addEventListener('click',e=>{
    const card=e.target.closest?.('#techniques .card[data-tech]');
    if(!card) return;
    const t=techniqueById.get(card.dataset.tech);
    setRecent({techniqueId:card.dataset.tech,positionId:document.querySelector('#positions button.active')?.dataset.id||null,routeId:card.dataset.route||null,nameKo:t?.nameKo||card.querySelector('b')?.textContent||card.dataset.tech,at:Date.now()});
    navButtons.forEach(b=>b.classList.toggle('active',b.dataset.shellTab==='tech'));
  },true);

  function renderHome(){
    const recent=getRecent();
    const title=home.querySelector('#continueTitle');
    const meta=home.querySelector('#continueMeta');
    const card=home.querySelector('#continueCard');
    if(!recent?.techniqueId){
      title.textContent='기술을 하나 골라보세요';
      title.classList.add('emptyToday');
      meta.textContent='오늘 복습할 기술을 찾아 시작해보세요.';
      card.onclick=()=>show('tech');
    } else {
      title.classList.remove('emptyToday');
      const t=techniqueById.get(recent.techniqueId);
      const pos=POSITION_LABELS.find(([id])=>id===recent.positionId)?.[1]||'기술';
      title.textContent=t?.nameKo||recent.nameKo||recent.techniqueId;
      meta.textContent=`${pos}에서 이어보기`;
      card.onclick=()=>openTechnique(recent.techniqueId,recent.positionId||'closed-guard');
    }

    const history=safeJson(STORAGE.history,[]).slice(0,3);
    const notes=safeJson(STORAGE.notes,[]);
    const items=history.map(h=>({kind:'tech',...h}));
    if(notes[0]&&items.length<3) items.push({kind:'note',...notes[0]});
    home.querySelector('#activityList').innerHTML=items.length
      ? items.slice(0,3).map(item=>item.kind==='note'
        ? `<button class="activityItem" data-activity-note><div><b>훈련 노트</b><span>${escapeHtml(item.text).slice(0,34)}</span></div><i>›</i></button>`
        : `<button class="activityItem" data-activity-tech="${item.techniqueId}" data-activity-position="${item.positionId||'closed-guard'}"><div><b>${escapeHtml(techniqueById.get(item.techniqueId)?.nameKo||item.nameKo||item.techniqueId)}</b><span>${POSITION_LABELS.find(([id])=>id===item.positionId)?.[1]||'기술'}</span></div><i>›</i></button>`).join('')
      : '<div class="activityEmpty">기술을 보거나 노트를 남기면 여기에 최근 활동이 표시됩니다.</div>';
    home.querySelectorAll('[data-activity-tech]').forEach(btn=>btn.onclick=()=>openTechnique(btn.dataset.activityTech,btn.dataset.activityPosition));
    home.querySelector('[data-activity-note]')?.addEventListener('click',()=>show('note'));
  }

  function renderNotes(){
    const notes=safeJson(STORAGE.notes,[]);
    note.querySelector('#noteCount').textContent=`${notes.length}개 노트`;
    note.querySelector('#noteList').innerHTML=notes.length
      ? notes.map(n=>`<article class="noteItem"><time>${new Date(n.at).toLocaleString('ko-KR',{month:'numeric',day:'numeric',hour:'2-digit',minute:'2-digit'})}</time><p>${escapeHtml(n.text)}</p></article>`).join('')
      : '<div class="emptyNote">아직 저장한 노트가 없습니다.</div>';
  }

  function escapeHtml(text){return String(text).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}

  note.querySelector('#saveNote').onclick=()=>{
    const input=note.querySelector('#noteInput');
    const text=input.value.trim();
    if(!text) return;
    const notes=safeJson(STORAGE.notes,[]);
    notes.unshift({id:`note-${Date.now()}`,text,at:Date.now()});
    try{localStorage.setItem(STORAGE.notes,JSON.stringify(notes.slice(0,50)));}catch{}
    input.value='';
    renderNotes();
  };

  renderHome();
  renderFlowShell();
  renderNotes();
  show('home');
  window.__BJJ_MOBILE_SHELL__={show,flows:flows.length,scenarios:COMPETITION_SCENARIOS.length,techniques:techniqueList.length,drills:drillsPayload.drills?.length||0,homeVersion:'v2'};
}

setTimeout(()=>init().catch(err=>console.error('mobile-shell init failed',err)),0);
