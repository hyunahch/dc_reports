import { BEGINNER_COMPETITION_VIDEOS } from './competition-beginner-videos-v0.1.mjs';

const REMOTE_URL = 'https://raw.githubusercontent.com/hyunahch/dc_reports/main/bjjnote-content/beginner-competition-videos.json';
const CACHE_KEY = 'bjjnote.beginnerCompetitionVideos.remote.v1';
const MAX_VIDEOS = 8;
let pendingFeed = null;

function safeParse(value) {
  try { return JSON.parse(value); } catch { return null; }
}

function normalizeVideo(video) {
  if (!video || typeof video !== 'object') return null;
  const youtubeId = String(video.youtubeId || '').trim();
  const id = String(video.id || '').trim();
  const title = String(video.title || '').trim();
  if (!id || !title || !/^[A-Za-z0-9_-]{6,20}$/.test(youtubeId)) return null;
  const categories = Array.isArray(video.categories)
    ? [...new Set(video.categories.map(value => String(value).trim()).filter(Boolean))]
    : [];
  const watchPoints = Array.isArray(video.watchPoints)
    ? video.watchPoints.map(value => String(value).trim()).filter(Boolean).slice(0, 4)
    : [];
  if (!categories.length || !watchPoints.length) return null;
  return {
    id,
    youtubeId,
    title,
    originalTitle: String(video.originalTitle || title),
    channel: String(video.channel || 'YouTube'),
    duration: String(video.duration || '경기 영상'),
    categories,
    badge: String(video.badge || '초보 경기'),
    summary: String(video.summary || '실제 초보 경기 흐름을 관찰하는 참고 영상입니다.'),
    watchPoints,
    startSeconds: Math.max(0, Number(video.startSeconds || 0) || 0),
    sourceType: String(video.sourceType || 'remote'),
  };
}

function normalizeFeed(feed) {
  if (!feed || Number(feed.schemaVersion) !== 1 || !Array.isArray(feed.videos)) return null;
  const videos = [];
  const seenIds = new Set();
  const seenYoutube = new Set();
  for (const raw of feed.videos) {
    const video = normalizeVideo(raw);
    if (!video || seenIds.has(video.id) || seenYoutube.has(video.youtubeId)) continue;
    seenIds.add(video.id);
    seenYoutube.add(video.youtubeId);
    videos.push(video);
    if (videos.length >= MAX_VIDEOS) break;
  }
  if (videos.length < 4) return null;
  return {
    schemaVersion: 1,
    updatedAt: String(feed.updatedAt || ''),
    curationMode: String(feed.curationMode || 'remote'),
    videos,
  };
}

function readCache() {
  try { return normalizeFeed(safeParse(localStorage.getItem(CACHE_KEY))); } catch { return null; }
}

function writeCache(feed) {
  try { localStorage.setItem(CACHE_KEY, JSON.stringify(feed)); } catch {}
}

function activeIframeCount() {
  return document.querySelectorAll('[data-beginner-video-media] iframe').length;
}

function rerenderVideoSurfaces() {
  document.querySelectorAll('[data-beginner-video-library="1"], [data-guard-pull-video-reference="1"]').forEach(node => node.remove());
}

function applyFeed(feed, source) {
  if (!feed) return false;
  if (activeIframeCount() > 0) {
    pendingFeed = { feed, source };
    return false;
  }
  BEGINNER_COMPETITION_VIDEOS.splice(0, BEGINNER_COMPETITION_VIDEOS.length, ...feed.videos);
  rerenderVideoSurfaces();
  queueMicrotask(() => {
    document.dispatchEvent(new CustomEvent('bjj:beginner-video-feed-updated', {
      detail: { source, updatedAt: feed.updatedAt, count: feed.videos.length }
    }));
  });
  globalThis.__BJJ_BEGINNER_VIDEO_REMOTE__ = {
    version: 'v0.1',
    source,
    updatedAt: feed.updatedAt,
    count: feed.videos.length,
    url: REMOTE_URL,
  };
  return true;
}

function applyPendingWhenSafe() {
  if (!pendingFeed || activeIframeCount() > 0) return;
  const next = pendingFeed;
  pendingFeed = null;
  applyFeed(next.feed, next.source);
}

async function fetchRemote() {
  try {
    const response = await fetch(`${REMOTE_URL}?t=${Date.now()}`, { cache: 'no-store' });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const feed = normalizeFeed(await response.json());
    if (!feed) throw new Error('invalid remote feed');
    writeCache(feed);
    applyFeed(feed, 'remote');
  } catch (error) {
    globalThis.__BJJ_BEGINNER_VIDEO_REMOTE__ = {
      version: 'v0.1',
      source: 'fallback',
      count: BEGINNER_COMPETITION_VIDEOS.length,
      url: REMOTE_URL,
      error: String(error?.message || error),
    };
  }
}

const cached = readCache();
if (cached) applyFeed(cached, 'cache');
else globalThis.__BJJ_BEGINNER_VIDEO_REMOTE__ = {
  version: 'v0.1',
  source: 'bundled',
  count: BEGINNER_COMPETITION_VIDEOS.length,
  url: REMOTE_URL,
};

setTimeout(fetchRemote, 0);
document.addEventListener('click', applyPendingWhenSafe, true);
window.addEventListener('popstate', applyPendingWhenSafe);
window.addEventListener('hashchange', applyPendingWhenSafe);
document.addEventListener('visibilitychange', () => {
  if (!document.hidden) applyPendingWhenSafe();
});

export { REMOTE_URL };
