import { compareVersions } from './app-update-core-v0.1.mjs';

export function validateOtaManifest(manifest) {
  if (!manifest || typeof manifest !== 'object') return false;
  if (Number(manifest.schemaVersion) !== 1) return false;
  if (typeof manifest.version !== 'string' || !/^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$/.test(manifest.version)) return false;
  if (!Number.isInteger(Number(manifest.nativeSchema)) || Number(manifest.nativeSchema) < 1) return false;
  if (typeof manifest.bundleUrl !== 'string' || !/^https:\/\//i.test(manifest.bundleUrl)) return false;
  if (typeof manifest.sha256 !== 'string' || !/^[a-f0-9]{64}$/i.test(manifest.sha256)) return false;
  return true;
}

export function classifyOtaUpdate(currentVersion, nativeSchema, manifest) {
  if (!validateOtaManifest(manifest)) return 'invalid';
  if (Number(manifest.nativeSchema) !== Number(nativeSchema)) return 'native-update-required';
  if (compareVersions(manifest.version, currentVersion) <= 0) return 'current';
  return 'available';
}
