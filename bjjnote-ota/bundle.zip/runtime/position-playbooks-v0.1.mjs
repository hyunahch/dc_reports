export const POSITION_PLAYBOOKS = [
  {
    id: 'top-side-control',
    positionId: 'top-side-control',
    nameKo: '탑 사이드 컨트롤',
    eyebrow: 'POSITION PLAYBOOK',
    title: '여기서 뭘 하지?',
    summary: '도착 직후 공격부터 찾지 말고, 먼저 안정한 뒤 상대 반응을 보고 다음 선택을 고릅니다.',
    arrival: {
      seconds: 3,
      title: '먼저 3초만 안정시키기',
      cues: [
        '머리·어깨 방향을 먼저 통제하기',
        '내 베이스와 힙 위치를 안정시키기',
        '상대 팔과 무릎이 어디로 움직이는지 확인하기',
      ],
    },
    overview: [
      { id: 'stabilize', label: '안정' },
      { id: 'attack', label: '공격' },
      { id: 'advance', label: '이동' },
    ],
    reactions: [
      {
        id: 'frames-with-arm',
        label: '팔로 나를 밀어요',
        opponent: '팔로 프레임을 만들고 내 상체를 밀어냅니다.',
        insight: '팔꿈치가 몸에서 떨어지는 순간을 먼저 확인합니다.',
        primary: {
          kind: 'technique',
          techniqueId: 'americana',
          entryRouteId: 'from-top-side-control',
          label: '아메리카나',
          description: '팔꿈치가 벌어진 상태라면 손목과 팔꿈치 라인을 고정해 아메리카나를 첫 공격으로 연결합니다.',
        },
        branches: [
          {
            when: '팔을 펴며 빠져나와요',
            kind: 'technique',
            techniqueId: 'armbar',
            entryRouteId: 'from-top-side-control',
            label: '암바로 연결',
          },
          {
            when: '팔을 다시 몸에 붙여요',
            kind: 'position',
            positionId: 'mount',
            label: '마운트 이동을 우선',
          },
        ],
      },
      {
        id: 'elbows-tight',
        label: '팔을 몸에 붙여요',
        opponent: '팔꿈치를 몸통에 붙이고 서브미션 공간을 닫습니다.',
        insight: '억지로 팔을 떼기보다 상위 포지션을 더 좋게 만드는 쪽을 우선합니다.',
        primary: {
          kind: 'position',
          positionId: 'mount',
          label: '마운트로 이동',
          description: '상대 팔이 단단히 접혀 있다면 공격을 억지로 열기보다 무릎과 힙 공간을 확인해 마운트 전환을 노립니다.',
        },
        branches: [
          {
            when: '이동 중 팔꿈치가 벌어져요',
            kind: 'technique',
            techniqueId: 'americana',
            entryRouteId: 'from-top-side-control',
            label: '아메리카나 다시 확인',
          },
        ],
      },
      {
        id: 'knee-reinsert',
        label: '무릎을 안으로 넣어요',
        opponent: '무릎과 프레임을 사이에 넣어 가드를 다시 만들려 합니다.',
        insight: '공격보다 포지션 유지가 먼저입니다. 프레임과 힙 라인을 다시 정리합니다.',
        primary: {
          kind: 'stabilize',
          label: '공격 중단 · 자리 다시 잡기',
          description: '상대 무릎이 내 몸 사이로 들어오면 서브미션을 이어가기보다 크로스페이스·힙 컨트롤과 베이스를 다시 확보합니다.',
        },
        branches: [
          {
            when: '가드가 거의 복구됐어요',
            kind: 'technique',
            techniqueId: 'knee-cut-pass',
            entryRouteId: 'from-top-half-guard',
            label: '니 컷 패스 다시 보기',
          },
        ],
      },
      {
        id: 'upper-body-turn',
        label: '상체를 돌리며 팔을 빼요',
        opponent: '상체를 옆으로 돌리며 팔과 어깨 라인을 빼내려 합니다.',
        insight: '돌아가는 방향과 팔꿈치 공간을 보면서 가까운 팔을 억지로 당기지 않습니다.',
        primary: {
          kind: 'technique',
          techniqueId: 'kimura',
          entryRouteId: 'from-top-side-control',
          label: '기무라',
          description: '어깨와 팔꿈치 라인이 열리면 기무라 그립으로 상체 회전을 다시 통제하는 선택을 확인합니다.',
        },
        branches: [
          {
            when: '팔을 완전히 펴며 빠져요',
            kind: 'technique',
            techniqueId: 'armbar',
            entryRouteId: 'from-top-side-control',
            label: '암바 연결 확인',
          },
        ],
      },
    ],
  },
];

export const ARRIVAL_PLAYBOOK_LINKS = {
  'knee-cut-pass': {
    positionId: 'top-side-control',
    playbookId: 'top-side-control',
    label: '탑 사이드 컨트롤',
  },
};

export function getPositionPlaybook(idOrPositionId) {
  return POSITION_PLAYBOOKS.find(x => x.id === idOrPositionId || x.positionId === idOrPositionId) || null;
}
