const ACTION_LABELS = new Map([
  ['submission', '서브미션'],
  ['sweep', '스윕'],
  ['pass', '패스'],
  ['escape', '탈출'],
  ['takedown', '테이크다운'],
  ['transition', '전환'],
  ['control', '컨트롤'],
  ['guard', '가드'],
  ['choke', '초크'],
  ['joint-lock', '관절기'],
]);

function actionLabel(value) {
  const key = String(value || '').trim().toLowerCase();
  return ACTION_LABELS.get(key) || value || '기술';
}

function addStyles() {
  if (document.getElementById('mobile-tech-polish-style')) return;
  const style = document.createElement('style');
  style.id = 'mobile-tech-polish-style';
  style.textContent = `
    #index.techPolished{padding-bottom:10px}
    #techLibraryHeader{margin:0 0 17px}
    #techLibraryHeader small{display:block;margin-bottom:5px;font-size:9px;line-height:1;font-weight:900;letter-spacing:.14em;color:#8498A8}
    #techLibraryHeader h1{margin:0;color:#1C2B44;font-size:25px;line-height:1.15;letter-spacing:-.045em}
    #techLibraryHeader p{margin:7px 0 0;color:#667381;font-size:11px;line-height:1.55}
    #index.techPolished .catalogSwitch{gap:5px;padding:4px;margin-bottom:22px;border-radius:15px;background:#EEF1F4}
    #index.techPolished .catalogSwitch button{height:40px;border-radius:11px;font-size:12px}
    #index.techPolished .catalogSwitch button.active{box-shadow:0 3px 10px rgba(20,35,50,.055)}
    #index.techPolished #techCatalog>h2,#index.techPolished #drillCatalog>h2{margin:0 0 5px;color:#1C2B44;font-size:17px;letter-spacing:-.03em}
    #index.techPolished #techCatalog>.hint,#index.techPolished #drillCatalog>.hint{margin:0 0 12px;color:#8498A8;font-size:10px;line-height:1.5}
    #index.techPolished #positions,#index.techPolished #drillCategories{gap:7px;margin-right:-20px;padding:0 20px 7px 0;scrollbar-width:none;-webkit-overflow-scrolling:touch}
    #index.techPolished #positions::-webkit-scrollbar,#index.techPolished #drillCategories::-webkit-scrollbar{display:none}
    #index.techPolished #positions button,#index.techPolished #drillCategories button{flex:0 0 auto;min-height:36px;padding:8px 12px;border-color:#E3E8EC;background:#fff;color:#667381;font-size:11px;font-weight:700;box-shadow:0 2px 8px rgba(20,35,50,.025)}
    #index.techPolished #positions button.active,#index.techPolished #drillCategories button.active{border-color:#1C2B44;background:#1C2B44;color:#fff;box-shadow:none}
    .catalogResultHead{display:flex;align-items:end;justify-content:space-between;margin:14px 0 9px}
    .catalogResultHead b{color:#1C2B44;font-size:14px;letter-spacing:-.02em}
    .catalogResultHead span{color:#8498A8;font-size:10px;font-weight:700}
    #index.techPolished #techniques,#index.techPolished #drills{gap:9px}
    #index.techPolished #techniques .card,#index.techPolished #drills .card{position:relative;width:100%;border:0;background:#fff;border-radius:16px;padding:14px 44px 14px 15px;box-shadow:0 3px 13px rgba(20,35,50,.045);color:#1A232D}
    #index.techPolished #techniques .card{min-height:72px}
    #index.techPolished #techniques .card::after,#index.techPolished #drills .card::after{content:'›';position:absolute;right:15px;top:50%;transform:translateY(-50%);color:#A3AFB9;font-size:22px;font-weight:400}
    #index.techPolished #techniques .card b,#index.techPolished #drills .card b{font-size:14px;line-height:1.25;letter-spacing:-.02em;color:#1C2B44}
    #index.techPolished #techniques .card small{display:flex;align-items:center;gap:6px;margin-top:8px;color:#667381}
    .techActionBadge{display:inline-flex;align-items:center;min-height:22px;padding:4px 7px;border-radius:999px;background:#EEF3F7;color:#40556A;font-size:9px;font-weight:800;line-height:1}
    .techRouteText{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#8498A8;font-size:10px;font-weight:700}
    #index.techPolished #drills .card{padding-right:42px}
    #index.techPolished #drills .card small{margin-top:5px;font-size:10px;line-height:1.45;color:#667381;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
    #index.techPolished #drills .card .meta{margin-top:9px;gap:5px}
    #index.techPolished #drills .card .mini{background:#F2F5F7;color:#667381;padding:5px 7px;font-size:9px;font-weight:700}
    @media(min-width:700px){
      #index.techPolished #positions,#index.techPolished #drillCategories{margin-right:0;padding-right:0}
      #index.techPolished #techniques,#index.techPolished #drills{grid-template-columns:repeat(2,minmax(0,1fr))}
    }
  `;
  document.head.appendChild(style);
}

function ensureHeader(index) {
  let header = index.querySelector('#techLibraryHeader');
  if (header) return header;
  const switcher = index.querySelector('.catalogSwitch');
  if (!switcher) return null;
  header = document.createElement('header');
  header.id = 'techLibraryHeader';
  header.innerHTML = '<small>TECHNIQUE LIBRARY</small><h1>기술 라이브러리</h1><p>포지션에서 시작해 필요한 기술과 혼자 할 수 있는 드릴을 빠르게 찾아보세요.</p>';
  switcher.before(header);
  return header;
}

function ensureResultHead(list, id, label) {
  if (!list) return null;
  let head = document.getElementById(id);
  if (!head) {
    head = document.createElement('div');
    head.id = id;
    head.className = 'catalogResultHead';
    head.innerHTML = `<b>${label}</b><span class="catalogResultCount">0개</span>`;
    list.before(head);
  }
  return head;
}

function decorateTechniqueCards() {
  document.querySelectorAll('#techniques .card').forEach(card => {
    if (card.dataset.techPolished === '1') return;
    const small = card.querySelector('small');
    if (small) {
      const raw = small.textContent || '';
      const parts = raw.split('·').map(x => x.trim()).filter(Boolean);
      const action = actionLabel(parts.shift());
      const route = parts.join(' · ') || '진입 경로';
      small.innerHTML = `<span class="techActionBadge">${action}</span><span class="techRouteText">${route}</span>`;
    }
    card.dataset.techPolished = '1';
  });
}

function decorateDrillCards() {
  document.querySelectorAll('#drills .card').forEach(card => {
    card.dataset.drillPolished = '1';
  });
}

function refreshCounts() {
  const techCount = document.querySelectorAll('#techniques .card').length;
  const drillCount = document.querySelectorAll('#drills .card').length;
  const techHead = document.querySelector('#techResultHead .catalogResultCount');
  const drillHead = document.querySelector('#drillResultHead .catalogResultCount');
  if (techHead) techHead.textContent = `${techCount}개`;
  if (drillHead) drillHead.textContent = `${drillCount}개`;
}

function polishRenderedLists() {
  decorateTechniqueCards();
  decorateDrillCards();
  refreshCounts();
}

function enhanceTech() {
  const index = document.getElementById('index');
  if (!index || !window.__BJJ_MOBILE_SHELL__) return false;
  const switcher = index.querySelector('.catalogSwitch');
  const techCatalog = index.querySelector('#techCatalog');
  const drillCatalog = index.querySelector('#drillCatalog');
  const techList = index.querySelector('#techniques');
  const drillList = index.querySelector('#drills');
  if (!switcher || !techCatalog || !drillCatalog || !techList || !drillList) return false;

  addStyles();
  index.classList.add('techPolished');
  ensureHeader(index);

  const techTitle = techCatalog.querySelector(':scope > h2');
  const techHint = techCatalog.querySelector(':scope > .hint');
  if (techTitle) techTitle.textContent = '시작 포지션';
  if (techHint) techHint.textContent = '포지션을 고르면 그 위치에서 바로 쓸 수 있는 기술만 보여줘요.';
  const drillTitle = drillCatalog.querySelector(':scope > h2');
  const drillHint = drillCatalog.querySelector(':scope > .hint');
  if (drillTitle) drillTitle.textContent = '드릴 종류';
  if (drillHint) drillHint.textContent = '파트너 없이 반복할 움직임을 목적별로 골라보세요.';

  ensureResultHead(techList, 'techResultHead', '기술');
  ensureResultHead(drillList, 'drillResultHead', '드릴');
  polishRenderedLists();

  if (index.dataset.techPolishBound !== '1') {
    const observer = new MutationObserver(polishRenderedLists);
    observer.observe(techList, { childList: true, subtree: true });
    observer.observe(drillList, { childList: true, subtree: true });
    index.dataset.techPolishBound = '1';
  }

  window.__BJJ_TECH_POLISH__ = { version: 'v0.1' };
  return true;
}

let attempts = 0;
const timer = setInterval(() => {
  attempts += 1;
  if (enhanceTech() || attempts >= 400) clearInterval(timer);
}, 25);

document.addEventListener('visibilitychange', () => {
  if (!document.hidden) enhanceTech();
});
