import { TRAINING_GUIDES, getTrainingGuide } from './training-guides-v0.1.mjs';

const STYLE_ID = 'mobile-training-guide-style';
const SHELL_ID = 'trainingGuideShell';
let activeGuideId = null;
let view = 'list';

function addStyles() {
  if (document.getElementById(STYLE_ID)) return;
  const style = document.createElement('style');
  style.id = STYLE_ID;
  style.textContent = `
    #homeTrainingGuideTitle{margin-top:22px}
    #homeTrainingGuideCard{width:100%;border:0;border-radius:18px;background:linear-gradient(135deg,#EEF3F7,#F7F9FB);padding:14px 15px;display:flex;align-items:center;gap:12px;text-align:left;color:#1A232D;box-shadow:0 3px 12px rgba(20,35,50,.045)}
    #homeTrainingGuideCard .guideHomeIcon{width:42px;height:42px;flex:0 0 auto;border-radius:13px;background:#40556A;color:#fff;display:grid;place-items:center;font-size:17px;font-weight:900}
    #homeTrainingGuideCard .guideHomeText{min-width:0;flex:1}
    #homeTrainingGuideCard small{display:block;font-size:9px;font-weight:900;letter-spacing:.06em;color:#8498A8}
    #homeTrainingGuideCard b{display:block;margin-top:3px;font-size:13px;color:#1C2B44}
    #homeTrainingGuideCard p{margin:3px 0 0;font-size:10px;line-height:1.45;color:#667381}
    #homeTrainingGuideCard .guideHomeArrow{font-size:17px;color:#8498A8}
    #trainingGuideShell{padding-bottom:18px}
    .guideTopBar{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:13px}
    .guideBack{border:0;background:transparent;padding:5px 0;color:#1C2B44;font-size:12px;font-weight:900}
    .guideTopMeta{font-size:9px;font-weight:900;letter-spacing:.08em;color:#8498A8}
    .guideHeader{margin:0 0 14px}
    .guideHeader small{font-size:9px;font-weight:900;letter-spacing:.08em;color:#8498A8}
    .guideHeader h1{margin:5px 0 0;font-size:24px;line-height:1.2;letter-spacing:-.045em;color:#1C2B44}
    .guideHeader p{font-size:11px;line-height:1.6;color:#667381;margin:7px 0 0}
    .guidePilotCard{width:100%;border:0;background:#fff;border-radius:18px;padding:15px;text-align:left;color:#1A232D;box-shadow:0 4px 16px rgba(20,35,50,.055)}
    .guidePilotCard .guidePills{display:flex;gap:5px;flex-wrap:wrap;margin-bottom:9px}
    .guidePill{border-radius:999px;padding:5px 7px;background:#EEF3F7;color:#40556A;font-size:8px;font-weight:900}
    .guidePilotCard b{display:block;font-size:14px;color:#1C2B44}
    .guidePilotCard p{font-size:11px;line-height:1.55;color:#667381;margin:6px 0 0}
    .guidePilotCard .guideOpen{display:block;margin-top:11px;font-size:10px;font-weight:900;color:#40556A}
    .guideHero{background:#1C2B44;color:#fff;border-radius:20px;padding:17px;margin:0 0 15px}
    .guideHero small{font-size:9px;font-weight:900;letter-spacing:.08em;opacity:.65}
    .guideHero h2{font-size:18px;line-height:1.3;margin:6px 0}
    .guideHero p{font-size:11px;line-height:1.55;margin:0;opacity:.8}
    .guideHero .guideHeroTags{display:flex;gap:5px;flex-wrap:wrap;margin-top:11px}
    .guideHero .guideHeroTags span{font-size:8px;font-weight:900;padding:5px 7px;border-radius:999px;background:rgba(255,255,255,.12)}
    .guideSectionTitle{display:flex;align-items:end;justify-content:space-between;margin:20px 0 9px}
    .guideSectionTitle h2{font-size:16px;margin:0;color:#1C2B44}
    .guideSectionTitle span{font-size:9px;color:#8498A8}
    .guidePrinciples{display:grid;gap:7px}
    .guidePrinciple{display:grid;grid-template-columns:25px 1fr;gap:9px;background:#F2F5F7;border-radius:13px;padding:10px 11px}
    .guidePrinciple i{font-style:normal;width:25px;height:25px;border-radius:8px;background:#DCE5EB;color:#40556A;display:grid;place-items:center;font-size:9px;font-weight:900}
    .guidePrinciple p{font-size:10px;line-height:1.5;color:#536170;margin:0}
    .hairOptionList{display:grid;gap:12px}
    .hairOption{border:1px solid #E3E8EC;border-radius:18px;background:#fff;padding:14px}
    .hairOption.current{border-color:#9DAFBC;box-shadow:0 4px 16px rgba(20,35,50,.05)}
    .hairOptionHead{display:grid;grid-template-columns:42px 1fr;gap:11px;align-items:center}
    .hairOptionMarker{width:42px;height:42px;border-radius:13px;background:#EEF3F7;color:#40556A;display:grid;place-items:center;font-size:10px;font-weight:900}
    .hairOption.current .hairOptionMarker{background:#1C2B44;color:#fff}
    .hairOptionHead small{display:block;font-size:8px;font-weight:900;color:#8498A8;letter-spacing:.04em}
    .hairOptionHead b{display:block;margin-top:3px;font-size:13px;color:#1C2B44}
    .hairOptionHead p{font-size:9px;line-height:1.45;color:#667381;margin:3px 0 0}
    .hairMethod{margin:12px 0 0;padding-top:11px;border-top:1px solid #E8ECEF}
    .hairMethod strong{font-size:11px;color:#1C2B44}
    .hairWhy{font-size:10px;line-height:1.55;color:#667381;margin:5px 0 10px}
    .hairSteps{display:grid;gap:9px}
    .hairStep{display:grid;grid-template-columns:1fr;gap:8px;align-items:start;background:#F7F8FA;border-radius:14px;padding:8px;overflow:hidden}
    .hairStepImage{display:block;width:100%;height:auto;object-fit:contain;border-radius:10px;background:#EEF3F7}
    .hairStepCopy{display:grid;grid-template-columns:24px 1fr;gap:7px;align-items:start;min-width:0}
    .hairStepCopy span{width:24px;height:24px;border-radius:8px;background:#1C2B44;color:#fff;display:grid;place-items:center;font-size:9px;font-weight:900}
    .hairStepCopy p{font-size:10px;line-height:1.5;margin:2px 0 0;color:#536170;word-break:keep-all}
    .hairFallback{margin:10px 0 0;border-radius:11px;background:#F7F8FA;padding:9px 10px;font-size:9px;line-height:1.5;color:#667381}
    .guideSafety{background:#FFF8EB;border-radius:16px;padding:13px}
    .guideSafety h3{font-size:12px;margin:0;color:#6D5125}
    .guideSafety p{font-size:10px;line-height:1.55;color:#7D6848;margin:5px 0 0}
    .guideEquipment{display:grid;gap:8px;margin-top:10px}
    .guideEquipmentRow{background:#fff;border-radius:12px;padding:10px}
    .guideEquipmentRow b{font-size:10px;color:#1C2B44}
    .guideEquipmentRow p{font-size:9px;line-height:1.5;color:#667381;margin:4px 0 0}
    .guideCompetitionNote{font-size:9px;line-height:1.55;color:#8498A8;margin:13px 2px 0}
    @media(max-width:350px){.hairStepCopy{grid-template-columns:22px 1fr;gap:6px}.hairStepCopy span{width:22px;height:22px}}
    @media(min-width:700px){#trainingGuideShell{max-width:760px;margin:0 auto}.hairOptionList{grid-template-columns:repeat(3,1fr)}.hairStepCopy{margin-top:1px}}
  `;
  document.head.appendChild(style);
}

function escapeHtml(text) {
  return String(text).replace(/[&<>'"]/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[char]));
}

function ensureShell() {
  const main = document.querySelector('main');
  if (!main) return null;
  let shell = document.getElementById(SHELL_ID);
  if (!shell) {
    shell = document.createElement('section');
    shell.id = SHELL_ID;
    shell.className = 'shellPanel';
    main.append(shell);
  }
  return shell;
}

function activateGuideShell() {
  const mobileShell = window.__BJJ_MOBILE_SHELL__;
  if (!mobileShell?.show) return false;
  mobileShell.show('home');
  const home = document.getElementById('homeShell');
  const guideShell = ensureShell();
  if (!home || !guideShell) return false;
  home.classList.remove('active');
  guideShell.classList.add('active');
  return true;
}

function renderHomeEntry() {
  const home = document.getElementById('homeShell');
  const activity = document.getElementById('activityAnchor');
  if (!home || !activity) return false;
  if (document.getElementById('homeTrainingGuideCard')) return true;

  const title = document.createElement('div');
  title.id = 'homeTrainingGuideTitle';
  title.className = 'shellTitle';
  title.innerHTML = `<h2>수련 가이드</h2><span>${TRAINING_GUIDES.length}개 · PILOT</span>`;

  const card = document.createElement('button');
  card.id = 'homeTrainingGuideCard';
  card.type = 'button';
  card.innerHTML = '<span class="guideHomeIcon">≈</span><span class="guideHomeText"><small>MAT READY</small><b>머리 정리 · 2분 준비</b><p>짧은 머리부터 길이별 묶는 법과 롤링 전 안전 체크</p></span><span class="guideHomeArrow">›</span>';
  card.addEventListener('click', openList);
  activity.before(title, card);
  return true;
}

function renderList() {
  const shell = ensureShell();
  if (!shell) return;
  view = 'list';
  activeGuideId = null;
  shell.dataset.guideView = 'list';
  shell.innerHTML = `
    <div class="guideTopBar"><button type="button" class="guideBack" id="trainingGuideHomeBack">← 홈</button><span class="guideTopMeta">TRAINING GUIDE</span></div>
    <header class="guideHeader"><small>MAT READY</small><h1>수련 가이드</h1><p>기술 외에 실제 수련을 덜 방해받고 더 편하게 이어가기 위한 작은 준비법을 모읍니다.</p></header>
    <div class="guidePilotList">${TRAINING_GUIDES.map((guide) => `<button type="button" class="guidePilotCard" data-training-guide="${guide.id}"><span class="guidePills">${guide.tags.map((tag) => `<span class="guidePill">${escapeHtml(tag)}</span>`).join('')}</span><b>${escapeHtml(guide.title)}</b><p>${escapeHtml(guide.summary)}</p><span class="guideOpen">${escapeHtml(guide.duration)} · 열어보기 →</span></button>`).join('')}</div>
  `;
  shell.querySelector('#trainingGuideHomeBack')?.addEventListener('click', closeToHome);
  shell.querySelectorAll('[data-training-guide]').forEach((button) => button.addEventListener('click', () => openDetail(button.dataset.trainingGuide)));
}

function equipmentRow(title, items) {
  return `<div class="guideEquipmentRow"><b>${escapeHtml(title)}</b><p>${items.map(escapeHtml).join(' · ')}</p></div>`;
}

function illustrationFor(option, index) {
  return option.illustrations?.[index] || null;
}

function renderHairStep(option, step, index) {
  const illustration = illustrationFor(option, index);
  const image = illustration
    ? `<img class="hairStepImage" src="${escapeHtml(illustration.src)}" alt="${escapeHtml(illustration.alt)}" decoding="async">`
    : '';
  return `<div class="hairStep" data-hair-step="${index + 1}">${image}<div class="hairStepCopy"><span>${index + 1}</span><p>${escapeHtml(step)}</p></div></div>`;
}

function renderDetail(guide) {
  const shell = ensureShell();
  if (!shell || !guide) return;
  view = 'detail';
  activeGuideId = guide.id;
  shell.dataset.guideView = 'detail';
  shell.innerHTML = `
    <div class="guideTopBar"><button type="button" class="guideBack" id="trainingGuideListBack">← 수련 가이드</button><span class="guideTopMeta">${escapeHtml(guide.eyebrow)}</span></div>
    <header class="guideHeader"><small>${escapeHtml(guide.eyebrow)}</small><h1>${escapeHtml(guide.title)}</h1><p>${escapeHtml(guide.summary)}</p></header>
    <div class="guideHero"><small>오늘 바로 적용</small><h2>짧은 머리는 한 번에 묶지 말고<br>앞·옆부터 나눠 잡기</h2><p>낮은 포니테일이 짧고 층이 빠진다면 먼저 2단 분할 포니를 시험합니다. 단단한 집게는 수업 전후 정리에만 쓰고 라이브 롤링 전에는 빼는 쪽을 기본으로 둡니다.</p><div class="guideHeroTags">${guide.tags.map((tag) => `<span>${escapeHtml(tag)}</span>`).join('')}</div></div>
    <div class="guideSectionTitle"><h2>먼저 기억할 것</h2><span>4개</span></div>
    <div class="guidePrinciples">${guide.principles.map((text, index) => `<div class="guidePrinciple"><i>${index + 1}</i><p>${escapeHtml(text)}</p></div>`).join('')}</div>
    <div class="guideSectionTitle"><h2>길이별 묶는 법</h2><span>그림으로 단계 확인</span></div>
    <div class="hairOptionList">${guide.options.map((option, optionIndex) => `<article class="hairOption${optionIndex === 0 ? ' current' : ''}" data-hair-option="${option.id}"><div class="hairOptionHead"><div class="hairOptionMarker">${String(optionIndex + 1).padStart(2, '0')}</div><div><small>${escapeHtml(option.badge)}</small><b>${escapeHtml(option.label)}</b><p>${escapeHtml(option.range)}</p></div></div><div class="hairMethod"><strong>${escapeHtml(option.method)}</strong><p class="hairWhy">${escapeHtml(option.why)}</p><div class="hairSteps">${option.steps.map((step, index) => renderHairStep(option, step, index)).join('')}</div><p class="hairFallback">대안 · ${escapeHtml(option.fallback)}</p></div></article>`).join('')}</div>
    <div class="guideSectionTitle"><h2>집게핀은 언제?</h2><span>롤링 전 체크</span></div>
    <div class="guideSafety"><h3>플랫·유연 집게도 ‘눕기 편함’과 ‘롤링 안전’은 다릅니다.</h3><p>워밍업 전 이동이나 수업 전후 정리에는 쓸 수 있지만, 라이브 롤링에서는 빠지거나 눌릴 수 있는 단단한 부품을 남기지 않는 쪽을 기본으로 권합니다.</p><div class="guideEquipment">${equipmentRow('추천', guide.equipment.recommended)}${equipmentRow('매트 밖에서만', guide.equipment.offMatOnly)}${equipmentRow('롤링 중 피하기', guide.equipment.avoidOnMat)}</div></div>
    <p class="guideCompetitionNote">${escapeHtml(guide.competitionNote)}</p>
  `;
  shell.querySelector('#trainingGuideListBack')?.addEventListener('click', openList);
}

function openList() {
  if (!activateGuideShell()) return false;
  renderList();
  window.scrollTo({ top: 0, behavior: 'instant' });
  return true;
}

function openDetail(id) {
  const guide = getTrainingGuide(id);
  if (!guide || !activateGuideShell()) return false;
  renderDetail(guide);
  window.scrollTo({ top: 0, behavior: 'instant' });
  return true;
}

function closeToHome() {
  window.__BJJ_MOBILE_SHELL__?.show?.('home');
  activeGuideId = null;
  view = 'list';
  return true;
}

function back() {
  const shell = document.getElementById(SHELL_ID);
  if (!shell?.classList.contains('active')) return false;
  if (view === 'detail') return openList();
  return closeToHome();
}

function enhance() {
  if (!window.__BJJ_MOBILE_SHELL__ || !document.getElementById('homeShell')) return false;
  addStyles();
  ensureShell();
  renderHomeEntry();
  window.__BJJ_TRAINING_GUIDE__ = {
    version: 'v0.3',
    guides: TRAINING_GUIDES.length,
    openList,
    openDetail,
    back,
    get state() { return { view, activeGuideId }; },
  };
  return true;
}

let attempts = 0;
const timer = setInterval(() => {
  attempts += 1;
  if (enhance() || attempts >= 400) clearInterval(timer);
}, 25);

document.addEventListener('visibilitychange', () => {
  if (!document.hidden) enhance();
});
