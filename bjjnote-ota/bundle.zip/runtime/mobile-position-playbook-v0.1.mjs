import { ARRIVAL_PLAYBOOK_LINKS, getPositionPlaybook } from './position-playbooks-v0.1.mjs';

let shell = null;
let activePlaybook = null;
let selectedReactionId = null;
let origin = { kind: 'tech', positionId: 'top-side-control' };

function addStyles() {
  if (document.getElementById('mobile-position-playbook-style')) return;
  const style = document.createElement('style');
  style.id = 'mobile-position-playbook-style';
  style.textContent = `
    #positionPlaybookShell{padding-bottom:18px}
    .playbookBack{border:0;background:transparent;padding:0;color:#1C2B44;font-size:12px;font-weight:850;margin:0 0 15px}
    .playbookHero small{display:block;color:#8498A8;font-size:9px;font-weight:900;letter-spacing:.14em}
    .playbookHero h1{margin:6px 0 2px;color:#1C2B44;font-size:27px;line-height:1.12;letter-spacing:-.045em}
    .playbookHero b{display:block;color:#40556A;font-size:14px;margin-top:6px}
    .playbookHero p{margin:5px 0 0;color:#667381;font-size:11px;line-height:1.55}
    .playbookMap{position:relative;display:grid;grid-template-columns:1.2fr .8fr;gap:8px;align-items:center;margin:18px 0 12px;padding:17px;border:1px solid #E3E8EC;border-radius:18px;background:#fff;overflow:hidden}
    .playbookMap::before{content:'';position:absolute;left:34%;top:50%;width:42%;height:1px;background:repeating-linear-gradient(90deg,#BCC7D0 0 5px,transparent 5px 10px)}
    .playbookMapOrigin{position:relative;z-index:1;border-radius:12px;background:#1C2B44;color:#fff;padding:13px 12px;font-size:11px;font-weight:850;text-align:center;box-shadow:0 4px 12px rgba(28,43,68,.12)}
    .playbookMapChoices{position:relative;z-index:1;display:grid;gap:6px}.playbookMapChoices span{display:flex;align-items:center;justify-content:center;min-height:34px;border-radius:11px;background:#F2F5F7;color:#40556A;font-size:10px;font-weight:800}
    .playbookArrival{margin-top:10px;border:1px solid #E3E8EC;border-radius:18px;background:#fff;padding:15px}
    .playbookArrivalHead{display:flex;align-items:flex-start;justify-content:space-between;gap:12px}.playbookArrivalHead b{color:#1C2B44;font-size:14px}.playbookArrivalHead p{margin:4px 0 0;color:#667381;font-size:10px}.playbookTimer{flex:0 0 auto;border-radius:999px;background:#EEF3F7;color:#40556A;padding:6px 8px;font-size:10px;font-weight:850}
    .playbookCueList{display:grid;gap:9px;margin-top:13px}.playbookCue{display:grid;grid-template-columns:22px 1fr;gap:8px;align-items:center;color:#40556A;font-size:11px}.playbookCue i{font-style:normal;width:22px;height:22px;border-radius:50%;display:grid;place-items:center;background:#1C2B44;color:#fff;font-size:9px;font-weight:900}
    .playbookSectionTitle{margin:23px 0 9px}.playbookSectionTitle h2{margin:0;color:#1C2B44;font-size:17px;letter-spacing:-.03em}.playbookSectionTitle p{margin:4px 0 0;color:#8498A8;font-size:10px;line-height:1.5}
    .playbookReactionRail{display:flex;gap:7px;overflow-x:auto;margin-right:-20px;padding:0 20px 7px 0;scrollbar-width:none;-webkit-overflow-scrolling:touch}.playbookReactionRail::-webkit-scrollbar{display:none}
    .playbookReactionRail button{flex:0 0 auto;min-height:38px;border:1px solid #E3E8EC;border-radius:999px;background:#fff;padding:9px 12px;color:#667381;font-size:10px;font-weight:800;white-space:nowrap}.playbookReactionRail button.active{background:#1C2B44;border-color:#1C2B44;color:#fff}
    .playbookReactionEmpty{border:1px dashed #C8D1D8;border-radius:16px;padding:17px;text-align:center;color:#8498A8;font-size:10px;line-height:1.55}
    .playbookReactionSummary{border:1px solid #E3E8EC;border-radius:16px;padding:13px 14px;background:#fff}.playbookReactionSummary small{display:block;color:#8498A8;font-size:9px;font-weight:850}.playbookReactionSummary b{display:block;margin-top:4px;color:#1C2B44;font-size:13px}.playbookReactionSummary p{margin:5px 0 0;color:#667381;font-size:10px;line-height:1.55}
    .playbookPrimary{position:relative;margin-top:10px;border:0;border-radius:20px;background:#1C2B44;color:#fff;padding:17px;text-align:left;overflow:hidden}.playbookPrimary::after{content:'→';position:absolute;right:16px;bottom:15px;width:30px;height:30px;border-radius:50%;display:grid;place-items:center;background:rgba(255,255,255,.12);font-size:15px}.playbookPrimary small{display:block;font-size:9px;font-weight:850;opacity:.66}.playbookPrimary b{display:block;margin-top:6px;font-size:22px;letter-spacing:-.04em}.playbookPrimary p{margin:6px 38px 0 0;font-size:11px;line-height:1.55;opacity:.8}.playbookPrimary[data-kind="stabilize"]::after{content:'✓'}.playbookPrimary[data-kind="stabilize"]{cursor:default}
    .playbookBranches{display:grid;gap:8px;margin-top:9px}.playbookBranch{width:100%;border:1px solid #E3E8EC;border-radius:14px;background:#fff;padding:12px 38px 12px 13px;text-align:left;position:relative;color:#1C2B44}.playbookBranch::after{content:'›';position:absolute;right:14px;top:50%;transform:translateY(-50%);color:#A3AFB9;font-size:20px}.playbookBranch small{display:block;color:#8498A8;font-size:9px;font-weight:800}.playbookBranch b{display:block;margin-top:4px;font-size:11px}
    .playbookFooterPath{margin-top:16px;border-radius:13px;background:#F2F5F7;padding:10px;text-align:center;color:#8498A8;font-size:9px;font-weight:750;letter-spacing:.02em}
    .arrivalPlaybookWrap{margin-top:24px}.arrivalPlaybookCard{width:100%;border:0;border-radius:20px;background:#1C2B44;color:#fff;padding:17px;text-align:left;position:relative;overflow:hidden}.arrivalPlaybookCard::after{content:'→';position:absolute;right:17px;bottom:17px;width:32px;height:32px;border-radius:50%;display:grid;place-items:center;background:rgba(255,255,255,.12);font-size:17px}.arrivalPlaybookCard small{display:block;font-size:9px;font-weight:850;opacity:.65}.arrivalPlaybookCard b{display:block;margin-top:6px;font-size:20px;letter-spacing:-.035em}.arrivalPlaybookCard p{margin:6px 44px 0 0;font-size:10px;line-height:1.55;opacity:.78}.arrivalPlaybookCard strong{display:block;margin-top:12px;font-size:12px}
    .positionPlaybookTeaser{width:100%;border:0;border-radius:17px;background:#EEF3F7;color:#1C2B44;padding:14px 42px 14px 14px;text-align:left;position:relative;margin:8px 0 2px}.positionPlaybookTeaser::after{content:'›';position:absolute;right:15px;top:50%;transform:translateY(-50%);color:#8498A8;font-size:22px}.positionPlaybookTeaser small{display:block;color:#8498A8;font-size:8px;font-weight:900;letter-spacing:.11em}.positionPlaybookTeaser b{display:block;margin-top:5px;font-size:14px}.positionPlaybookTeaser span{display:block;margin-top:4px;color:#667381;font-size:9px}
    @media(min-width:700px){#positionPlaybookShell{max-width:820px;margin:0 auto}.playbookReactionRail{margin-right:0;padding-right:0}.playbookMap{grid-template-columns:1fr 1fr}.playbookBranches{grid-template-columns:repeat(2,minmax(0,1fr))}}
  `;
  document.head.appendChild(style);
}

function escapeHtml(text) {
  return String(text ?? '').replace(/[&<>'"]/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', "'":'&#39;', '"':'&quot;' }[c]));
}

function setBottomActive(tab) {
  document.querySelectorAll('.bottom button[data-shell-tab]').forEach(btn => btn.classList.toggle('active', btn.dataset.shellTab === tab));
}

function hideAllPanels() {
  document.querySelectorAll('.panel,.shellPanel').forEach(el => el.classList.remove('active'));
}

function ensureShell() {
  if (shell?.isConnected) return shell;
  const main = document.querySelector('main');
  if (!main) return null;
  shell = document.getElementById('positionPlaybookShell');
  if (!shell) {
    shell = document.createElement('section');
    shell.id = 'positionPlaybookShell';
    shell.className = 'shellPanel';
    main.appendChild(shell);
  }
  return shell;
}

function actionButton(action, className, extra = '') {
  if (!action) return '';
  const attrs = [
    `class="${className}"`,
    `data-kind="${escapeHtml(action.kind)}"`,
    action.techniqueId ? `data-technique-id="${escapeHtml(action.techniqueId)}"` : '',
    action.entryRouteId ? `data-entry-route-id="${escapeHtml(action.entryRouteId)}"` : '',
    action.positionId ? `data-position-id="${escapeHtml(action.positionId)}"` : '',
  ].filter(Boolean).join(' ');
  return `<button ${attrs}${action.kind === 'stabilize' ? ' disabled' : ''}>${extra}</button>`;
}

function renderPlaybook() {
  if (!shell || !activePlaybook) return;
  const p = activePlaybook;
  const reaction = p.reactions.find(x => x.id === selectedReactionId) || null;
  const primary = reaction?.primary || null;
  shell.innerHTML = `
    <button class="playbookBack" id="positionPlaybookBack">← 돌아가기</button>
    <header class="playbookHero">
      <small>${escapeHtml(p.eyebrow)}</small>
      <h1>${escapeHtml(p.title)}</h1>
      <b>${escapeHtml(p.nameKo)}</b>
      <p>${escapeHtml(p.summary)}</p>
    </header>
    <div class="playbookMap">
      <div class="playbookMapOrigin">${escapeHtml(p.nameKo)}</div>
      <div class="playbookMapChoices">${p.overview.map(x => `<span>${escapeHtml(x.label)}</span>`).join('')}</div>
    </div>
    <section class="playbookArrival">
      <div class="playbookArrivalHead"><div><b>지금 여기 도착했다면</b><p>${escapeHtml(p.arrival.title)}</p></div><span class="playbookTimer">◷ ${p.arrival.seconds}초</span></div>
      <div class="playbookCueList">${p.arrival.cues.map((cue, i) => `<div class="playbookCue"><i>${i + 1}</i><span>${escapeHtml(cue)}</span></div>`).join('')}</div>
    </section>
    <div class="playbookSectionTitle"><h2>상대가 지금 뭘 하고 있나요?</h2><p>가장 가까운 반응 하나를 골라 다음 선택을 확인하세요.</p></div>
    <div class="playbookReactionRail">${p.reactions.map(r => `<button class="${r.id === selectedReactionId ? 'active' : ''}" data-playbook-reaction="${escapeHtml(r.id)}">${escapeHtml(r.label)}</button>`).join('')}</div>
    ${reaction ? `
      <section class="playbookReactionSummary"><small>상대 반응</small><b>${escapeHtml(reaction.opponent)}</b><p>${escapeHtml(reaction.insight)}</p></section>
      ${actionButton(primary, 'playbookPrimary', `<small>내 첫 선택</small><b>${escapeHtml(primary.label)}</b><p>${escapeHtml(primary.description)}</p>`)}
      ${reaction.branches?.length ? `<div class="playbookSectionTitle"><h2>막히면 다음 선택</h2><p>첫 선택이 막혔을 때만 다음 분기로 넘어갑니다.</p></div><div class="playbookBranches">${reaction.branches.map(branch => actionButton(branch, 'playbookBranch', `<small>${escapeHtml(branch.when)}</small><b>→ ${escapeHtml(branch.label)}</b>`)).join('')}</div>` : ''}
    ` : '<div class="playbookReactionEmpty">상대 반응을 하나 고르면<br>내 첫 선택과 다음 연결을 보여줍니다.</div>'}
    <div class="playbookFooterPath">기술 → 도착 포지션 → 상대 반응 → 다음 선택</div>
  `;
  shell.querySelector('#positionPlaybookBack')?.addEventListener('click', closePlaybook);
  shell.querySelectorAll('[data-playbook-reaction]').forEach(btn => btn.addEventListener('click', () => {
    selectedReactionId = btn.dataset.playbookReaction;
    renderPlaybook();
    const title = shell.querySelector('.playbookSectionTitle');
    title?.scrollIntoView({ block: 'start', behavior: 'smooth' });
  }));
  shell.querySelectorAll('.playbookPrimary:not([disabled]),.playbookBranch').forEach(btn => btn.addEventListener('click', () => runAction({
    kind: btn.dataset.kind,
    techniqueId: btn.dataset.techniqueId || null,
    entryRouteId: btn.dataset.entryRouteId || null,
    positionId: btn.dataset.positionId || null,
  })));
}

function runAction(action) {
  if (!action?.kind) return;
  if (action.kind === 'technique' && action.techniqueId) {
    window.__BJJ_MOBILE_SHELL__?.show?.('tech');
    queueMicrotask(() => window.__recovery?.openTechnique?.({
      techniqueId: action.techniqueId,
      selectedEntryRouteId: action.entryRouteId || null,
    }));
    return;
  }
  if (action.kind === 'position' && action.positionId) {
    window.__BJJ_MOBILE_SHELL__?.show?.('tech');
    queueMicrotask(() => document.querySelector(`#positions button[data-id="${action.positionId}"]`)?.click());
  }
}

function openPlaybook(idOrPositionId, nextOrigin = null) {
  const playbook = getPositionPlaybook(idOrPositionId);
  const root = ensureShell();
  if (!playbook || !root) return false;
  activePlaybook = playbook;
  selectedReactionId = null;
  if (nextOrigin) origin = nextOrigin;
  hideAllPanels();
  renderPlaybook();
  root.classList.add('active');
  setBottomActive('flow');
  window.scrollTo({ top: 0, behavior: 'instant' });
  return true;
}

function closePlaybook() {
  if (!shell?.classList.contains('active')) return false;
  shell.classList.remove('active');
  if (origin.kind === 'detail' && document.getElementById('detail')) {
    hideAllPanels();
    document.getElementById('detail').classList.add('active');
    setBottomActive('tech');
    window.scrollTo({ top: Math.max(0, origin.scrollY || 0), behavior: 'instant' });
    return true;
  }
  window.__BJJ_MOBILE_SHELL__?.show?.('tech');
  const positionId = origin.positionId || activePlaybook?.positionId;
  if (positionId) queueMicrotask(() => document.querySelector(`#positions button[data-id="${positionId}"]`)?.click());
  return true;
}

function currentDetailTechniqueId() {
  const context = document.querySelector('#detail.active #detailRoot .context');
  if (!context) return null;
  const known = Object.keys(ARRIVAL_PLAYBOOK_LINKS);
  const bold = [...context.querySelectorAll('b')].map(x => x.textContent?.trim()).filter(Boolean);
  return bold.find(x => known.includes(x)) || null;
}

function decorateDetailArrival() {
  const root = document.getElementById('detailRoot');
  if (!root) return;
  const techniqueId = currentDetailTechniqueId();
  const link = techniqueId ? ARRIVAL_PLAYBOOK_LINKS[techniqueId] : null;
  const existing = root.querySelector('.arrivalPlaybookWrap');
  if (!link) {
    existing?.remove();
    return;
  }
  if (existing?.dataset.arrivalTechnique === techniqueId) return;
  existing?.remove();
  const wrap = document.createElement('div');
  wrap.className = 'arrivalPlaybookWrap';
  wrap.dataset.arrivalTechnique = techniqueId;
  wrap.innerHTML = `<button class="arrivalPlaybookCard" data-arrival-playbook="${escapeHtml(link.playbookId)}"><small>도착 위치</small><b>${escapeHtml(link.label)}</b><p>기술을 성공했다면 공격을 서두르기 전에 포지션을 안정시키고 다음 선택을 확인하세요.</p><strong>여기서 뭘 하지?</strong></button>`;
  root.appendChild(wrap);
  wrap.querySelector('[data-arrival-playbook]')?.addEventListener('click', btn => {
    openPlaybook(btn.currentTarget.dataset.arrivalPlaybook, { kind: 'detail', scrollY: window.scrollY });
  });
}

function ensureIndexTeaser() {
  const catalog = document.getElementById('techCatalog');
  const positions = document.getElementById('positions');
  if (!catalog || !positions) return;
  let teaser = document.getElementById('positionPlaybookTeaser');
  const activePosition = positions.querySelector('button.active')?.dataset.id || null;
  if (activePosition !== 'top-side-control') {
    teaser?.remove();
    return;
  }
  if (!teaser) {
    teaser = document.createElement('button');
    teaser.id = 'positionPlaybookTeaser';
    teaser.className = 'positionPlaybookTeaser';
    teaser.innerHTML = '<small>POSITION PLAYBOOK</small><b>탑 사이드에서 뭘 하지?</b><span>3초 안정 → 상대 반응 → 다음 공격</span>';
    const head = document.getElementById('techResultHead');
    if (head) head.before(teaser); else positions.after(teaser);
    teaser.addEventListener('click', () => openPlaybook('top-side-control', { kind: 'tech', positionId: 'top-side-control' }));
  }
}

function init() {
  if (!window.__BJJ_MOBILE_SHELL__ || !window.__recovery) return false;
  addStyles();
  ensureShell();
  const detailRoot = document.getElementById('detailRoot');
  const positions = document.getElementById('positions');
  if (!detailRoot || !positions) return false;

  const detailObserver = new MutationObserver(() => queueMicrotask(decorateDetailArrival));
  detailObserver.observe(detailRoot, { childList: true });
  const positionObserver = new MutationObserver(() => queueMicrotask(ensureIndexTeaser));
  positionObserver.observe(positions, { childList: true, subtree: true, attributes: true, attributeFilter: ['class'] });
  document.addEventListener('click', event => {
    if (event.target.closest?.('#positions button')) queueMicrotask(ensureIndexTeaser);
  }, true);

  decorateDetailArrival();
  ensureIndexTeaser();
  window.__BJJ_POSITION_PLAYBOOK__ = {
    version: 'v0.1',
    open: openPlaybook,
    close: closePlaybook,
    isActive: () => Boolean(shell?.classList.contains('active')),
    activeId: () => activePlaybook?.id || null,
  };
  return true;
}

let attempts = 0;
const timer = setInterval(() => {
  attempts += 1;
  if (init() || attempts >= 400) clearInterval(timer);
}, 25);
