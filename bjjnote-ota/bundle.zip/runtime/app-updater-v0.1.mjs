import { isUpdateAvailable, validateUpdateManifest } from './app-update-core-v0.1.mjs';

const DEFAULT_MANIFEST_URL = 'https://raw.githubusercontent.com/hyunahch/dc_reports/main/bjjnote-update/latest.json';
const state = {
  status: 'idle',
  currentVersion: String(window.__BJJ_APP_VERSION__ || '0.0.0'),
  manifest: null,
  error: null,
};
let nativeEventsBound = false;

function isNativeApp() {
  return Boolean(window.Capacitor?.isNativePlatform?.());
}

function addStyles() {
  if (document.getElementById('bjjnote-update-style')) return;
  const style = document.createElement('style');
  style.id = 'bjjnote-update-style';
  style.textContent = `
    .appUpdateBanner{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:-7px 0 16px;padding:13px 14px;background:#EEF5FF;border:1px solid #D5E3F8;border-radius:16px;color:#1C2B44}
    .appUpdateBanner small{display:block;font-size:9px;font-weight:800;color:#5D78A1}
    .appUpdateBanner b{display:block;margin-top:3px;font-size:13px;letter-spacing:-.02em}
    .appUpdateBanner p{margin:3px 0 0;font-size:9px;line-height:1.45;color:#667381}
    .appUpdateBanner button{flex:0 0 auto;border:0;border-radius:11px;background:#1C2B44;color:#fff;padding:10px 12px;font-size:10px;font-weight:800}
    .appUpdateBanner button:disabled{opacity:.55}
  `;
  document.head.appendChild(style);
}

async function waitForHome(timeoutMs = 8000) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const home = document.getElementById('homeShell');
    if (home) return home;
    await new Promise(resolve => setTimeout(resolve, 50));
  }
  return null;
}

function setButtonStatus(button, text, disabled = false) {
  button.textContent = text;
  button.disabled = disabled;
}

function currentBannerControls() {
  const banner = document.getElementById('appUpdateBanner');
  if (!banner) return null;
  return {
    message: banner.querySelector('#appUpdateMessage'),
    button: banner.querySelector('#appUpdateButton'),
  };
}

async function bindNativeEvents() {
  if (nativeEventsBound) return;
  const updater = window.Capacitor?.Plugins?.AppUpdater;
  if (!updater?.addListener) return;

  await updater.addListener('updateError', event => {
    state.status = 'available';
    state.error = String(event?.message || '업데이트 다운로드에 실패했습니다.');
    const controls = currentBannerControls();
    if (!controls) return;
    controls.message.textContent = `${state.error} 네트워크를 확인한 뒤 다시 시도해주세요.`;
    setButtonStatus(controls.button, '다시 시도', false);
  });

  await updater.addListener('installerOpened', () => {
    state.status = 'installing';
    const controls = currentBannerControls();
    if (!controls) return;
    controls.message.textContent = 'Android 설치 확인 화면이 열렸습니다. 설치를 승인해주세요.';
    setButtonStatus(controls.button, '설치 확인 중', true);
  });

  nativeEventsBound = true;
}

async function startInstall(manifest, button, message) {
  const updater = window.Capacitor?.Plugins?.AppUpdater;
  if (!updater?.installApk) {
    window.location.href = manifest.apkUrl;
    return;
  }

  await bindNativeEvents();
  setButtonStatus(button, '준비 중…', true);
  try {
    const result = await updater.installApk({ url: manifest.apkUrl, sha256: manifest.sha256 || null });
    if (result?.permissionRequired) {
      message.textContent = '설치 권한을 허용한 뒤 이 버튼을 한 번 더 눌러주세요.';
      setButtonStatus(button, '권한 허용 후 다시', false);
      return;
    }
    state.status = 'downloading';
    message.textContent = '업데이트를 내려받는 중입니다. 완료되면 Android 설치 화면이 열립니다.';
    setButtonStatus(button, '다운로드 중…', true);
  } catch (error) {
    state.status = 'available';
    message.textContent = '업데이트를 시작하지 못했습니다. 네트워크를 확인한 뒤 다시 시도해주세요.';
    setButtonStatus(button, '다시 시도', false);
    state.error = String(error?.message || error);
  }
}

async function renderUpdateBanner(manifest) {
  const home = await waitForHome();
  if (!home) return false;

  addStyles();
  await bindNativeEvents();
  let banner = document.getElementById('appUpdateBanner');
  if (!banner) {
    banner = document.createElement('div');
    banner.id = 'appUpdateBanner';
    banner.className = 'appUpdateBanner';
    banner.innerHTML = `
      <div>
        <small id="appUpdateVersion"></small>
        <b>새 버전이 준비됐어요</b>
        <p id="appUpdateMessage">눌러서 최신 주짓수 노트로 업데이트하세요.</p>
      </div>
      <button id="appUpdateButton" type="button">업데이트</button>
    `;
    const header = home.querySelector('.homeHeader');
    if (header) header.after(banner);
    else home.prepend(banner);
  }

  banner.querySelector('#appUpdateVersion').textContent = `v${state.currentVersion} → v${manifest.version}`;
  const message = banner.querySelector('#appUpdateMessage');
  message.textContent = manifest.releaseNotes || '눌러서 최신 주짓수 노트로 업데이트하세요.';
  const button = banner.querySelector('#appUpdateButton');
  button.disabled = false;
  button.textContent = '업데이트';
  button.onclick = () => startInstall(manifest, button, message);
  return true;
}

export async function checkForUpdate() {
  if (!isNativeApp()) {
    state.status = 'web';
    return state;
  }

  const manifestUrl = String(window.__BJJ_UPDATE_MANIFEST_URL__ || DEFAULT_MANIFEST_URL);
  state.status = 'checking';
  state.error = null;

  try {
    const response = await fetch(`${manifestUrl}${manifestUrl.includes('?') ? '&' : '?'}t=${Date.now()}`, {
      cache: 'no-store',
      headers: { Accept: 'application/json' },
    });
    if (!response.ok) throw new Error(`update manifest HTTP ${response.status}`);

    const manifest = await response.json();
    if (!validateUpdateManifest(manifest)) throw new Error('invalid update manifest');
    state.manifest = manifest;

    if (!isUpdateAvailable(state.currentVersion, manifest)) {
      state.status = 'current';
      document.getElementById('appUpdateBanner')?.remove();
      return state;
    }

    state.status = 'available';
    await renderUpdateBanner(manifest);
    return state;
  } catch (error) {
    state.status = 'unavailable';
    state.error = String(error?.message || error);
    return state;
  }
}

window.__BJJ_APP_UPDATER__ = { state, checkForUpdate };
setTimeout(async () => {
  await bindNativeEvents();
  await checkForUpdate();
}, 700);
document.addEventListener('visibilitychange', () => {
  if (!document.hidden && state.status !== 'checking') setTimeout(checkForUpdate, 350);
});
