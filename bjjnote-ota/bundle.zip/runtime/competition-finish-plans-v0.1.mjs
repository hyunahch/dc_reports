export const COMPETITION_FINISH_PLANS = [
  {
    id: 'single-leg-run-the-pipe',
    scenarioId: 'match-start-opponent-first-grip-stays-standing',
    title: '주력 싱글렉 마무리 · Run the Pipe',
    badge: 'Primary Finish',
    entryCondition: '오우치를 피하려 상대가 공격받은 다리를 뒤로 빼고, 새로 앞에 남은 다리를 헤드 인사이드 싱글로 잡은 순간.',
    summary: '상대를 크게 들어 올리거나 멀리 쫓기보다 머리를 상대 골반 가까이에 붙이고 팔꿈치를 모은 채 잡은 다리를 내 중심 가까이에 둔 상태에서 발과 몸통 회전으로 균형을 무너뜨린다.',
    whyThisFinish: '현재 A-Game의 핵심인 단순한 판단과 반응 연결에 맞는다. 헤드 인사이드 싱글의 대표적인 기본 마무리라 반복 학습 자료가 많고, 큰 리프트 없이도 몸 위치와 회전으로 탑 전환을 만들 수 있다.',
    cues: [
      '머리: 상대 골반·옆구리에 붙여 머리 위치를 잃지 않는다.',
      '팔꿈치: 바깥으로 벌어지지 않게 몸 가까이에 둔다.',
      '잡은 다리: 팔로 멀리 당기기보다 내 중심 가까이에 유지한다.',
      '마무리: 팔 힘보다 발 이동과 몸통 회전으로 상대 균형을 무너뜨린다.',
    ],
    steps: [
      {
        id: 'capture-new-lead-leg',
        order: 1,
        title: '새 앞다리를 헤드 인사이드 싱글로 확보',
        instruction: '오우치를 피하며 뒤로 빠진 다리를 쫓지 않는다. 상대가 새로 앞에 남긴 다리로 목표를 바꾸고, 머리는 상대 골반 가까이에 붙인 채 두 팔로 다리를 내 몸 가까이에 모은다.',
      },
      {
        id: 'elbows-in-posture',
        order: 2,
        title: '팔꿈치 모으고 자세부터 안정',
        instruction: '팔꿈치를 벌려 다리를 매달지 말고 몸 가까이에 모은다. 머리와 가슴이 너무 아래로 떨어지지 않게 자세를 세워 상대가 위저나 스프로울로 내 상체를 쉽게 누르기 어렵게 한다.',
      },
      {
        id: 'center-captured-leg',
        order: 3,
        title: '잡은 다리를 내 중심 가까이에 둔다',
        instruction: '상대 다리를 몸에서 멀리 잡아당기지 말고 내 다리 사이 또는 중심선 가까이에 정리한다. 상대가 한 발로 버티는 동안 내 머리와 어깨는 계속 골반에 연결한다.',
      },
      {
        id: 'run-the-pipe-turn',
        order: 4,
        title: '발 이동 + 몸 회전으로 Run the Pipe',
        instruction: '한쪽 발을 앞으로 두고 반대 발을 원을 그리듯 뒤로 빼면서 몸통을 함께 회전한다. 잡은 다리를 팔로 비트는 것이 아니라, 머리 위치와 몸 회전으로 상대의 남은 지지축을 무너뜨린다.',
      },
      {
        id: 'follow-to-top',
        order: 5,
        title: '넘어지면 다리·골반을 따라가 탑 안정화',
        instruction: '상대가 내려가면 손을 놓고 서 있지 말고 다리와 골반을 따라가 탑을 먼저 안정화한다. 즉시 서브미션을 찾기보다 하프가드 탑 또는 사이드컨트롤 계열로 연결할 수 있는 안정된 압박을 우선한다.',
      },
    ],
    safety: '연습에서는 상대 무릎을 억지로 비틀어 쓰러뜨리려 하지 않는다. 잡은 다리의 무릎이 불편한 방향으로 고정되면 회전을 강제하지 말고 풀어 준다. 넘어지는 파트너를 급하게 비틀어 던지기보다 통제된 속도로 따라 내려간다.',
    video: {
      status: 'verified',
      youtubeId: 'unKj49UQdVI',
      title: 'Run The Pipe! Finish Your Single Leg Takedowns',
      channel: 'Gold BJJ',
      url: 'https://www.youtube.com/watch?v=unKj49UQdVI',
      embedUrl: 'https://www.youtube.com/embed/unKj49UQdVI',
      watchFor: [
        '헤드 인사이드 싱글에서 머리와 골반 위치가 어떻게 유지되는지',
        '팔꿈치를 벌리지 않고 다리를 몸 가까이에 두는 방식',
        '팔로 당기기보다 발 이동과 회전으로 마무리하는 순서',
      ],
      verifiedAt: '2026-08-29',
    },
    sources: [
      {
        title: 'Run The Pipe! Finish Your Single Leg Takedowns',
        publisherOrInstructor: 'Dom Anderson / Gold BJJ',
        url: 'https://www.youtube.com/watch?v=unKj49UQdVI',
        role: 'primaryVideo',
        checkedAt: '2026-08-29',
      },
      {
        title: 'Finish the Single Leg with Rustam Chsiev',
        publisherOrInstructor: 'Rustam Chsiev / BJJ Fanatics',
        url: 'https://bjjfanatics.com/blogs/news/finish-the-single-leg-with-rustam-chsiev',
        role: 'mechanicsCrossCheck',
        checkedAt: '2026-08-29',
      },
      {
        title: 'The Head Inside Single Leg Takedown',
        publisherOrInstructor: 'Tyler Caldwell / BJJ Fanatics',
        url: 'https://bjjfanatics.com/collections/instructional-videos/products/the-head-inside-single-leg-takedown-by-tyler-caldwell',
        role: 'systemCrossCheck',
        checkedAt: '2026-08-29',
      },
    ],
  },
];

export function getCompetitionFinishPlan(scenarioId) {
  return COMPETITION_FINISH_PLANS.find(plan => plan.scenarioId === scenarioId) || null;
}
