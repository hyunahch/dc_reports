import { classifyOtaUpdate, validateOtaManifest } from './ota-update-core-v0.1.mjs';

const DEFAULT_MANIFEST_URL = 'https://raw.githubusercontent.com/hyunahch/dc_reports/main/bjjnote-ota/latest.json';
const state = {
  status: 'idle',
  currentVersion: String(window.__BJJ_OTA_VERSION__ || '0.0.0'),
  nativeSchema: Number(window.__BJJ_NATIVE_SCHEMA__ || 0),
  manifest: null,
  pendingVersion: null,
  error: null,
};
let readyNotified = false;
let checkPromise = null;

function isNativeApp() {
  return Boolean(window.Capacitor?.isNativePlatform?.());
}

function updaterPlugin() {
  return window.Capacitor?.Plugins?.CapacitorUpdater || null;
}

async function waitForAppReady(timeoutMs = 12000) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const home = document.getElementById('homeShell');
    if (home && document.body) return true;
    await new Promise(resolve => setTimeout(resolve, 60));
  }
  return Boolean(document.body);
}

async function notifyAppReady() {
  if (readyNotified || !isNativeApp()) return;
  const updater = updaterPlugin();
  if (!updater?.notifyAppReady) return;
  await waitForAppReady();
  try {
    await updater.notifyAppReady();
    readyNotified = true;
  } catch (error) {
    state.error = String(error?.message || error);
  }
}

function showPreparedToast(version) {
  if (!document.body || document.getElementById('otaPreparedToast')) return;
  const toast = document.createElement('div');
  toast.id = 'otaPreparedToast';
  toast.setAttribute('role', 'status');
  toast.textContent = `콘텐츠 업데이트 v${version} 준비 완료 · 다음 실행부터 자동 적용`;
  Object.assign(toast.style, {
    position: 'fixed',
    left: '50%',
    bottom: 'calc(84px + env(safe-area-inset-bottom, 0px))',
    transform: 'translateX(-50%)',
    zIndex: '9999',
    maxWidth: 'calc(100vw - 40px)',
    padding: '10px 13px',
    borderRadius: '13px',
    background: 'rgba(28,43,68,.94)',
    color: '#fff',
    fontSize: '11px',
    fontWeight: '700',
    lineHeight: '1.4',
    boxShadow: '0 8px 24px rgba(20,35,50,.18)',
    textAlign: 'center',
  });
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 4200);
}

async function fetchManifest() {
  const manifestUrl = String(window.__BJJ_OTA_MANIFEST_URL__ || DEFAULT_MANIFEST_URL);
  const response = await fetch(`${manifestUrl}${manifestUrl.includes('?') ? '&' : '?'}t=${Date.now()}`, {
    cache: 'no-store',
    headers: { Accept: 'application/json' },
  });
  if (!response.ok) throw new Error(`OTA manifest HTTP ${response.status}`);
  const manifest = await response.json();
  if (!validateOtaManifest(manifest)) throw new Error('invalid OTA manifest');
  return manifest;
}

export async function checkForOtaUpdate() {
  if (checkPromise) return checkPromise;
  checkPromise = (async () => {
    await notifyAppReady();
    if (!isNativeApp()) {
      state.status = 'web';
      return state;
    }

    const updater = updaterPlugin();
    if (!updater?.download || !updater?.next) {
      state.status = 'unsupported';
      return state;
    }

    state.status = 'checking';
    state.error = null;
    try {
      const manifest = await fetchManifest();
      state.manifest = manifest;
      const classification = classifyOtaUpdate(state.currentVersion, state.nativeSchema, manifest);

      if (classification === 'native-update-required') {
        state.status = classification;
        return state;
      }
      if (classification === 'current') {
        state.status = 'current';
        return state;
      }
      if (classification !== 'available') throw new Error(`OTA classification failed: ${classification}`);

      state.status = 'downloading';
      const bundle = await updater.download({
        url: manifest.bundleUrl,
        version: manifest.version,
        checksum: manifest.sha256,
      });
      if (!bundle?.id) throw new Error('OTA download did not return a bundle id');

      await updater.next({ id: bundle.id });
      state.pendingVersion = manifest.version;
      state.status = 'prepared';
      try {
        localStorage.setItem('bjjnote.ota.pendingVersion', manifest.version);
      } catch {}
      showPreparedToast(manifest.version);
      return state;
    } catch (error) {
      state.status = 'unavailable';
      state.error = String(error?.message || error);
      return state;
    } finally {
      setTimeout(() => { checkPromise = null; }, 1000);
    }
  })();
  return checkPromise;
}

window.__BJJ_OTA_UPDATER__ = { state, checkForOtaUpdate, notifyAppReady };

setTimeout(() => {
  notifyAppReady();
  checkForOtaUpdate();
}, 900);

document.addEventListener('visibilitychange', () => {
  if (!document.hidden && state.status !== 'checking' && state.status !== 'downloading') {
    setTimeout(checkForOtaUpdate, 450);
  }
});
