import { classifyOtaUpdate, validateOtaManifest } from './ota-update-core-v0.1.mjs';

const DEFAULT_MANIFEST_URL = 'https://raw.githubusercontent.com/hyunahch/dc_reports/main/bjjnote-ota/latest.json';
const PENDING_VERSION_KEY = 'bjjnote.ota.pendingVersion';
const PENDING_BUNDLE_ID_KEY = 'bjjnote.ota.pendingBundleId';
const state = {
  status: 'idle',
  currentVersion: String(window.__BJJ_OTA_VERSION__ || '0.0.0'),
  nativeSchema: Number(window.__BJJ_NATIVE_SCHEMA__ || 0),
  manifest: null,
  pendingVersion: null,
  error: null,
};
let readyNotified = false;
let checkPromise = null;
let launchActivationChecked = false;

function isNativeApp() {
  return Boolean(window.Capacitor?.isNativePlatform?.());
}

function updaterPlugin() {
  return window.Capacitor?.Plugins?.CapacitorUpdater || null;
}

function readStoredPending() {
  try {
    return {
      version: String(localStorage.getItem(PENDING_VERSION_KEY) || ''),
      id: String(localStorage.getItem(PENDING_BUNDLE_ID_KEY) || ''),
    };
  } catch {
    return { version: '', id: '' };
  }
}

function rememberPending(bundle, version = '') {
  const pendingVersion = String(version || bundle?.version || '');
  const pendingId = String(bundle?.id || '');
  try {
    if (pendingVersion) localStorage.setItem(PENDING_VERSION_KEY, pendingVersion);
    if (pendingId) localStorage.setItem(PENDING_BUNDLE_ID_KEY, pendingId);
  } catch {}
}

function clearStoredPending() {
  try {
    localStorage.removeItem(PENDING_VERSION_KEY);
    localStorage.removeItem(PENDING_BUNDLE_ID_KEY);
  } catch {}
}

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

async function waitForAppReady(timeoutMs = 12000) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const home = document.getElementById('homeShell');
    if (home && document.body) return true;
    await sleep(60);
  }
  return Boolean(document.body);
}

async function notifyAppReady() {
  if (readyNotified || !isNativeApp()) return;
  const updater = updaterPlugin();
  if (!updater?.notifyAppReady) return;
  await waitForAppReady();
  try {
    await updater.notifyAppReady();
    readyNotified = true;
  } catch (error) {
    state.error = String(error?.message || error);
  }
}

function showPreparedToast(version) {
  if (!document.body || document.getElementById('otaPreparedToast')) return;
  const toast = document.createElement('div');
  toast.id = 'otaPreparedToast';
  toast.setAttribute('role', 'status');
  toast.textContent = `콘텐츠 업데이트 v${version} 준비 완료 · 다음 실행부터 자동 적용`;
  Object.assign(toast.style, {
    position: 'fixed',
    left: '50%',
    bottom: 'calc(84px + env(safe-area-inset-bottom, 0px))',
    transform: 'translateX(-50%)',
    zIndex: '9999',
    maxWidth: 'calc(100vw - 40px)',
    padding: '10px 13px',
    borderRadius: '13px',
    background: 'rgba(28,43,68,.94)',
    color: '#fff',
    fontSize: '11px',
    fontWeight: '700',
    lineHeight: '1.4',
    boxShadow: '0 8px 24px rgba(20,35,50,.18)',
    textAlign: 'center',
  });
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 4200);
}

async function fetchManifest() {
  const manifestUrl = String(window.__BJJ_OTA_MANIFEST_URL__ || DEFAULT_MANIFEST_URL);
  const response = await fetch(`${manifestUrl}${manifestUrl.includes('?') ? '&' : '?'}t=${Date.now()}`, {
    cache: 'no-store',
    headers: { Accept: 'application/json' },
  });
  if (!response.ok) throw new Error(`OTA manifest HTTP ${response.status}`);
  const manifest = await response.json();
  if (!validateOtaManifest(manifest)) throw new Error('invalid OTA manifest');
  return manifest;
}

function usableNativeBundle(bundle) {
  return Boolean(
    bundle?.id &&
    bundle.id !== 'builtin' &&
    bundle.status !== 'error' &&
    bundle.status !== 'deleted'
  );
}

async function getPendingNativeBundle() {
  if (!isNativeApp()) return null;
  const updater = updaterPlugin();
  if (!updater?.getNextBundle) return null;
  try {
    const pending = await updater.getNextBundle();
    return usableNativeBundle(pending) ? pending : null;
  } catch {
    return null;
  }
}

async function listNativeBundles() {
  if (!isNativeApp()) return [];
  const updater = updaterPlugin();
  if (!updater?.list) return [];
  try {
    const result = await updater.list();
    return Array.isArray(result?.bundles) ? result.bundles.filter(usableNativeBundle) : [];
  } catch {
    return [];
  }
}

function newestBundle(bundles) {
  return [...bundles].sort((a, b) => {
    const aTime = Date.parse(a?.downloaded || '') || 0;
    const bTime = Date.parse(b?.downloaded || '') || 0;
    return bTime - aTime;
  })[0] || null;
}

async function findRecoverablePendingBundle({ version = '', checksum = '' } = {}) {
  const stored = readStoredPending();
  const bundles = await listNativeBundles();
  if (!bundles.length) return null;

  if (stored.id) {
    const exact = bundles.find(bundle => bundle.id === stored.id);
    if (exact) return exact;
  }

  const targetVersion = String(version || stored.version || '');
  if (!targetVersion) return null;
  let matches = bundles.filter(bundle => String(bundle.version || '') === targetVersion);
  if (checksum) {
    const checksumMatches = matches.filter(bundle => String(bundle.checksum || '') === String(checksum));
    if (checksumMatches.length) matches = checksumMatches;
  }
  return newestBundle(matches);
}

async function waitForRecoverablePendingBundle({ version = '', checksum = '', timeoutMs = 2200 } = {}) {
  const start = Date.now();
  do {
    const pending = await getPendingNativeBundle() || await findRecoverablePendingBundle({ version, checksum });
    if (pending) return pending;
    await sleep(180);
  } while (Date.now() - start < timeoutMs);
  return null;
}

async function getCurrentNativeBundle() {
  if (!isNativeApp()) return null;
  const updater = updaterPlugin();
  if (!updater?.current) return null;
  try {
    const current = await updater.current();
    return current?.bundle || null;
  } catch {
    return null;
  }
}

function sameNativeBundle(current, pending) {
  if (!current?.id || !pending?.id) return false;
  if (current.id === pending.id) return true;
  return current.id !== 'builtin' && String(current.version || '') === String(pending.version || '');
}

async function activateBundleNow(bundle, version = '') {
  const updater = updaterPlugin();
  if (!updater || !usableNativeBundle(bundle)) return false;
  rememberPending(bundle, version);
  state.pendingVersion = String(version || bundle.version || '');
  state.status = 'activating';

  if (updater?.set) {
    await updater.set({ id: bundle.id });
    return true;
  }
  if (updater?.next && updater?.reload) {
    await updater.next({ id: bundle.id });
    await updater.reload();
    return true;
  }
  return false;
}

export async function activatePendingOtaOnLaunch() {
  if (launchActivationChecked || !isNativeApp()) return false;
  launchActivationChecked = true;
  const updater = updaterPlugin();
  if (!updater) return false;

  try {
    const stored = readStoredPending();
    // On some Android cold launches Capgo's persisted bundle store is not ready
    // when the WebView bootstrap first runs. If our own marker says the previous
    // session prepared an OTA, give native storage a short grace window before
    // deciding that the bundle is gone and falling through to network recovery.
    const pending = stored.version || stored.id
      ? await waitForRecoverablePendingBundle({ version: stored.version })
      : await getPendingNativeBundle() || await findRecoverablePendingBundle();
    if (!pending) return false;

    rememberPending(pending);
    const current = await getCurrentNativeBundle();
    if (sameNativeBundle(current, pending)) {
      state.currentVersion = String(current.version || state.currentVersion);
      state.pendingVersion = null;
      state.status = 'current';
      clearStoredPending();
      await notifyAppReady();
      return false;
    }

    return await activateBundleNow(pending);
  } catch (error) {
    state.status = 'unavailable';
    state.error = String(error?.message || error);
    return false;
  }
}

async function recoverStoredPendingOnColdLaunch() {
  const stored = readStoredPending();
  if (!isNativeApp() || (!stored.version && !stored.id)) return false;
  const updater = updaterPlugin();
  if (!updater?.download) return false;

  state.status = 'recovering';
  state.error = null;
  try {
    // A prepared marker means this launch is the user's intended activation
    // launch. If Capgo temporarily or permanently lost the local bundle record,
    // recover the latest compatible OTA and activate it *now* instead of queuing
    // another `next` and forcing the user through a third app launch.
    const manifest = await fetchManifest();
    state.manifest = manifest;
    const classification = classifyOtaUpdate(state.currentVersion, state.nativeSchema, manifest);

    if (classification === 'current') {
      clearStoredPending();
      state.pendingVersion = null;
      state.status = 'current';
      return false;
    }
    if (classification !== 'available') {
      state.status = classification;
      return false;
    }

    const recovered = await waitForRecoverablePendingBundle({
      version: manifest.version,
      checksum: manifest.sha256,
      timeoutMs: 900,
    });
    if (recovered) return await activateBundleNow(recovered, manifest.version);

    state.status = 'downloading';
    const bundle = await updater.download({
      url: manifest.bundleUrl,
      version: manifest.version,
      checksum: manifest.sha256,
    });
    if (!bundle?.id) throw new Error('OTA cold-launch recovery download did not return a bundle id');
    return await activateBundleNow(bundle, manifest.version);
  } catch (error) {
    state.status = 'unavailable';
    state.error = String(error?.message || error);
    return false;
  }
}

export async function checkForOtaUpdate() {
  if (checkPromise) return checkPromise;
  checkPromise = (async () => {
    await notifyAppReady();
    if (!isNativeApp()) {
      state.status = 'web';
      return state;
    }

    const updater = updaterPlugin();
    if (!updater?.download || !updater?.next) {
      state.status = 'unsupported';
      return state;
    }

    state.status = 'checking';
    state.error = null;
    try {
      const manifest = await fetchManifest();
      state.manifest = manifest;
      const classification = classifyOtaUpdate(state.currentVersion, state.nativeSchema, manifest);

      if (classification === 'native-update-required') {
        state.status = classification;
        return state;
      }
      if (classification === 'current') {
        state.status = 'current';
        clearStoredPending();
        return state;
      }
      if (classification !== 'available') throw new Error(`OTA classification failed: ${classification}`);

      const existingPending = await getPendingNativeBundle() || await findRecoverablePendingBundle({
        version: manifest.version,
        checksum: manifest.sha256,
      });
      if (existingPending && String(existingPending.version || '') === String(manifest.version)) {
        if (!await getPendingNativeBundle()) {
          await updater.next({ id: existingPending.id });
        }
        rememberPending(existingPending, manifest.version);
        state.pendingVersion = manifest.version;
        state.status = 'prepared';
        return state;
      }

      state.status = 'downloading';
      const bundle = await updater.download({
        url: manifest.bundleUrl,
        version: manifest.version,
        checksum: manifest.sha256,
      });
      if (!bundle?.id) throw new Error('OTA download did not return a bundle id');

      await updater.next({ id: bundle.id });
      rememberPending(bundle, manifest.version);
      state.pendingVersion = manifest.version;
      state.status = 'prepared';
      showPreparedToast(manifest.version);
      return state;
    } catch (error) {
      state.status = 'unavailable';
      state.error = String(error?.message || error);
      return state;
    } finally {
      setTimeout(() => { checkPromise = null; }, 1000);
    }
  })();
  return checkPromise;
}

window.__BJJ_OTA_UPDATER__ = { state, checkForOtaUpdate, notifyAppReady, activatePendingOtaOnLaunch };

setTimeout(async () => {
  const activating = await activatePendingOtaOnLaunch();
  if (activating) return;

  const recovered = await recoverStoredPendingOnColdLaunch();
  if (recovered) return;

  // Only acknowledge the currently loaded bundle after we have exhausted the
  // cold-launch recovery path. This prevents a transient native-store miss from
  // turning a prepared update into another delayed `next` cycle.
  await notifyAppReady();
  checkForOtaUpdate();
}, 900);

document.addEventListener('visibilitychange', () => {
  if (!document.hidden && state.status !== 'checking' && state.status !== 'downloading' && state.status !== 'activating' && state.status !== 'recovering') {
    setTimeout(checkForOtaUpdate, 450);
  }
});
