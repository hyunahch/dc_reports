const STYLE_ID = 'mobile-home-illustrations-style';

const ASSETS = {
  competition: './runtime/assets/competition/first-10-seconds.webp',
  trainingGuide: './runtime/assets/competition/competition-day-checklist.webp',
};

function addStyles() {
  if (document.getElementById(STYLE_ID)) return;
  const style = document.createElement('style');
  style.id = STYLE_ID;
  style.textContent = `
    #homeCompetitionCard .homeCompetitionIllustration,
    #homeTrainingGuideCard .guideHomeIllustration{
      display:block;
      flex:0 0 auto;
      width:66px;
      height:60px;
      object-fit:contain;
      object-position:center;
      border-radius:12px;
      background:#F7F8FA;
    }
    #homeCompetitionCard.hasHomeIllustration{gap:11px}
    #homeCompetitionCard.hasHomeIllustration .homeCompetitionText{min-width:0}
    #homeTrainingGuideCard.hasHomeIllustration{gap:11px}
    #homeTrainingGuideCard.hasHomeIllustration .guideHomeText{min-width:0}
    @media(max-width:370px){
      #homeCompetitionCard .homeCompetitionIllustration,
      #homeTrainingGuideCard .guideHomeIllustration{width:58px;height:54px}
      #homeCompetitionCard.hasHomeIllustration{padding-left:11px;padding-right:11px;gap:8px}
      #homeTrainingGuideCard.hasHomeIllustration{padding-left:11px;padding-right:11px;gap:8px}
    }
  `;
  document.head.appendChild(style);
}

function illustration(src, alt, className) {
  const img = document.createElement('img');
  img.className = className;
  img.src = src;
  img.alt = alt;
  img.decoding = 'async';
  img.loading = 'eager';
  return img;
}

function decorateCompetitionCard() {
  const card = document.getElementById('homeCompetitionCard');
  if (!card || card.classList.contains('hasHomeIllustration')) return false;
  const icon = card.querySelector('.homeCompetitionIcon');
  if (!icon) return false;
  icon.replaceWith(illustration(
    ASSETS.competition,
    '첫 시합 준비를 상징하는 주짓수 상황 일러스트',
    'homeCompetitionIllustration',
  ));
  card.classList.add('hasHomeIllustration');
  return true;
}

function decorateTrainingGuideCard() {
  const card = document.getElementById('homeTrainingGuideCard');
  if (!card || card.classList.contains('hasHomeIllustration')) return false;
  const icon = card.querySelector('.guideHomeIcon');
  if (!icon) return false;
  icon.replaceWith(illustration(
    ASSETS.trainingGuide,
    '도복과 수련 준비를 상징하는 주짓수 일러스트',
    'guideHomeIllustration',
  ));
  card.classList.add('hasHomeIllustration');
  return true;
}

function decorateHomeIllustrations() {
  addStyles();
  const competition = decorateCompetitionCard();
  const trainingGuide = decorateTrainingGuideCard();
  return competition || trainingGuide;
}

let attempts = 0;
const timer = setInterval(() => {
  attempts += 1;
  decorateHomeIllustrations();
  if (attempts >= 400 || (document.querySelector('#homeCompetitionCard.hasHomeIllustration') && document.querySelector('#homeTrainingGuideCard.hasHomeIllustration'))) {
    clearInterval(timer);
  }
}, 25);

const observer = new MutationObserver(() => decorateHomeIllustrations());
observer.observe(document.documentElement, { childList: true, subtree: true });

window.__BJJ_HOME_ILLUSTRATIONS__ = {
  version: 'v0.2',
  assets: ASSETS,
  refresh: decorateHomeIllustrations,
};
