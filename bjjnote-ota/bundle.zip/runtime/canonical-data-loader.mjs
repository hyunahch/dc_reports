export const CANONICAL_RECORD_PATHS = [
  "./data/v0.2/techniques/armbar.json",
  "./data/v0.2/techniques/omoplata.json",
  "./data/v0.2/techniques/triangle.json",
  "./data/v0.2/techniques/kimura.json",
  "./data/v0.2/techniques/scissor-sweep.json",
  "./data/v0.2/techniques/hip-bump-sweep.json",
  "./data/v0.2/techniques/guillotine.json",
  "./data/v0.2/techniques/americana.json",
  "./data/v0.2/techniques/knee-cut-pass.json",
  "./data/v0.2/techniques/toreando-pass.json",
  "./data/v0.2/techniques/high-guard-push-down-pass.json",
  "./data/v0.2/techniques/sao-paulo-pass.json",
  "./data/v0.2/techniques/side-control-knee-elbow-escape.json",
  "./data/v0.2/techniques/side-hip-escape.json",
  "./data/v0.2/techniques/side-underhook-reguard.json",
  "./data/v0.2/techniques/mount-trap-and-roll-escape.json",
  "./data/v0.2/techniques/mount-leg-trap-escape.json",
  "./data/v0.2/techniques/closed-guard-standing-break.json",
  "./data/v0.2/techniques/closed-guard-kneeling-break.json",
  "./data/v0.2/techniques/spider-guard-basic-escape.json",
  "./data/v0.2/techniques/lasso-guard-basic-escape.json",
];

function canonicalBrowserUrl(path) {
  if (/^[a-z]+:/i.test(path) || path.startsWith("/")) return path;
  // Canonical paths are repository-root-relative. Resolve from this module,
  // not from the HTML document location, so root app and /prototypes/* share one loader.
  const rootRelative = path.replace(/^\.\//, "");
  return new URL(`../${rootRelative}`, import.meta.url).toString();
}

export async function loadTechniqueRecords(
  paths = CANONICAL_RECORD_PATHS,
  fetchJson = async (path) => {
    const response = await fetch(canonicalBrowserUrl(path), { cache: "no-store" });
    if (!response.ok) throw new Error(`Failed to load ${path}: ${response.status}`);
    return response.json();
  }
) {
  const records = await Promise.all(paths.map((path) => fetchJson(path)));
  const techniques = {};
  for (let index = 0; index < records.length; index += 1) {
    const record = records[index];
    const path = paths[index];
    if (!record || typeof record.id !== "string" || !record.id) {
      throw new Error(`Canonical technique is missing id: ${path}`);
    }
    if (techniques[record.id]) {
      throw new Error(`Duplicate canonical technique id: ${record.id}`);
    }
    techniques[record.id] = record;
  }

  // Runtime records are keyed by canonical id. Keep that contract while providing
  // a non-enumerable Array-style map compatibility shim for UI code that only needs
  // to derive a list. Object.keys/Object.values and schema/regression behavior stay unchanged.
  Object.defineProperty(techniques, "map", {
    enumerable: false,
    value(callback, thisArg) {
      return Object.values(techniques).map(callback, thisArg);
    },
  });

  return techniques;
}
