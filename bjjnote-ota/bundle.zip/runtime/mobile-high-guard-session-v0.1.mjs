const POSITION_ID = 'high-guard-top';
const POSITION_LABEL = '하이가드 탑';
let selected = false;

function addStyles() {
  if (document.getElementById('mobile-high-guard-session-style')) return;
  const style = document.createElement('style');
  style.id = 'mobile-high-guard-session-style';
  style.textContent = `
    .highGuardSessionPrimer{margin:3px 0 11px;border:1px solid #DDE5EA;border-radius:17px;background:#F7F9FA;padding:14px 15px;color:#1C2B44}
    .highGuardSessionPrimer small{display:block;color:#8498A8;font-size:8px;font-weight:900;letter-spacing:.12em}
    .highGuardSessionPrimer b{display:block;margin-top:6px;font-size:14px;letter-spacing:-.025em}
    .highGuardSessionPrimer p{margin:5px 0 0;color:#667381;font-size:10px;line-height:1.55}
    .highGuardSessionPrimer .sessionPath{margin-top:10px;padding:8px 9px;border-radius:11px;background:#EEF3F7;color:#40556A;font-size:10px;font-weight:800;line-height:1.45}
  `;
  document.head.appendChild(style);
}

function techniqueArray() {
  const payload = window.__recovery?.TECHNIQUES;
  if (!payload) return [];
  return Array.isArray(payload) ? payload : Object.values(payload);
}

function rowsForHighGuard() {
  return techniqueArray().flatMap(technique => (technique.entryRoutes || [])
    .filter(route => route.fromPositionId === POSITION_ID && ['verified', 'partial'].includes(route.status))
    .map(route => ({ technique, route })));
}

function renderHighGuard() {
  const positions = document.getElementById('positions');
  const list = document.getElementById('techniques');
  const count = document.querySelector('#techResultHead .catalogResultCount');
  if (!positions || !list) return;
  const rows = rowsForHighGuard();
  positions.querySelectorAll('button').forEach(btn => btn.classList.toggle('active', btn.dataset.id === POSITION_ID));
  list.innerHTML = `
    <div class="highGuardSessionPrimer" data-high-guard-primer>
      <small>오늘 배운 연결</small>
      <b>사이드 바텀 → 하프가드 → 하이가드</b>
      <p>바텀에서는 가드를 여기까지 회복하고, 역할을 바꾼 탑에서는 두 가지 패스를 비교해 복습합니다.</p>
      <div class="sessionPath">하이가드 탑 → ① 밀어내기 패스 / ② 상파울루(토지) 압박 패스 → 탑 사이드컨트롤</div>
    </div>
    ${rows.map(({ technique, route }) => `<button class="card" data-tech="${technique.id}" data-route="${route.id}"><b>${technique.nameKo}</b><small>${technique.classification?.actionCategory || 'pass'} · ${route.label}${route.status === 'partial' ? ' · route 검증 보완 중' : ''}</small></button>`).join('')}
  `;
  if (count) count.textContent = `${rows.length}개`;
  list.querySelectorAll('.card[data-tech]').forEach(card => card.addEventListener('click', () => {
    window.__recovery?.openTechnique?.({ techniqueId: card.dataset.tech, selectedEntryRouteId: card.dataset.route });
  }));
  window.__BJJ_HIGH_GUARD_SESSION__ = { version: 'v0.1', selected: true, count: rows.length };
}

function ensurePositionButton() {
  const positions = document.getElementById('positions');
  if (!positions) return false;
  let btn = positions.querySelector(`[data-id="${POSITION_ID}"]`);
  if (!btn) {
    btn = document.createElement('button');
    btn.type = 'button';
    btn.dataset.id = POSITION_ID;
    btn.dataset.virtualPosition = '1';
    btn.textContent = POSITION_LABEL;
    positions.appendChild(btn);
  }
  if (btn.dataset.highGuardBound !== '1') {
    btn.dataset.highGuardBound = '1';
    btn.addEventListener('click', () => {
      selected = true;
      renderHighGuard();
    });
  }
  if (selected) {
    btn.classList.add('active');
    queueMicrotask(renderHighGuard);
  }
  return true;
}

function init() {
  if (!window.__BJJ_MOBILE_SHELL__ || !window.__BJJ_TECH_CATEGORY__ || !window.__recovery?.TECHNIQUES) return false;
  const positions = document.getElementById('positions');
  if (!positions || !document.getElementById('techniques')) return false;
  addStyles();
  ensurePositionButton();

  if (positions.dataset.highGuardObserverBound !== '1') {
    positions.dataset.highGuardObserverBound = '1';
    const observer = new MutationObserver(() => queueMicrotask(ensurePositionButton));
    observer.observe(positions, { childList: true });
    positions.addEventListener('click', event => {
      const button = event.target.closest?.('button[data-id]');
      if (!button || button.dataset.id === POSITION_ID) return;
      selected = false;
      window.__BJJ_HIGH_GUARD_SESSION__ = { version: 'v0.1', selected: false, count: rowsForHighGuard().length };
    }, true);
  }

  window.__BJJ_HIGH_GUARD_SESSION__ = { version: 'v0.1', selected, count: rowsForHighGuard().length };
  return true;
}

let attempts = 0;
const timer = setInterval(() => {
  attempts += 1;
  if (init() || attempts >= 400) clearInterval(timer);
}, 25);

document.addEventListener('visibilitychange', () => {
  if (!document.hidden) init();
});
