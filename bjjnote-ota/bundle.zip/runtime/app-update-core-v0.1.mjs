export function normalizeVersion(value) {
  return String(value ?? '')
    .trim()
    .replace(/^v/i, '')
    .split('-')[0]
    .split('+')[0]
    .split('.')
    .map(part => Number.parseInt(part, 10) || 0);
}

export function compareVersions(left, right) {
  const a = normalizeVersion(left);
  const b = normalizeVersion(right);
  const size = Math.max(a.length, b.length, 3);
  for (let i = 0; i < size; i += 1) {
    const av = a[i] ?? 0;
    const bv = b[i] ?? 0;
    if (av > bv) return 1;
    if (av < bv) return -1;
  }
  return 0;
}

export function validateUpdateManifest(manifest) {
  if (!manifest || typeof manifest !== 'object') return false;
  if (typeof manifest.version !== 'string' || !manifest.version.trim()) return false;
  if (!Number.isInteger(Number(manifest.versionCode)) || Number(manifest.versionCode) < 1) return false;
  if (typeof manifest.apkUrl !== 'string' || !/^https:\/\//i.test(manifest.apkUrl)) return false;
  return true;
}

export function isUpdateAvailable(currentVersion, manifest) {
  return validateUpdateManifest(manifest) && compareVersions(manifest.version, currentVersion) > 0;
}
