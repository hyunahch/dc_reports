import './mobile-home-illustrations-v0.1.mjs';

const RECENT_KEY = 'bjjnote.recentTechnique';

function readRecent() {
  try {
    return JSON.parse(localStorage.getItem(RECENT_KEY) || 'null');
  } catch {
    return null;
  }
}

function positionCandidates(preferredPositionId = '') {
  const ids = [...document.querySelectorAll('#positions button[data-id]')]
    .map(button => button.dataset.id)
    .filter(Boolean);
  if (!preferredPositionId) return ids;
  return [preferredPositionId, ...ids.filter(id => id !== preferredPositionId)];
}

function findTechniqueCard(techniqueId) {
  return [...document.querySelectorAll('#techniques .card[data-tech]')]
    .find(card => card.dataset.tech === techniqueId) || null;
}

function openTechniqueDetail(techniqueId, preferredPositionId = '') {
  if (!techniqueId) return false;
  const shell = window.__BJJ_MOBILE_SHELL__;
  if (!shell?.show) return false;

  shell.show('tech');
  document.querySelector('.catalogSwitch button[data-catalog="techniques"]')?.click();

  for (const positionId of positionCandidates(preferredPositionId)) {
    const positionButton = [...document.querySelectorAll('#positions button[data-id]')]
      .find(button => button.dataset.id === positionId);
    if (!positionButton) continue;
    positionButton.click();
    const techniqueCard = findTechniqueCard(techniqueId);
    if (!techniqueCard) continue;
    techniqueCard.click();
    return true;
  }

  return false;
}

document.addEventListener('click', event => {
  const continueCard = event.target.closest?.('#continueCard');
  if (continueCard) {
    const recent = readRecent();
    if (!recent?.techniqueId) return;
    event.preventDefault();
    event.stopPropagation();
    openTechniqueDetail(recent.techniqueId, recent.positionId || '');
    return;
  }

  const activity = event.target.closest?.('[data-activity-tech]');
  if (!activity) return;
  event.preventDefault();
  event.stopPropagation();
  openTechniqueDetail(activity.dataset.activityTech, activity.dataset.activityPosition || '');
}, true);

window.__BJJ_RECENT_TECH_NAV__ = {
  version: 'v0.1',
  openTechniqueDetail,
};
