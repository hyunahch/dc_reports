const STYLE_ID = 'mobile-flow-single-owner-style';

function ensureStyle() {
  if (document.getElementById(STYLE_ID)) return;
  const style = document.createElement('style');
  style.id = STYLE_ID;
  style.textContent = '#flowAppPanel{display:none!important}';
  document.head.appendChild(style);
}

function getFlowButton() {
  return document.querySelector('.bottom button[data-shell-tab="flow"]') ||
    [...document.querySelectorAll('.bottom button')].find(button => button.textContent.trim() === '흐름') ||
    null;
}

function removeLegacyFlowOwner() {
  const legacyPanel = document.getElementById('flowAppPanel');
  if (legacyPanel) legacyPanel.remove();
  const flowButton = getFlowButton();
  if (flowButton?.onclick) flowButton.onclick = null;
}

function normalizeCompetitionIndex(flow) {
  const switchEl = flow.querySelector('#mobileFlowModeSwitch');
  const competitionButton = switchEl?.querySelector('[data-mobile-flow-mode="competition"]');
  if (!switchEl || !competitionButton?.classList.contains('active')) return;

  const firstCompetition = flow.querySelector('#firstCompetitionGuide');
  if (firstCompetition && switchEl.nextElementSibling !== firstCompetition) {
    switchEl.insertAdjacentElement('afterend', firstCompetition);
  }

  const scenarioHeading = [...flow.querySelectorAll('.shellTitle h2')]
    .find(node => node.textContent.trim() === '경기 시작');
  if (scenarioHeading) scenarioHeading.textContent = '개인 시나리오';
}

function enforceSingleOwner() {
  ensureStyle();
  const flow = document.getElementById('flowShell');
  if (!flow) return false;

  removeLegacyFlowOwner();
  if (flow.classList.contains('active')) {
    document.querySelectorAll('.panel.active,.shellPanel.active').forEach(panel => {
      if (panel !== flow) panel.classList.remove('active');
    });
  }
  normalizeCompetitionIndex(flow);

  globalThis.__BJJ_FLOW_SINGLE_OWNER__ = {
    version: 'v0.1',
    activeRootCount: document.querySelectorAll('.panel.active,.shellPanel.active').length,
    legacyPanelPresent: Boolean(document.getElementById('flowAppPanel')),
  };
  return true;
}

document.addEventListener('click', event => {
  const button = event.target.closest?.('.bottom button');
  if (!button) return;
  if (button.dataset.shellTab !== 'flow' && button.textContent.trim() !== '흐름') return;
  if (button.onclick) button.onclick = null;
  queueMicrotask(enforceSingleOwner);
  setTimeout(enforceSingleOwner, 0);
}, true);

const observer = new MutationObserver(() => queueMicrotask(enforceSingleOwner));
observer.observe(document.documentElement, {
  childList: true,
  subtree: true,
  attributes: true,
  attributeFilter: ['class'],
});

let attempts = 0;
const timer = setInterval(() => {
  attempts += 1;
  const ready = enforceSingleOwner();
  if ((ready && globalThis.__BJJ_MOBILE_SHELL__) || attempts >= 400) clearInterval(timer);
}, 25);
