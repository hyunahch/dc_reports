const DB_NAME = 'bjjnote.videoReview.v1';
const DB_VERSION = 1;
const STORE = 'entries';
const FRAME_COUNT = 6;
const FRAME_MAX_WIDTH = 768;

const SITUATION_LABELS = {
  'match-opening': '경기 시작',
  'guard-pull': '가드 풀 대응',
  'top-side': '탑 사이드',
  'mount-escape': '마운트 탈출',
  free: '자유 분석',
};

const ATHLETE_LABELS = {
  'white-gi': '나는 흰 도복',
  'blue-gi': '나는 파란/어두운 도복',
  left: '나는 화면 왼쪽',
  right: '나는 화면 오른쪽',
};

const REVIEW_CUES = {
  'match-opening': [
    '시작 신호 뒤 첫발이 언제 움직이는지',
    '상대와 정면으로 멈춰 있는 시간이 긴지',
    '첫 그립 뒤 다음 발 움직임이 이어지는지',
    '상대 반응 뒤 판단이 멈추는 순간이 있는지',
  ],
  'guard-pull': [
    '상대가 앉기 시작하는 순간 내 첫발이 움직이는지',
    '양발이 동시에 멈추는지',
    '골반이 상대 정면에서 옆으로 빠지는지',
    '상대 다리 라인을 손으로 치우는 타이밍',
    '첫발 뒤 뒷발이 따라오는지',
    '정면을 벗어난 뒤 상체 압박이 이어지는지',
  ],
  'top-side': [
    '포지션을 잡은 뒤 바로 공격하지 않고 먼저 안정하는지',
    '머리·상체·힙 압박이 끊기는 순간이 있는지',
    '상대가 프레임을 만들 때 내 베이스가 흔들리는지',
    '상대 반응을 보고 다음 선택으로 넘어가는지',
  ],
  'mount-escape': [
    '목과 팔을 먼저 안전하게 지키는지',
    '팔꿈치와 무릎 사이 공간을 줄이는지',
    '한 번에 뒤집으려 하기보다 단계적으로 공간을 만드는지',
    '실패 뒤 멈추지 않고 다음 탈출로 이어가는지',
  ],
  free: [
    '눈에 보이는 반복 행동을 먼저 찾기',
    '잘한 행동과 개선할 행동을 구분하기',
    '확실히 보이지 않는 관절·그립은 추측하지 않기',
  ],
};

function openDb() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('영상 복기 저장소를 열 수 없습니다.'));
  });
}

async function dbGet(id) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readonly');
    const request = tx.objectStore(STORE).get(id);
    request.onsuccess = () => resolve(request.result || null);
    request.onerror = () => reject(request.error || new Error('영상 복기를 불러오지 못했습니다.'));
    tx.oncomplete = () => db.close();
  });
}

async function dbPut(entry) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).put(entry);
    tx.oncomplete = () => { db.close(); resolve(); };
    tx.onerror = () => { db.close(); reject(tx.error || new Error('분석 결과 저장에 실패했습니다.')); };
  });
}

function buildReviewPrompt(entry) {
  const situation = SITUATION_LABELS[entry.situation] || '자유 분석';
  const athlete = ATHLETE_LABELS[entry.athlete] || '영상 속 내가 누구인지 메모를 참고';
  const cues = REVIEW_CUES[entry.situation] || REVIEW_CUES.free;
  const userQuestion = String(entry.note || '').trim();
  return [
    '주짓수노트의 짧은 영상 복기입니다. 첨부한 이미지는 같은 짧은 영상에서 시간순으로 뽑은 대표 프레임입니다.',
    '',
    `[상황] ${situation}`,
    `[영상 속 나] ${athlete}`,
    userQuestion ? `[내가 궁금한 것] ${userQuestion}` : '',
    '',
    '[우선 확인할 것]',
    ...cues.map((cue, index) => `${index + 1}. ${cue}`),
    '',
    '프레임만으로 확실히 보이는 것과 추정인 것을 구분해 주세요. 가려진 그립·관절 위치는 단정하지 말아 주세요.',
    '결과는 아래 순서로 짧고 구체적으로 정리해 주세요.',
    '1) 잘한 점',
    '2) 가장 먼저 고칠 것 1개',
    '3) 그 다음 문제 최대 2개',
    '4) 프레임 순서 기준으로 문제가 보이는 장면',
    '5) 다음 반복에서 기억할 짧은 훈련 큐 1~2개',
  ].filter(Boolean).join('\n');
}

function seek(video, time) {
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => reject(new Error('영상 장면을 불러오는 데 시간이 걸리고 있습니다.')), 7000);
    const done = () => { clearTimeout(timeout); video.removeEventListener('seeked', done); resolve(); };
    video.addEventListener('seeked', done, { once: true });
    try { video.currentTime = Math.max(0, Math.min(time, Math.max(0, video.duration - 0.04))); }
    catch (error) { clearTimeout(timeout); reject(error); }
  });
}

function canvasBlob(canvas) {
  return new Promise((resolve, reject) => {
    canvas.toBlob(blob => blob ? resolve(blob) : reject(new Error('분석 장면을 이미지로 만들지 못했습니다.')), 'image/jpeg', 0.78);
  });
}

async function extractReviewFrames(entry, count = FRAME_COUNT) {
  if (!entry?.blob) throw new Error('저장된 영상이 없습니다.');
  const url = URL.createObjectURL(entry.blob);
  const video = document.createElement('video');
  video.preload = 'auto';
  video.muted = true;
  video.playsInline = true;
  video.src = url;
  try {
    await new Promise((resolve, reject) => {
      const timeout = setTimeout(() => reject(new Error('영상 정보를 읽지 못했습니다.')), 8000);
      video.onloadedmetadata = () => { clearTimeout(timeout); resolve(); };
      video.onerror = () => { clearTimeout(timeout); reject(new Error('영상 정보를 읽지 못했습니다.')); };
    });
    const duration = Number(video.duration);
    if (!Number.isFinite(duration) || duration <= 0) throw new Error('영상 길이를 확인할 수 없습니다.');
    const actualCount = Math.max(3, Math.min(count, duration < 3 ? 4 : count));
    const times = Array.from({ length: actualCount }, (_, index) => {
      const ratio = actualCount === 1 ? 0 : index / (actualCount - 1);
      return Math.max(0, Math.min(duration - 0.04, duration * (0.06 + ratio * 0.88)));
    });
    const files = [];
    for (let index = 0; index < times.length; index += 1) {
      await seek(video, times[index]);
      const sourceWidth = video.videoWidth || 1280;
      const sourceHeight = video.videoHeight || 720;
      const width = Math.min(FRAME_MAX_WIDTH, sourceWidth);
      const height = Math.max(1, Math.round(sourceHeight * (width / sourceWidth)));
      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const context = canvas.getContext('2d', { alpha: false });
      context.drawImage(video, 0, 0, width, height);
      const blob = await canvasBlob(canvas);
      files.push(new File([blob], `bjj-review-${String(index + 1).padStart(2, '0')}.jpg`, { type: 'image/jpeg' }));
    }
    return files;
  } finally {
    try { video.pause(); } catch {}
    video.removeAttribute('src');
    URL.revokeObjectURL(url);
  }
}

async function copyText(text) {
  if (navigator.clipboard?.writeText) {
    await navigator.clipboard.writeText(text);
    return true;
  }
  const area = document.createElement('textarea');
  area.value = text;
  area.style.position = 'fixed';
  area.style.opacity = '0';
  document.body.appendChild(area);
  area.select();
  const ok = document.execCommand?.('copy');
  area.remove();
  return Boolean(ok);
}

function ensureStyles() {
  if (document.getElementById('video-review-chatgpt-bridge-style')) return;
  const style = document.createElement('style');
  style.id = 'video-review-chatgpt-bridge-style';
  style.textContent = `
    .videoReviewChatgpt{margin-top:9px;padding-top:9px;border-top:1px solid #E8ECEF}.videoReviewChatgpt button{width:100%;height:36px;border:0;border-radius:10px;background:#1C2B44;color:#fff;font-size:9px;font-weight:900}.videoReviewChatgpt small{display:block;margin-top:6px;font-size:8px;line-height:1.45;color:#8498A8}.videoReviewPasteToggle{margin-top:6px!important;background:#F2F5F7!important;color:#1C2B44!important;border:1px solid #E1E7EB!important}.videoReviewPastePanel{margin-top:7px}.videoReviewPastePanel[hidden]{display:none}.videoReviewPastePanel textarea{width:100%;min-height:94px;border:1px solid #DDE4E9;border-radius:10px;padding:9px;font:inherit;font-size:9px;line-height:1.5;color:#1C2B44;resize:vertical}.videoReviewPastePanel .videoReviewPasteSave{margin-top:6px;background:#fff;color:#1C2B44;border:1px solid #DDE4E9}.videoReviewAnalysis{margin-top:9px;padding:10px;border-radius:11px;background:#F7F8FA}.videoReviewAnalysis b{display:block;font-size:9px;color:#1C2B44}.videoReviewAnalysis p{margin:5px 0 0;white-space:pre-wrap;font-size:9px;line-height:1.55;color:#667381}.videoReviewShareStatus{min-height:14px;margin-top:5px;font-size:8px;line-height:1.4;color:#667381}.videoReviewShareStatus.isError{color:#A14848}
  `;
  document.head.appendChild(style);
}

function bridgeMarkup(entry) {
  const analysis = String(entry.analysisText || entry.analysis || '').trim();
  return `
    <div class="videoReviewChatgpt" data-video-review-chatgpt="${entry.id}">
      <button type="button" data-video-review-share="${entry.id}">ChatGPT로 복기하기</button>
      <small>대표 장면 6장과 복기 질문을 준비해 공유합니다. 공유창에서 ChatGPT를 선택하세요.</small>
      <button type="button" class="videoReviewPasteToggle" data-video-review-paste-toggle="${entry.id}">분석 결과 붙여넣기</button>
      <div class="videoReviewPastePanel" data-video-review-paste-panel="${entry.id}" hidden><textarea placeholder="ChatGPT의 분석 결과를 여기에 붙여넣으세요.">${analysis}</textarea><button type="button" class="videoReviewPasteSave" data-video-review-paste-save="${entry.id}">분석 결과 저장</button></div>
      <div class="videoReviewShareStatus" data-video-review-share-status="${entry.id}" aria-live="polite"></div>
      ${analysis ? `<div class="videoReviewAnalysis"><b>저장된 복기 결과</b><p>${analysis.replace(/[&<>\"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;'}[c]))}</p></div>` : ''}
    </div>`;
}

async function enhanceCard(card) {
  if (card.querySelector('[data-video-review-chatgpt]')) return;
  const id = card.dataset.videoReviewEntry;
  if (!id) return;
  const entry = await dbGet(id).catch(() => null);
  if (!entry || !card.isConnected || card.querySelector('[data-video-review-chatgpt]')) return;
  card.insertAdjacentHTML('beforeend', bridgeMarkup(entry));
}

function setShareStatus(id, message, error = false) {
  const el = document.querySelector(`[data-video-review-share-status="${CSS.escape(id)}"]`);
  if (!el) return;
  el.textContent = message;
  el.classList.toggle('isError', error);
}

async function shareReview(id, button) {
  const entry = await dbGet(id);
  if (!entry) return;
  const prompt = buildReviewPrompt(entry);
  button.disabled = true;
  setShareStatus(id, '대표 장면을 뽑고 있어요…');
  try {
    const frames = await extractReviewFrames(entry);
    const payload = { title: `주짓수노트 · ${SITUATION_LABELS[entry.situation] || '영상 복기'}`, text: prompt, files: frames };
    if (navigator.share && (!navigator.canShare || navigator.canShare({ files: frames }))) {
      setShareStatus(id, '공유창이 열리면 ChatGPT를 선택하세요.');
      await navigator.share(payload);
      setShareStatus(id, '공유했습니다. ChatGPT에서 분석한 뒤 결과를 돌아와 저장하세요.');
      return;
    }
    await copyText(prompt);
    setShareStatus(id, '이 기기에서는 이미지 묶음 공유가 지원되지 않아 복기 질문을 복사했습니다. ChatGPT에 영상 또는 대표 장면을 올리고 붙여넣어 주세요.');
  } catch (error) {
    if (error?.name === 'AbortError') setShareStatus(id, '공유를 취소했습니다.');
    else {
      try { await copyText(prompt); } catch {}
      setShareStatus(id, `${error?.message || '공유 준비에 실패했습니다.'} 복기 질문은 클립보드에 복사했습니다.`, true);
    }
  } finally {
    button.disabled = false;
  }
}

async function saveAnalysis(id, panel) {
  const textarea = panel.querySelector('textarea');
  const text = textarea?.value.trim() || '';
  if (!text) return;
  const entry = await dbGet(id);
  if (!entry) return;
  entry.analysisStatus = 'chatgpt-manual';
  entry.analysisText = text;
  entry.analysisSavedAt = Date.now();
  await dbPut(entry);
  const card = panel.closest('[data-video-review-entry]');
  card?.querySelector('[data-video-review-chatgpt]')?.remove();
  if (card) await enhanceCard(card);
  setShareStatus(id, 'ChatGPT 복기 결과를 저장했습니다.');
}

function enhance() {
  ensureStyles();
  document.querySelectorAll('#noteShell [data-video-review-entry]').forEach(card => enhanceCard(card));
  globalThis.__BJJ_VIDEO_REVIEW_CHATGPT__ = {
    version: 'v0.1',
    mounted: Boolean(document.querySelector('#noteShell')),
    mode: 'os-share-manual-return',
    apiCost: 'none',
    frameCount: FRAME_COUNT,
    buildPrompt: buildReviewPrompt,
  };
}

if (!document.documentElement.dataset.videoReviewChatgptBound) {
  document.documentElement.dataset.videoReviewChatgptBound = '1';
  document.addEventListener('click', event => {
    const share = event.target.closest?.('[data-video-review-share]');
    if (share) { event.preventDefault(); shareReview(share.dataset.videoReviewShare, share); return; }
    const toggle = event.target.closest?.('[data-video-review-paste-toggle]');
    if (toggle) {
      event.preventDefault();
      const panel = document.querySelector(`[data-video-review-paste-panel="${CSS.escape(toggle.dataset.videoReviewPasteToggle)}"]`);
      if (panel) panel.hidden = !panel.hidden;
      return;
    }
    const save = event.target.closest?.('[data-video-review-paste-save]');
    if (save) {
      event.preventDefault();
      const panel = save.closest('[data-video-review-paste-panel]');
      if (panel) saveAnalysis(save.dataset.videoReviewPasteSave, panel).catch(error => setShareStatus(save.dataset.videoReviewPasteSave, error.message || '저장에 실패했습니다.', true));
    }
  }, true);
}

const observer = new MutationObserver(() => queueMicrotask(enhance));
observer.observe(document.documentElement, { childList: true, subtree: true });
enhance();

export { buildReviewPrompt, extractReviewFrames };
