const ACTION_LABELS = new Map([
  ['escape', '탈출'],
  ['submission', '서브미션'],
  ['sweep', '스윕'],
  ['pass', '패스'],
  ['takedown', '테이크다운'],
  ['transition', '전환'],
  ['control', '컨트롤'],
]);

const POSITION_GROUP_LABELS = new Map([
  ['bottom-mount', '마운트 탈출'],
  ['closed-guard-top', '클로즈드가드 탈출'],
  ['bottom-side-control', '사이드컨트롤 탈출'],
  ['closed-guard', '클로즈드가드'],
  ['mount', '마운트'],
  ['top-side-control', '탑 사이드컨트롤'],
  ['top-half-guard', '탑 하프가드'],
  ['spider-guard', '스파이더가드'],
  ['lasso-guard', '라쏘가드'],
]);

const CATEGORY_ORDER = ['escape', 'submission', 'sweep', 'pass', 'takedown', 'transition', 'control'];
let browseMode = 'position';
let selectedCategory = 'escape';

function addStyles() {
  if (document.getElementById('mobile-tech-category-style')) return;
  const style = document.createElement('style');
  style.id = 'mobile-tech-category-style';
  style.textContent = `
    #techBrowseSwitch{display:grid;grid-template-columns:1fr 1fr;gap:5px;padding:4px;margin:0 0 16px;background:#F2F5F7;border-radius:13px}
    #techBrowseSwitch button{height:34px;border:0;border-radius:9px;background:transparent;color:#667381;font-size:11px;font-weight:800}
    #techBrowseSwitch button.active{background:#fff;color:#1C2B44;box-shadow:0 2px 8px rgba(20,35,50,.05)}
    #actionCategories{display:flex;gap:7px;overflow-x:auto;margin-right:-20px;padding:0 20px 7px 0;scrollbar-width:none;-webkit-overflow-scrolling:touch}
    #actionCategories::-webkit-scrollbar{display:none}
    #actionCategories button{flex:0 0 auto;min-height:36px;padding:8px 12px;border:1px solid #E3E8EC;border-radius:999px;background:#fff;color:#667381;font-size:11px;font-weight:700;box-shadow:0 2px 8px rgba(20,35,50,.025)}
    #actionCategories button.active{border-color:#1C2B44;background:#1C2B44;color:#fff;box-shadow:none}
    .techActionGroup{margin:17px 0 8px;display:flex;align-items:center;justify-content:space-between}
    .techActionGroup b{font-size:12px;color:#1C2B44;letter-spacing:-.02em}
    .techActionGroup span{font-size:9px;color:#8498A8;font-weight:700}
    #index.techPolished #techniques .techActionGroup:first-child{margin-top:3px}
    @media(min-width:700px){#actionCategories{margin-right:0;padding-right:0}}
  `;
  document.head.appendChild(style);
}

function techniqueArray() {
  const payload = window.__recovery?.TECHNIQUES;
  if (!payload) return [];
  if (Array.isArray(payload)) return payload;
  return Object.values(payload);
}

function routeForTechnique(t) {
  const routes = t?.entryRoutes || [];
  return routes.find(r => r.status === 'verified') || routes[0] || null;
}

function actionLabel(category) {
  return ACTION_LABELS.get(category) || category || '기술';
}

function groupLabel(route, category) {
  const positionId = route?.fromPositionId;
  if (category === 'escape' && POSITION_GROUP_LABELS.has(positionId)) return POSITION_GROUP_LABELS.get(positionId);
  return POSITION_GROUP_LABELS.get(positionId) || route?.label || '기타';
}

function renderCategories() {
  const holder = document.getElementById('actionCategories');
  if (!holder) return;
  const present = new Set(techniqueArray().map(t => t?.classification?.actionCategory).filter(Boolean));
  const categories = CATEGORY_ORDER.filter(id => present.has(id));
  if (!categories.includes(selectedCategory)) selectedCategory = categories[0] || 'escape';
  holder.innerHTML = categories.map(id => `<button type="button" class="${id === selectedCategory ? 'active' : ''}" data-action-category="${id}">${actionLabel(id)}</button>`).join('');
  holder.querySelectorAll('[data-action-category]').forEach(btn => btn.addEventListener('click', () => {
    selectedCategory = btn.dataset.actionCategory;
    renderCategories();
    renderCategoryList();
  }));
}

function renderCategoryList() {
  const list = document.getElementById('techniques');
  const count = document.querySelector('#techResultHead .catalogResultCount');
  if (!list) return;
  const rows = techniqueArray()
    .filter(t => t?.classification?.actionCategory === selectedCategory)
    .map(t => ({ technique: t, route: routeForTechnique(t) }))
    .filter(x => x.route);

  const groups = new Map();
  for (const row of rows) {
    const label = groupLabel(row.route, selectedCategory);
    if (!groups.has(label)) groups.set(label, []);
    groups.get(label).push(row);
  }

  list.innerHTML = [...groups.entries()].map(([label, items]) => `
    <div class="techActionGroup"><b>${label}</b><span>${items.length}개</span></div>
    ${items.map(({ technique, route }) => `<button class="card" data-tech="${technique.id}" data-route="${route.id}"><b>${technique.nameKo}</b><small>${selectedCategory} · ${route.label}</small></button>`).join('')}
  `).join('');
  if (count) count.textContent = `${rows.length}개`;

  list.querySelectorAll('.card[data-tech]').forEach(card => card.addEventListener('click', () => {
    window.__recovery?.openTechnique?.({ techniqueId: card.dataset.tech, selectedEntryRouteId: card.dataset.route || null });
  }));
}

function setMode(mode, { restorePosition = true } = {}) {
  browseMode = mode;
  const techCatalog = document.getElementById('techCatalog');
  const positions = document.getElementById('positions');
  const categories = document.getElementById('actionCategories');
  const switcher = document.getElementById('techBrowseSwitch');
  const title = techCatalog?.querySelector(':scope > h2');
  const hint = techCatalog?.querySelector(':scope > .hint');
  switcher?.querySelectorAll('[data-tech-browse]').forEach(btn => btn.classList.toggle('active', btn.dataset.techBrowse === mode));

  if (mode === 'category') {
    if (positions) positions.style.display = 'none';
    if (categories) categories.style.display = 'flex';
    if (title) title.textContent = '기술 종류';
    if (hint) hint.textContent = '탈출·서브미션·스윕·패스처럼 목적별로 기술을 모아볼 수 있어요.';
    renderCategories();
    renderCategoryList();
  } else {
    if (positions) positions.style.display = '';
    if (categories) categories.style.display = 'none';
    if (title) title.textContent = '시작 포지션';
    if (hint) hint.textContent = '포지션을 고르면 그 위치에서 바로 쓸 수 있는 기술만 보여줘요.';
    if (restorePosition) {
      const active = positions?.querySelector('button.active') || positions?.querySelector('button');
      active?.click();
    }
  }
  window.__BJJ_TECH_CATEGORY__ = { version: 'v0.1', mode: browseMode, selectedCategory };
}

function enhance() {
  const techCatalog = document.getElementById('techCatalog');
  const positions = document.getElementById('positions');
  const list = document.getElementById('techniques');
  if (!techCatalog || !positions || !list || !window.__BJJ_MOBILE_SHELL__ || !window.__recovery?.TECHNIQUES) return false;
  addStyles();

  if (!document.getElementById('techBrowseSwitch')) {
    const browse = document.createElement('div');
    browse.id = 'techBrowseSwitch';
    browse.innerHTML = '<button type="button" class="active" data-tech-browse="position">포지션</button><button type="button" data-tech-browse="category">기술 종류</button>';
    techCatalog.prepend(browse);
    browse.querySelectorAll('[data-tech-browse]').forEach(btn => btn.addEventListener('click', () => setMode(btn.dataset.techBrowse)));
  }

  if (!document.getElementById('actionCategories')) {
    const categories = document.createElement('div');
    categories.id = 'actionCategories';
    categories.style.display = 'none';
    positions.after(categories);
  }

  if (positions.dataset.categoryModeBound !== '1') {
    positions.addEventListener('click', () => {
      if (browseMode !== 'position') setMode('position', { restorePosition: false });
    }, true);
    positions.dataset.categoryModeBound = '1';
  }

  setMode(browseMode, { restorePosition: false });
  return true;
}

let attempts = 0;
const timer = setInterval(() => {
  attempts += 1;
  if (enhance() || attempts >= 400) clearInterval(timer);
}, 25);

document.addEventListener('visibilitychange', () => {
  if (!document.hidden) enhance();
});
