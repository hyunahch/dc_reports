// Personal unlisted classroom URLs are deliberately NOT bundled with public OTA assets.
// The user imports a private manifest on their own device; only per-device storage is used.
export const PRIVATE_CLASS_LINK_STORAGE_KEY = 'bjjnote.privateClassYoutubeLinks.v1';
export const PRIVATE_CLASS_LINK_MANIFEST_TYPE = 'bjjnote-private-class-youtube-links';

const SOURCE_RE = /^20\d{6}_\d{6}\.mp4$/;
const VIDEO_ID_RE = /^[A-Za-z0-9_-]{11}$/;

export function validatePrivateClassLinkManifest(manifest) {
  if (!manifest || manifest.schemaVersion !== 1 ||
      manifest.type !== PRIVATE_CLASS_LINK_MANIFEST_TYPE ||
      !Array.isArray(manifest.videos) || !manifest.videos.length ||
      manifest.videos.length > 250) {
    throw new Error('주짓수 노트 개인 유튜브 연결 파일 형식이 아닙니다.');
  }
  const items = {};
  for (const video of manifest.videos) {
    const source = String(video?.source || '');
    const videoId = String(video?.videoId || '');
    const size = Number(video?.sourceSize);
    const duration = Number(video?.sourceDurationSeconds);
    if (!SOURCE_RE.test(source) || !VIDEO_ID_RE.test(videoId) ||
        !Number.isSafeInteger(size) || size <= 0 ||
        !Number.isFinite(duration) || duration <= 0 ||
        video?.privacy !== 'unlisted' || video?.uploadStatus !== 'processed') {
      throw new Error('확인되지 않은 원본·YouTube 영상 연결이 포함되어 있습니다.');
    }
    if (items[source]) throw new Error('같은 원본 영상이 중복 등록되었습니다.');
    items[source] = { videoId, sourceSize:size, sourceDurationSeconds:duration, privacy:'unlisted', tcCoverageVerified:video.tcCoverageVerified === true };
  }
  return items;
}

export function readPrivateClassLinks(storage = globalThis.localStorage) {
  try {
    const raw = JSON.parse(storage?.getItem(PRIVATE_CLASS_LINK_STORAGE_KEY) || '{}');
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return {};
    const safe = {};
    for (const [source, entry] of Object.entries(raw)) {
      if (SOURCE_RE.test(source) && VIDEO_ID_RE.test(entry?.videoId) &&
          Number.isFinite(Number(entry?.sourceDurationSeconds)) &&
          Number(entry?.sourceDurationSeconds) > 0) {
        safe[source] = {
          videoId:entry.videoId, sourceSize:Number(entry.sourceSize) || 0,
          sourceDurationSeconds:Number(entry.sourceDurationSeconds), privacy:'unlisted', tcCoverageVerified:entry.tcCoverageVerified === true,
        };
      }
    }
    return safe;
  } catch { return {}; }
}

export function importPrivateClassLinks(manifest, storage = globalThis.localStorage) {
  const incoming = validatePrivateClassLinkManifest(manifest);
  if (!storage || typeof storage.setItem !== 'function') {
    throw new Error('이 기기의 저장소에 접근할 수 없습니다.');
  }
  const merged = { ...readPrivateClassLinks(storage), ...incoming };
  storage.setItem(PRIVATE_CLASS_LINK_STORAGE_KEY, JSON.stringify(merged));
  return { imported:Object.keys(incoming).length, total:Object.keys(merged).length };
}

export function classTimeRangeStartSeconds(range) {
  const start = String(range || '').split(/[–—-]/)[0].trim();
  const parts = start.split(':').map(Number);
  if (parts.length < 2 || parts.length > 3 ||
      parts.some(part => !Number.isInteger(part) || part < 0) ||
      parts.slice(1).some(part => part >= 60)) return null;
  return parts.reduce((total,part) => total * 60 + part, 0);
}

export function classYoutubeWatchUrl(links, source, range = '') {
  const record = links?.[source];
  if (!record || !VIDEO_ID_RE.test(record.videoId)) return null;
  const base = 'https://www.youtube.com/watch?v=' + record.videoId;
  if (!range) return base;
  if (record.tcCoverageVerified !== true) return null;
  const seconds = classTimeRangeStartSeconds(range);
  if (seconds == null || seconds >= record.sourceDurationSeconds) return null;
  return base + '&t=' + seconds + 's';
}

export function classSourceShortLabel(source, multiple) {
  if (!multiple) return '수업 영상';
  const match = /^20\d{6}_(\d{2})(\d{2})\d{2}\.mp4$/.exec(String(source || ''));
  return match ? match[1] + ':' + match[2] + ' 촬영 수업' : '수업 영상';
}


export function classHistoryVideoSourceMarkup(day, links, escapeHtml) {
  const sources = [...(day.sources || [])].sort();
  if (!sources.length) return '';
  return '<div class="classHistorySource"><small>그날의 수업 영상 · 유튜브</small>' +
    sources.map(source => {
      const title = classSourceShortLabel(source, sources.length > 1);
      const href = classYoutubeWatchUrl(links, source);
      return '<div class="classHistoryVideoRow"><b>' + escapeHtml(title) + '</b>' +
        (href ? '<a class="classHistoryVideoLink" href="' + escapeHtml(href) +
          '" target="_blank" rel="noopener noreferrer">유튜브에서 수업 보기 ↗</a>'
          : '<span class="classHistorySourcePending">영상 연결 대기</span>') +
        '</div>';
    }).join('') + '</div>';
}

export function classHistoryTimeMarkup(item, links, escapeHtml) {
  const ranges = item.sourceTimeRanges || [];
  return ranges.map(range => {
    const href = classYoutubeWatchUrl(links, item.sourceMedia, range);
    if (href) return '<a class="classHistoryTimeLink" href="' + escapeHtml(href) +
      '" target="_blank" rel="noopener noreferrer">' + escapeHtml(range) + '부터 보기 ↗</a>';
    return '<i>' + escapeHtml(range) + ' · 영상 연결 대기</i>';
  }).join('');
}
