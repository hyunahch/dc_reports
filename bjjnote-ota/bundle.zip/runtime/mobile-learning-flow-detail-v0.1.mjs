import { loadTechniqueRecords } from './canonical-data-loader.mjs';
import { FLOW_DEFINITIONS, buildAllLearningFlows } from './learning-flow-v0.1.mjs';

const STYLE_ID = 'mobile-learning-flow-detail-style';
const POSITION_NAMES = {
  'closed-guard': '클로즈드가드',
  'bottom-side-control': '바텀 사이드컨트롤',
  mount: '마운트',
  'spider-guard': '스파이더가드',
};

let flows = [];
let activeFlowId = null;
let ready = false;

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>'"]/g, char => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;'
  }[char]));
}

function ensureStyle() {
  if (document.getElementById(STYLE_ID)) return;
  const style = document.createElement('style');
  style.id = STYLE_ID;
  style.textContent = `
.learningFlowIndex{display:grid;gap:10px;margin-top:14px}.learningFlowIndexCard{width:100%;border:1px solid #E3E8EC;border-radius:18px;background:#fff;padding:16px;text-align:left;color:#1A232D;position:relative}.learningFlowIndexCard::after{content:'›';position:absolute;right:16px;top:50%;transform:translateY(-50%);font-size:22px;color:#A2AFBA}.learningFlowIndexCard b{display:block;font-size:14px;padding-right:22px}.learningFlowIndexCard p{font-size:11px;line-height:1.5;color:#667381;margin:6px 28px 0 0}.learningFlowIndexMeta{display:flex;gap:6px;flex-wrap:wrap;margin-top:10px}.learningFlowIndexMeta span{font-size:9px;font-weight:800;color:#667381;background:#F2F5F7;border-radius:999px;padding:5px 8px}
.learningFlowBack{border:0;background:transparent;padding:0;color:#1C2B44;font-size:12px;font-weight:800;margin:4px 0 12px}.learningFlowHero{border-radius:20px;background:#1C2B44;color:#fff;padding:18px}.learningFlowHero small{font-size:9px;font-weight:800;opacity:.62}.learningFlowHero h2{font-size:20px;letter-spacing:-.04em;margin:7px 0 5px}.learningFlowHero p{font-size:11px;line-height:1.55;margin:0;opacity:.8}.learningFlowHeroMeta{display:flex;gap:7px;flex-wrap:wrap;margin-top:12px}.learningFlowHeroMeta span{font-size:9px;font-weight:800;padding:5px 8px;border-radius:999px;background:rgba(255,255,255,.12)}
.learningFlowSectionHead{display:flex;align-items:end;justify-content:space-between;margin:24px 0 10px}.learningFlowSectionHead h2{font-size:18px;margin:0}.learningFlowSectionHead span{font-size:10px;color:#8498A8}.learningFlowChain{position:relative;display:grid;gap:8px}.learningFlowChain::before{content:'';position:absolute;left:17px;top:18px;bottom:18px;width:2px;background:#E3E8EC}.learningFlowNode{width:100%;border:1px solid #E3E8EC;background:#fff;border-radius:16px;padding:12px 12px 12px 46px;text-align:left;color:#1C2B44;position:relative}.learningFlowNodeIndex{position:absolute;left:7px;top:50%;transform:translateY(-50%);width:22px;height:22px;border-radius:50%;display:grid;place-items:center;background:#1C2B44;color:#fff;font-size:9px;font-weight:800;z-index:1}.learningFlowNode b{display:block;font-size:12px}.learningFlowNode small{display:block;font-size:9px;color:#8498A8;margin-top:4px;line-height:1.4}.learningFlowNode i{position:absolute;right:12px;top:50%;transform:translateY(-50%);font-style:normal;color:#8498A8}
.learningReactionGroups{display:grid;gap:14px}.learningReactionGroup{border-radius:18px;background:#F7F8FA;padding:12px}.learningReactionSource{display:flex;align-items:center;justify-content:space-between;padding:2px 2px 9px}.learningReactionSource b{font-size:12px;color:#1C2B44}.learningReactionSource span{font-size:9px;color:#8498A8}.learningReactionList{display:grid;gap:8px}.learningReactionCard{background:#fff;border:1px solid #E3E8EC;border-radius:14px;padding:12px}.learningReactionCard small{display:block;color:#8498A8;font-size:9px;font-weight:800}.learningReactionCard b{display:block;font-size:12px;color:#1A232D;margin:4px 0}.learningReactionCard p{font-size:11px;line-height:1.5;color:#667381;margin:0}.learningReactionAction{display:flex;gap:6px;align-items:center;flex-wrap:wrap;margin-top:10px}.learningReactionTag{font-size:9px;font-weight:800;color:#667381;background:#F2F5F7;border-radius:999px;padding:5px 8px}.learningReactionNext{border:0;background:#1C2B44;color:#fff;border-radius:999px;padding:6px 9px;font-size:9px;font-weight:800}.learningReactionOutcome{font-size:9px;font-weight:800;color:#1C2B44;background:#E9EEF2;border-radius:999px;padding:5px 8px}
.learningFlowEmpty{border:1px dashed #C8D1D8;border-radius:14px;padding:16px;text-align:center;color:#8498A8;font-size:10px}
`;
  document.head.appendChild(style);
}

function flowName(flow, techniqueId) {
  return flow.nodes.find(node => node.techniqueId === techniqueId)?.nameKo || techniqueId;
}

function openTechnique(techniqueId, positionId) {
  globalThis.__BJJ_MOBILE_SHELL__?.show?.('tech');
  document.querySelector(`#positions button[data-id="${positionId}"]`)?.click();
  queueMicrotask(() => document.querySelector(`#techniques .card[data-tech="${techniqueId}"]`)?.click());
}

function renderIndex(flowShell, switchEl) {
  const wrapper = document.createElement('div');
  wrapper.id = 'mobileLearningFlowEnhanced';
  wrapper.innerHTML = `
    <div class="shellTitle"><h2>기술 흐름</h2><span>${flows.length}개 흐름</span></div>
    <p class="hint">상대 반응에 따라 검증된 기술 연결을 한 흐름씩 깊게 봅니다.</p>
    <div class="learningFlowIndex">${flows.map(flow => `
      <button class="learningFlowIndexCard" data-learning-flow-id="${escapeHtml(flow.id)}">
        <b>${escapeHtml(flow.title)}</b>
        <p>${escapeHtml(flow.description)}</p>
        <div class="learningFlowIndexMeta"><span>${escapeHtml(POSITION_NAMES[flow.positionId] || flow.positionId)}</span><span>${flow.nodes.length}개 기술</span><span>${flow.edges.length}개 반응</span></div>
      </button>`).join('')}</div>`;
  switchEl.insertAdjacentElement('afterend', wrapper);
  wrapper.querySelectorAll('[data-learning-flow-id]').forEach(button => button.onclick = () => {
    activeFlowId = button.dataset.learningFlowId;
    enhance(true);
    window.scrollTo({ top: 0, behavior: 'instant' });
  });
}

function renderDetail(flowShell, switchEl, flow) {
  const edgesBySource = new Map();
  flow.nodes.forEach(node => edgesBySource.set(node.techniqueId, []));
  flow.edges.forEach(edge => {
    if (!edgesBySource.has(edge.fromTechniqueId)) edgesBySource.set(edge.fromTechniqueId, []);
    edgesBySource.get(edge.fromTechniqueId).push(edge);
  });

  const wrapper = document.createElement('div');
  wrapper.id = 'mobileLearningFlowEnhanced';
  wrapper.innerHTML = `
    <button class="learningFlowBack" id="mobileLearningFlowBack">← 기술 흐름</button>
    <div class="learningFlowHero">
      <small>${escapeHtml(POSITION_NAMES[flow.positionId] || flow.positionId)} · REACTION FLOW</small>
      <h2>${escapeHtml(flow.title)}</h2>
      <p>${escapeHtml(flow.description)}</p>
      <div class="learningFlowHeroMeta"><span>${flow.nodes.length}개 기술</span><span>${flow.edges.length}개 반응 연결</span></div>
    </div>
    <div class="learningFlowSectionHead"><h2>기술 연결</h2><span>눌러서 기술 보기</span></div>
    <div class="learningFlowChain">${flow.nodes.map((node, index) => `
      <button class="learningFlowNode" data-learning-tech="${escapeHtml(node.techniqueId)}" data-learning-position="${escapeHtml(flow.positionId)}">
        <span class="learningFlowNodeIndex">${index + 1}</span>
        <b>${escapeHtml(node.nameKo)}</b>
        <small>${escapeHtml(node.routeLabel || '이 포지션에서 연결')}</small>
        <i>›</i>
      </button>`).join('')}</div>
    <div class="learningFlowSectionHead"><h2>상대 반응별 선택</h2><span>${flow.edges.length}개 분기</span></div>
    <div class="learningReactionGroups">${flow.nodes.map(node => {
      const edges = edgesBySource.get(node.techniqueId) || [];
      if (!edges.length) return '';
      return `<section class="learningReactionGroup" data-learning-source="${escapeHtml(node.techniqueId)}">
        <div class="learningReactionSource"><b>${escapeHtml(node.nameKo)}에서</b><span>${edges.length}개 반응</span></div>
        <div class="learningReactionList">${edges.map(edge => {
          const next = edge.toTechniqueId ? `<button class="learningReactionNext" data-learning-next-tech="${escapeHtml(edge.toTechniqueId)}" data-learning-position="${escapeHtml(flow.positionId)}">→ ${escapeHtml(flowName(flow, edge.toTechniqueId))}</button>`
            : edge.outcomePositionId ? `<span class="learningReactionOutcome">→ ${escapeHtml(edge.outcomePositionId)}</span>`
            : '<span class="learningReactionOutcome">→ 컨트롤 유지 · 재선택</span>';
          return `<article class="learningReactionCard" data-learning-edge="${escapeHtml(edge.id)}">
            <small>상대가 이렇게 하면</small>
            <b>${escapeHtml(edge.opponentReaction)}</b>
            <p>${escapeHtml(edge.responseSummary)}</p>
            <div class="learningReactionAction"><span class="learningReactionTag">${edge.scope === 'core' ? 'Core 반응' : 'Entry 반응'}</span>${next}</div>
          </article>`;
        }).join('')}</div>
      </section>`;
    }).join('') || '<div class="learningFlowEmpty">아직 연결된 상대 반응이 없습니다.</div>'}</div>`;
  switchEl.insertAdjacentElement('afterend', wrapper);
  wrapper.querySelector('#mobileLearningFlowBack').onclick = () => {
    activeFlowId = null;
    enhance(true);
    window.scrollTo({ top: 0, behavior: 'instant' });
  };
  wrapper.querySelectorAll('[data-learning-tech]').forEach(button => button.onclick = () => openTechnique(button.dataset.learningTech, button.dataset.learningPosition));
  wrapper.querySelectorAll('[data-learning-next-tech]').forEach(button => button.onclick = () => openTechnique(button.dataset.learningNextTech, button.dataset.learningPosition));
}

function learningModeActive(switchEl) {
  return switchEl?.querySelector('[data-mobile-flow-mode="learning"]')?.classList.contains('active');
}

function enhance(force = false) {
  if (!ready) return false;
  const flowShell = document.getElementById('flowShell');
  const switchEl = flowShell?.querySelector('#mobileFlowModeSwitch');
  if (!flowShell || !switchEl || !learningModeActive(switchEl)) return false;
  if (!force && flowShell.querySelector('#mobileLearningFlowEnhanced')) return true;

  let sibling = switchEl.nextElementSibling;
  while (sibling) {
    const next = sibling.nextElementSibling;
    sibling.remove();
    sibling = next;
  }

  const flow = activeFlowId ? flows.find(item => item.id === activeFlowId) : null;
  if (flow) renderDetail(flowShell, switchEl, flow);
  else renderIndex(flowShell, switchEl);
  return true;
}

function resetWhenModeChanges(event) {
  const button = event.target.closest?.('#mobileFlowModeSwitch button');
  if (!button) return;
  if (button.dataset.mobileFlowMode !== 'learning') activeFlowId = null;
  setTimeout(() => enhance(true), 0);
}

document.addEventListener('click', resetWhenModeChanges, true);

const observer = new MutationObserver(() => queueMicrotask(() => enhance(false)));
observer.observe(document.documentElement, { childList: true, subtree: true });

async function init() {
  ensureStyle();
  const techniques = await loadTechniqueRecords();
  flows = buildAllLearningFlows(Object.fromEntries(techniques.map(item => [item.id, item])), FLOW_DEFINITIONS);
  ready = true;
  enhance(true);
  globalThis.__BJJ_LEARNING_FLOW_DETAIL__ = {
    version: 'v0.1',
    get activeFlowId() { return activeFlowId; },
    back() {
      if (!activeFlowId) return false;
      activeFlowId = null;
      enhance(true);
      window.scrollTo({ top: 0, behavior: 'instant' });
      return true;
    },
    enhance,
  };
}

init().catch(error => console.error('mobile learning flow detail init failed', error));
