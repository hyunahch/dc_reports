function active(selector) {
  return Boolean(document.querySelector(selector));
}

function click(selector) {
  const el = document.querySelector(selector);
  if (!el) return false;
  el.click();
  return true;
}

function goHome() {
  return click('.bottom button[data-shell-tab="home"]');
}

function handleAndroidBack() {
  // Fullscreen media is the shallowest layer. Exit it before any in-app navigation.
  if (window.__BJJ_YOUTUBE_FULLSCREEN_BACK__?.handleBack?.()) {
    return true;
  }

  // Position playbook is a shallow layer between a technique/position and Flow.
  if (active('#positionPlaybookShell.active')) {
    return window.__BJJ_POSITION_PLAYBOOK__?.close?.() ?? false;
  }

  // Technique / drill detail: respect the existing in-app back target first.
  if (active('#detail.active')) {
    return click('#detailRoot .back') || goHome();
  }

  // Competition scenario detail: return to the scenario list, not out of the app.
  if (active('#flowShell.active #mobileScenarioBack')) {
    return click('#mobileScenarioBack');
  }

  // Learning-flow detail: return to the four-flow index first.
  if (active('#flowShell.active #mobileLearningFlowBack')) {
    return click('#mobileLearningFlowBack');
  }

  // Legacy expandable cards, if ever present, remain one shallow navigation layer.
  const openFlowCard = document.querySelector('#flowShell.active .flowCard.open .flowToggle');
  if (openFlowCard) {
    openFlowCard.click();
    return true;
  }

  // Any top-level tab except Home returns to Home first.
  if (active('#index.active') || active('#flowShell.active') || active('#noteShell.active')) {
    return goHome();
  }

  // Legacy/unknown visible panels should not kill the task unexpectedly.
  if (active('#legacy.active')) {
    return goHome();
  }

  // Only Home (or an unrecoverable state) is allowed to fall through to native exit.
  return false;
}

window.__BJJ_HANDLE_ANDROID_BACK__ = handleAndroidBack;
// Keep the public debug marker stable; behavior changes are covered by the fullscreen guard version.
window.__BJJ_ANDROID_BACK_NAV__ = { version: 'v0.1', handle: handleAndroidBack };
