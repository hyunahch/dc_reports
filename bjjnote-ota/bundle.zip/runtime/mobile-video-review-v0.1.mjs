const DB_NAME = 'bjjnote.videoReview.v1';
const DB_VERSION = 1;
const STORE = 'entries';
const MAX_FILE_BYTES = 150 * 1024 * 1024;

const SITUATIONS = [
  ['match-opening', '경기 시작'],
  ['guard-pull', '가드 풀 대응'],
  ['top-side', '탑 사이드'],
  ['mount-escape', '마운트 탈출'],
  ['free', '자유 분석'],
];

const ATHLETE_OPTIONS = [
  ['white-gi', '내가 흰 도복'],
  ['blue-gi', '내가 파란/어두운 도복'],
  ['left', '내가 화면 왼쪽'],
  ['right', '내가 화면 오른쪽'],
];

let selectedFile = null;
let selectedPreviewUrl = null;
let selectedDuration = null;
let mounted = false;

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>'\"]/g, char => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '\"': '&quot;'
  }[char]));
}

function formatBytes(bytes) {
  if (!Number.isFinite(bytes)) return '';
  if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))}KB`;
  return `${(bytes / 1024 / 1024).toFixed(bytes >= 10 * 1024 * 1024 ? 0 : 1)}MB`;
}

function formatDuration(seconds) {
  if (!Number.isFinite(seconds) || seconds <= 0) return '길이 확인 전';
  const whole = Math.round(seconds);
  const min = Math.floor(whole / 60);
  const sec = whole % 60;
  return min ? `${min}:${String(sec).padStart(2, '0')}` : `${sec}초`;
}

function situationLabel(id) {
  return SITUATIONS.find(([value]) => value === id)?.[1] || '자유 분석';
}

function athleteLabel(id) {
  return ATHLETE_OPTIONS.find(([value]) => value === id)?.[1] || '';
}

function openDb() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE)) {
        const store = db.createObjectStore(STORE, { keyPath: 'id' });
        store.createIndex('createdAt', 'createdAt');
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('영상 저장소를 열 수 없습니다.'));
  });
}

async function dbPut(entry) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).put(entry);
    tx.oncomplete = () => { db.close(); resolve(); };
    tx.onerror = () => { db.close(); reject(tx.error || new Error('영상 복기 저장에 실패했습니다.')); };
  });
}

async function dbList() {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readonly');
    const request = tx.objectStore(STORE).getAll();
    request.onsuccess = () => resolve((request.result || []).sort((a, b) => b.createdAt - a.createdAt));
    request.onerror = () => reject(request.error || new Error('영상 복기를 불러오지 못했습니다.'));
    tx.oncomplete = () => db.close();
  });
}

async function dbGet(id) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readonly');
    const request = tx.objectStore(STORE).get(id);
    request.onsuccess = () => resolve(request.result || null);
    request.onerror = () => reject(request.error || new Error('영상을 불러오지 못했습니다.'));
    tx.oncomplete = () => db.close();
  });
}

async function dbDelete(id) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE, 'readwrite');
    tx.objectStore(STORE).delete(id);
    tx.oncomplete = () => { db.close(); resolve(); };
    tx.onerror = () => { db.close(); reject(tx.error || new Error('영상 복기를 삭제하지 못했습니다.')); };
  });
}

function stopLocalPlayback(root = document) {
  root.querySelectorAll?.('[data-video-review-player]').forEach(video => {
    try { video.pause(); } catch {}
    try { video.removeAttribute('src'); video.load(); } catch {}
  });
  root.querySelectorAll?.('[data-video-review-object-url]').forEach(el => {
    const url = el.dataset.videoReviewObjectUrl;
    if (url) URL.revokeObjectURL(url);
    delete el.dataset.videoReviewObjectUrl;
  });
}

function addStyles() {
  if (document.getElementById('mobile-video-review-style')) return;
  const style = document.createElement('style');
  style.id = 'mobile-video-review-style';
  style.textContent = `
    .noteModeSwitch{display:grid;grid-template-columns:1fr 1fr;background:#EEF2F5;border-radius:13px;padding:3px;margin:0 0 15px}.noteModeSwitch button{border:0;border-radius:10px;padding:9px 8px;background:transparent;color:#8498A8;font-size:10px;font-weight:900}.noteModeSwitch button.active{background:#fff;color:#1C2B44;box-shadow:0 2px 8px rgba(28,43,68,.08)}
    [data-note-mode-pane][hidden]{display:none!important}.videoReviewHero{border-radius:18px;background:#1C2B44;color:#fff;padding:16px;margin-bottom:10px}.videoReviewHero small{font-size:9px;font-weight:900;opacity:.6}.videoReviewHero h3{font-size:17px;margin:5px 0 5px}.videoReviewHero p{margin:0;font-size:10px;line-height:1.55;opacity:.78}.videoReviewPrivacy{border-radius:13px;background:#F2F5F7;padding:10px 12px;font-size:9px;line-height:1.5;color:#667381;margin-bottom:12px}.videoReviewComposer{border:1px solid #E3E8EC;background:#fff;border-radius:17px;padding:13px}.videoReviewFileLabel{display:flex;align-items:center;justify-content:space-between;gap:10px;border:1px dashed #AAB6BF;border-radius:14px;padding:13px;color:#1C2B44;cursor:pointer}.videoReviewFileLabel b{font-size:11px}.videoReviewFileLabel span{font-size:9px;color:#8498A8}.videoReviewFileLabel input{display:none}.videoReviewSelected{margin:9px 0 0;font-size:9px;color:#667381}.videoReviewPreview{margin-top:10px;border-radius:14px;overflow:hidden;background:#111}.videoReviewPreview[hidden]{display:none}.videoReviewPreview video{display:block;width:100%;max-height:300px;background:#111}.videoReviewFields{display:grid;gap:9px;margin-top:11px}.videoReviewField label{display:block;font-size:9px;font-weight:900;color:#8498A8;margin:0 0 5px}.videoReviewField select,.videoReviewField textarea{width:100%;border:1px solid #E3E8EC;border-radius:11px;background:#fff;padding:10px;font:inherit;font-size:11px;color:#1C2B44;outline:none}.videoReviewField textarea{min-height:72px;resize:vertical;line-height:1.5}.videoReviewSave{width:100%;height:42px;border:0;border-radius:12px;background:#1C2B44;color:#fff;font-size:11px;font-weight:900;margin-top:10px}.videoReviewStatus{min-height:18px;margin-top:7px;font-size:9px;line-height:1.45;color:#667381}.videoReviewStatus.isError{color:#A14848}.videoReviewAiNotice{margin-top:12px;padding:12px;border-radius:14px;background:#F7F8FA;border:1px solid #E7EBEE}.videoReviewAiNotice small{display:block;font-size:9px;color:#8498A8;font-weight:900}.videoReviewAiNotice b{display:block;font-size:11px;color:#1C2B44;margin:4px 0}.videoReviewAiNotice p{margin:0;font-size:9px;line-height:1.5;color:#667381}.videoReviewList{display:grid;gap:9px;margin-top:10px}.videoReviewCard{border:1px solid #E3E8EC;border-radius:15px;background:#fff;padding:12px}.videoReviewCardHead{display:flex;justify-content:space-between;gap:10px;align-items:flex-start}.videoReviewCardHead small{font-size:9px;color:#8498A8;font-weight:800}.videoReviewCardHead b{display:block;font-size:12px;color:#1C2B44;margin-top:3px}.videoReviewBadge{flex:0 0 auto;border-radius:999px;background:#EEF2F5;color:#667381;padding:5px 7px;font-size:8px;font-weight:900}.videoReviewCardMeta{display:flex;gap:5px;flex-wrap:wrap;margin-top:8px}.videoReviewCardMeta span{border-radius:999px;background:#F7F8FA;color:#667381;padding:5px 7px;font-size:8px;font-weight:800}.videoReviewCardNote{font-size:10px;line-height:1.5;color:#667381;margin:8px 0 0}.videoReviewCardActions{display:flex;gap:6px;margin-top:10px}.videoReviewCardActions button{flex:1;border:1px solid #DDE4E9;background:#fff;color:#1C2B44;border-radius:10px;height:34px;font-size:9px;font-weight:900}.videoReviewCardActions .danger{color:#8E5656}.videoReviewInlinePlayer{margin-top:9px;border-radius:12px;overflow:hidden;background:#111}.videoReviewInlinePlayer video{display:block;width:100%;max-height:300px}.videoReviewEmpty{border:1px dashed #AAB6BF;border-radius:14px;padding:17px;text-align:center;font-size:10px;line-height:1.5;color:#8498A8}.videoReviewListTitle{display:flex;justify-content:space-between;align-items:end;margin:18px 0 0}.videoReviewListTitle h3{margin:0;font-size:15px;color:#1C2B44}.videoReviewListTitle span{font-size:9px;color:#8498A8}
  `;
  document.head.appendChild(style);
}

function reviewPaneMarkup() {
  return `
    <div data-note-mode-pane="video" hidden>
      <section class="videoReviewHero"><small>PRIVATE VIDEO REVIEW</small><h3>영상 복기</h3><p>짧은 상황 영상을 저장하고, 어떤 장면을 분석할지 먼저 표시해 둡니다.</p></section>
      <div class="videoReviewPrivacy"><b>현재 단계에서는 영상이 이 기기에만 저장됩니다.</b><br>AI 분석 서버 연결 전에는 외부로 업로드하지 않습니다. 60초 이하의 짧은 상황 영상을 권장합니다.</div>
      <section class="videoReviewComposer">
        <label class="videoReviewFileLabel"><span><b>영상 선택</b><br><span>갤러리에서 짧은 스파링/상황 영상 고르기</span></span><span>선택 →</span><input id="videoReviewInput" type="file" accept="video/*"></label>
        <div class="videoReviewSelected" id="videoReviewSelected">아직 선택한 영상이 없습니다.</div>
        <div class="videoReviewPreview" id="videoReviewPreview" hidden><video id="videoReviewPreviewPlayer" controls playsinline preload="metadata"></video></div>
        <div class="videoReviewFields">
          <div class="videoReviewField"><label for="videoReviewSituation">분석할 상황</label><select id="videoReviewSituation">${SITUATIONS.map(([id,label])=>`<option value="${id}">${label}</option>`).join('')}</select></div>
          <div class="videoReviewField"><label for="videoReviewAthlete">영상 속 나</label><select id="videoReviewAthlete">${ATHLETE_OPTIONS.map(([id,label])=>`<option value="${id}">${label}</option>`).join('')}</select></div>
          <div class="videoReviewField"><label for="videoReviewNote">지금 궁금한 것 · 선택</label><textarea id="videoReviewNote" placeholder="예: 상대가 앉는 순간 왜 발이 멈추는지 보고 싶음"></textarea></div>
        </div>
        <button class="videoReviewSave" id="videoReviewSave" type="button">영상 복기 저장</button>
        <div class="videoReviewStatus" id="videoReviewStatus" aria-live="polite"></div>
        <div class="videoReviewAiNotice"><small>AI 분석 연결 단계</small><b>분석 결과 형식은 준비되어 있어요</b><p>다음 연결에서는 잘한 점 · 가장 큰 문제 3개 · 타임라인 · 다음 훈련 큐를 이 기록에 붙입니다. API 키는 앱에 넣지 않고 서버에서만 사용합니다.</p></div>
      </section>
      <div class="videoReviewListTitle"><h3>최근 영상 복기</h3><span id="videoReviewCount">0개</span></div>
      <div class="videoReviewList" id="videoReviewList"></div>
    </div>`;
}

function setStatus(note, message, isError = false) {
  const el = note.querySelector('#videoReviewStatus');
  if (!el) return;
  el.textContent = message;
  el.classList.toggle('isError', isError);
}

function resetSelection(note) {
  if (selectedPreviewUrl) URL.revokeObjectURL(selectedPreviewUrl);
  selectedPreviewUrl = null;
  selectedFile = null;
  selectedDuration = null;
  const input = note.querySelector('#videoReviewInput');
  if (input) input.value = '';
  const preview = note.querySelector('#videoReviewPreview');
  const player = note.querySelector('#videoReviewPreviewPlayer');
  if (player) { try { player.pause(); } catch {} player.removeAttribute('src'); try { player.load(); } catch {} }
  if (preview) preview.hidden = true;
  const selected = note.querySelector('#videoReviewSelected');
  if (selected) selected.textContent = '아직 선택한 영상이 없습니다.';
}

function onFileSelected(note, file) {
  resetSelection(note);
  if (!file) return;
  if (!String(file.type || '').startsWith('video/')) {
    setStatus(note, '동영상 파일을 선택해 주세요.', true);
    return;
  }
  if (file.size > MAX_FILE_BYTES) {
    setStatus(note, '영상이 150MB보다 큽니다. 짧게 잘라서 다시 선택해 주세요.', true);
    return;
  }
  selectedFile = file;
  selectedPreviewUrl = URL.createObjectURL(file);
  const selected = note.querySelector('#videoReviewSelected');
  if (selected) selected.textContent = `${file.name} · ${formatBytes(file.size)}`;
  const preview = note.querySelector('#videoReviewPreview');
  const player = note.querySelector('#videoReviewPreviewPlayer');
  if (player) {
    player.src = selectedPreviewUrl;
    player.onloadedmetadata = () => {
      selectedDuration = Number.isFinite(player.duration) ? player.duration : null;
      if (selected) selected.textContent = `${file.name} · ${formatBytes(file.size)} · ${formatDuration(selectedDuration)}`;
    };
  }
  if (preview) preview.hidden = false;
  setStatus(note, '상황과 영상 속 나를 확인한 뒤 저장하세요.');
}

function cardMarkup(entry) {
  const date = new Date(entry.createdAt).toLocaleString('ko-KR', { month:'numeric', day:'numeric', hour:'2-digit', minute:'2-digit' });
  return `
    <article class="videoReviewCard" data-video-review-entry="${escapeHtml(entry.id)}">
      <div class="videoReviewCardHead"><div><small>${escapeHtml(date)}</small><b>${escapeHtml(situationLabel(entry.situation))}</b></div><span class="videoReviewBadge">AI 연결 대기</span></div>
      <div class="videoReviewCardMeta"><span>${escapeHtml(athleteLabel(entry.athlete))}</span><span>${escapeHtml(formatDuration(entry.durationSec))}</span><span>${escapeHtml(formatBytes(entry.fileSize))}</span></div>
      ${entry.note ? `<p class="videoReviewCardNote">${escapeHtml(entry.note)}</p>` : ''}
      <div class="videoReviewCardActions"><button type="button" data-video-review-open="${escapeHtml(entry.id)}">영상 보기</button><button type="button" class="danger" data-video-review-delete="${escapeHtml(entry.id)}">삭제</button></div>
      <div class="videoReviewInlinePlayer" data-video-review-player-wrap hidden></div>
    </article>`;
}

async function renderEntries(note) {
  const list = note.querySelector('#videoReviewList');
  const count = note.querySelector('#videoReviewCount');
  if (!list || !count) return;
  try {
    const entries = await dbList();
    count.textContent = `${entries.length}개`;
    list.innerHTML = entries.length ? entries.map(cardMarkup).join('') : '<div class="videoReviewEmpty">아직 저장한 영상 복기가 없습니다.<br>지금 연습하는 짧은 장면부터 하나씩 쌓아보세요.</div>';
  } catch (error) {
    count.textContent = '';
    list.innerHTML = `<div class="videoReviewEmpty">${escapeHtml(error.message || '영상 복기를 불러오지 못했습니다.')}</div>`;
  }
}

async function saveReview(note) {
  if (!selectedFile) {
    setStatus(note, '먼저 영상을 선택해 주세요.', true);
    return;
  }
  const button = note.querySelector('#videoReviewSave');
  if (button) button.disabled = true;
  setStatus(note, '이 기기에 영상을 저장하고 있어요…');
  try {
    const entry = {
      id: `review-${Date.now()}-${Math.random().toString(36).slice(2,8)}`,
      createdAt: Date.now(),
      situation: note.querySelector('#videoReviewSituation')?.value || 'free',
      athlete: note.querySelector('#videoReviewAthlete')?.value || 'white-gi',
      note: note.querySelector('#videoReviewNote')?.value.trim() || '',
      fileName: selectedFile.name,
      fileType: selectedFile.type,
      fileSize: selectedFile.size,
      durationSec: selectedDuration,
      blob: selectedFile,
      analysisStatus: 'not-connected',
      analysis: null,
    };
    await dbPut(entry);
    note.querySelector('#videoReviewNote').value = '';
    resetSelection(note);
    setStatus(note, '영상 복기를 저장했어요.');
    await renderEntries(note);
  } catch (error) {
    setStatus(note, error.message || '영상 저장에 실패했습니다.', true);
  } finally {
    if (button) button.disabled = false;
  }
}

async function openEntryVideo(note, id) {
  const card = note.querySelector(`[data-video-review-entry="${CSS.escape(id)}"]`);
  const wrap = card?.querySelector('[data-video-review-player-wrap]');
  if (!wrap) return;
  if (!wrap.hidden) {
    stopLocalPlayback(wrap);
    wrap.replaceChildren();
    wrap.hidden = true;
    return;
  }
  stopLocalPlayback(note);
  note.querySelectorAll('[data-video-review-player-wrap]').forEach(item => { item.replaceChildren(); item.hidden = true; });
  try {
    const entry = await dbGet(id);
    if (!entry?.blob) return;
    const url = URL.createObjectURL(entry.blob);
    const video = document.createElement('video');
    video.controls = true;
    video.playsInline = true;
    video.preload = 'metadata';
    video.src = url;
    video.dataset.videoReviewPlayer = '1';
    video.dataset.videoReviewObjectUrl = url;
    wrap.replaceChildren(video);
    wrap.hidden = false;
  } catch (error) {
    setStatus(note, error.message || '영상을 열지 못했습니다.', true);
  }
}

async function deleteEntry(note, id) {
  stopLocalPlayback(note);
  try {
    await dbDelete(id);
    await renderEntries(note);
    setStatus(note, '영상 복기를 삭제했어요.');
  } catch (error) {
    setStatus(note, error.message || '삭제하지 못했습니다.', true);
  }
}

function setMode(note, mode) {
  const memo = note.querySelector('[data-note-mode-pane="memo"]');
  const video = note.querySelector('[data-note-mode-pane="video"]');
  note.querySelectorAll('[data-note-mode]').forEach(button => button.classList.toggle('active', button.dataset.noteMode === mode));
  if (memo) memo.hidden = mode !== 'memo';
  if (video) video.hidden = mode !== 'video';
  if (mode !== 'video') stopLocalPlayback(note);
  if (mode === 'video') renderEntries(note);
}

function bind(note) {
  note.querySelectorAll('[data-note-mode]').forEach(button => {
    button.addEventListener('click', () => setMode(note, button.dataset.noteMode));
  });
  note.querySelector('#videoReviewInput')?.addEventListener('change', event => onFileSelected(note, event.target.files?.[0] || null));
  note.querySelector('#videoReviewSave')?.addEventListener('click', () => saveReview(note));
  note.addEventListener('click', event => {
    const open = event.target.closest?.('[data-video-review-open]');
    if (open) { event.preventDefault(); openEntryVideo(note, open.dataset.videoReviewOpen); return; }
    const remove = event.target.closest?.('[data-video-review-delete]');
    if (remove) { event.preventDefault(); deleteEntry(note, remove.dataset.videoReviewDelete); }
  });
  document.querySelectorAll('.bottom button').forEach(button => button.addEventListener('click', () => {
    if (button.dataset.shellTab !== 'note') stopLocalPlayback(note);
  }));
  document.addEventListener('visibilitychange', () => { if (document.hidden) stopLocalPlayback(note); });
}

function mount() {
  if (mounted) return true;
  const note = document.querySelector('#noteShell');
  if (!note) return false;
  if (note.querySelector('[data-note-mode-switch="1"]')) { mounted = true; return true; }
  addStyles();
  const memoPane = document.createElement('div');
  memoPane.dataset.noteModePane = 'memo';
  while (note.firstChild) memoPane.appendChild(note.firstChild);
  const switchEl = document.createElement('div');
  switchEl.className = 'noteModeSwitch';
  switchEl.dataset.noteModeSwitch = '1';
  switchEl.innerHTML = '<button type="button" class="active" data-note-mode="memo">훈련 메모</button><button type="button" data-note-mode="video">영상 복기</button>';
  note.append(switchEl, memoPane);
  note.insertAdjacentHTML('beforeend', reviewPaneMarkup());
  bind(note);
  renderEntries(note);
  mounted = true;
  globalThis.__BJJ_VIDEO_REVIEW__ = {
    version: 'v0.1',
    mounted: true,
    storage: 'indexeddb-local-only',
    aiConnected: false,
    situations: SITUATIONS.length,
    stopPlayback: () => stopLocalPlayback(note),
  };
  return true;
}

const observer = new MutationObserver(() => queueMicrotask(mount));
observer.observe(document.documentElement, { childList: true, subtree: true });
mount();

export { mount, stopLocalPlayback };
