import { getCompetitionFinishPlan } from './competition-finish-plans-v0.1.mjs';

const STANDING_SCENARIO_ID = 'match-start-opponent-first-grip-stays-standing';
const STANDING_STEP_ID = 'establish-role-grips';

function finishMarkup(finish) {
  return `
    <section class="scenarioFinish" id="mobileScenarioFinish" data-finish="${finish.id}">
      <div class="shellTitle"><h2>주력 싱글렉 마무리</h2><span>${finish.badge}</span></div>
      <div class="scenarioFinishHero"><b>${finish.title}</b><p>${finish.entryCondition}</p><small>${finish.whyThisFinish}</small></div>
      <iframe data-finish-video="${finish.video.youtubeId}" src="${finish.video.embedUrl}?playsinline=1&rel=0" title="${finish.video.title}" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
      <div class="scenarioPoints"><ul>${finish.cues.map(cue => `<li>${cue}</li>`).join('')}</ul></div>
      <div class="scenarioStepList" id="mobileFinishSteps">${finish.steps.map((step, index) => `<div class="scenarioStepItem" data-mobile-finish-step="${step.id}"><div class="scenarioStepNum">${index + 1}</div><div><b>${step.title}</b><p>${step.instruction}</p></div></div>`).join('')}</div>
      <div class="scenarioFinishSafety"><b>안전</b><p>${finish.safety}</p></div>
    </section>`;
}

function ensureStyles() {
  if (document.getElementById('competition-finish-style')) return;
  const style = document.createElement('style');
  style.id = 'competition-finish-style';
  style.textContent = `
    .scenarioFinish{margin-top:4px}.scenarioFinishHero{background:#F2F5F7;border-radius:16px;padding:14px;margin-bottom:10px}.scenarioFinishHero b{display:block;font-size:14px;color:#1C2B44}.scenarioFinishHero p{font-size:11px;line-height:1.5;color:#667381;margin:6px 0}.scenarioFinishHero small{font-size:9px;line-height:1.5;color:#8498A8}.scenarioFinish iframe{display:block;width:100%;aspect-ratio:16/9;border:0;border-radius:14px;margin:10px 0}.scenarioFinishSafety{border:1px solid #E3E8EC;border-radius:14px;padding:12px;margin-top:10px}.scenarioFinishSafety b{font-size:11px;color:#1C2B44}.scenarioFinishSafety p{font-size:10px;line-height:1.5;color:#667381;margin:4px 0 0}`;
  document.head.appendChild(style);
}

function enhance() {
  const flow = document.getElementById('flowShell');
  const steps = flow?.querySelector('#mobileScenarioSteps');
  if (!flow || !steps) return;

  const isStandingScenario = Boolean(steps.querySelector(`[data-mobile-scenario-step="${STANDING_STEP_ID}"]`));
  if (!isStandingScenario) return;
  if (flow.querySelector('#mobileScenarioFinish')) return;

  const finish = getCompetitionFinishPlan(STANDING_SCENARIO_ID);
  if (!finish) return;
  ensureStyles();
  steps.insertAdjacentHTML('afterend', finishMarkup(finish));
}

const observer = new MutationObserver(enhance);
const start = () => {
  const flow = document.getElementById('flowShell');
  if (!flow) return false;
  observer.observe(flow, { childList: true, subtree: true });
  enhance();
  return true;
};

let attempts = 0;
const timer = setInterval(() => {
  attempts += 1;
  if (start() || attempts >= 100) clearInterval(timer);
}, 25);
