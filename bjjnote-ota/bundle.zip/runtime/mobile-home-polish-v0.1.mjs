import './mobile-recent-tech-navigation-v0.1.mjs';

const TRAINING_START_DATE = new Date(2026, 6, 20);

function localDay(date = new Date()) {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate());
}

function elapsedDays(from, to = new Date()) {
  return Math.max(0, Math.floor((localDay(to) - localDay(from)) / 86400000));
}

function trainingDayNumber() {
  return elapsedDays(TRAINING_START_DATE) + 1;
}

function addStyles() {
  if (document.getElementById('mobile-home-polish-style')) return;
  const style = document.createElement('style');
  style.id = 'mobile-home-polish-style';
  style.textContent = `
    #homeShell.homePolished{padding-bottom:8px}
    #homeShell.homePolished .homeHeader{align-items:flex-start;margin-bottom:18px}
    #homeShell.homePolished .homeHeader h1{font-size:25px;line-height:1.15;letter-spacing:-.045em}
    #homeShell.homePolished .homeHeader h1::before{content:'MY BJJ';display:block;margin-bottom:4px;font-size:9px;line-height:1;font-weight:900;letter-spacing:.14em;color:#8498A8}
    #homeShell.homePolished .homeHeader button{padding:9px 12px;background:#EEF1F4;color:#667381;font-size:10px}
    #homeShell.homePolished .shellTitle{margin:22px 0 10px;align-items:end}
    #homeShell.homePolished .shellTitle h2{font-size:17px;letter-spacing:-.03em;color:#1C2B44}
    #homeShell.homePolished .todayCard{background:linear-gradient(145deg,#1C2B44,#2B405B);border-radius:22px;padding:19px 18px 20px;box-shadow:0 10px 24px rgba(28,43,68,.14)}
    #homeShell.homePolished .todayCard::before{content:'';position:absolute;width:128px;height:128px;border-radius:50%;background:rgba(255,255,255,.05);right:-42px;top:-50px}
    #homeShell.homePolished .todayCard::after{right:17px;bottom:17px;width:34px;height:34px;background:rgba(255,255,255,.13)}
    #homeShell.homePolished .todayCard small{font-size:9px;letter-spacing:.06em;opacity:.62}
    #homeShell.homePolished .todayCard b{font-size:22px}
    #homeShell.homePolished .todayCard p{font-size:11px;line-height:1.5;opacity:.72}
    #homeQuickTitle{margin-top:22px}
    #homeShell.homePolished .actionRow{gap:8px;margin-top:0}
    #homeShell.homePolished .actionRow button{border:0;background:#fff;border-radius:16px;min-height:72px;padding:11px 6px 10px;box-shadow:0 3px 12px rgba(20,35,50,.045)}
    #homeShell.homePolished .actionRow button::before{width:30px;height:30px;margin:0 auto 7px;display:grid;place-items:center;background:#F2F5F7;border-radius:10px;font-size:16px;color:#40556A}
    #homePositionHint{font-size:10px;color:#8498A8;margin:-3px 0 11px;line-height:1.5}
    #homeShell.homePolished .positionGrid{display:flex;gap:8px;overflow-x:auto;overflow-y:hidden;margin-right:-20px;padding:0 20px 4px 0;scroll-snap-type:x proximity;scrollbar-width:none;-webkit-overflow-scrolling:touch}
    #homeShell.homePolished .positionGrid::-webkit-scrollbar{display:none}
    #homeShell.homePolished .positionCard{flex:0 0 138px;min-height:78px;border:0;border-radius:16px;padding:13px 12px;box-shadow:0 3px 12px rgba(20,35,50,.04);scroll-snap-align:start;position:relative}
    #homeShell.homePolished .positionCard::before{content:'';display:block;width:24px;height:4px;border-radius:99px;background:#D8E1E8;margin-bottom:10px}
    #homeShell.homePolished .positionCard:nth-child(2)::before{width:34px}
    #homeShell.homePolished .positionCard:nth-child(3)::before{width:29px}
    #homeShell.homePolished .positionCard b{font-size:12px}
    #homeShell.homePolished .positionCard span{margin-top:7px;font-size:9px}
    #homeShell.homePolished .activityList{gap:7px}
    #homeShell.homePolished .activityItem{background:#fff;border-radius:14px;padding:12px 13px;box-shadow:0 2px 10px rgba(20,35,50,.035)}
    #homeShell.homePolished .activityItem b{font-size:11px}
    #homeShell.homePolished .activityItem i{font-size:17px;color:#A3AFB9}
    @media(min-width:700px){
      #homeShell.homePolished .positionGrid{display:grid;grid-template-columns:repeat(3,1fr);overflow:visible;margin-right:0;padding-right:0}
      #homeShell.homePolished .positionCard{min-width:0;min-height:78px}
    }
  `;
  document.head.appendChild(style);
}

function enhanceHome() {
  const home = document.getElementById('homeShell');
  if (!home || !window.__BJJ_MOBILE_SHELL__) return false;
  addStyles();
  home.classList.add('homePolished');

  const titleBlocks = [...home.querySelectorAll(':scope > .shellTitle')];
  const focusTitle = titleBlocks[0];
  if (focusTitle) {
    const h2 = focusTitle.querySelector('h2');
    const meta = focusTitle.querySelector('span');
    if (h2) h2.textContent = '오늘의 포커스';
    if (meta) meta.textContent = '이어가기';
    focusTitle.style.marginTop = '0';
  }

  const continueCard = home.querySelector('#continueCard');
  if (continueCard) {
    const label = continueCard.querySelector('small');
    if (label) label.textContent = '최근 본 기술';
  }

  // The planned November 7 competition did not happen; do not show a dated home shortcut.
  home.querySelector('#homeCompetitionCard')?.remove();

  const actionRow = home.querySelector('.actionRow');
  if (actionRow && !home.querySelector('#homeQuickTitle')) {
    const quickTitle = document.createElement('div');
    quickTitle.id = 'homeQuickTitle';
    quickTitle.className = 'shellTitle';
    quickTitle.innerHTML = '<h2>바로 시작하기</h2><span>빠른 실행</span>';
    actionRow.before(quickTitle);
  }

  const positionGrid = home.querySelector('.positionGrid');
  if (positionGrid) {
    const positionTitle = positionGrid.previousElementSibling?.classList.contains('shellTitle')
      ? positionGrid.previousElementSibling
      : [...home.querySelectorAll('.shellTitle')].find(el => el.querySelector('h2')?.textContent.includes('포지션'));
    if (positionTitle) {
      const meta = positionTitle.querySelector('span');
      if (meta) meta.textContent = '8개';
      if (!home.querySelector('#homePositionHint')) {
        const hint = document.createElement('p');
        hint.id = 'homePositionHint';
        hint.textContent = '옆으로 넘겨서 원하는 시작 포지션을 빠르게 고르세요.';
        positionTitle.after(hint);
      }
    }
  }

  window.__BJJ_HOME_POLISH__ = {
    version: 'v0.2',
    trainingStartedAt: '2026-07-20',
    trainingDay: trainingDayNumber(),
  };
  return true;
}

let attempts = 0;
const timer = setInterval(() => {
  attempts += 1;
  if (enhanceHome() || attempts >= 400) clearInterval(timer);
}, 25);

document.addEventListener('visibilitychange', () => {
  if (!document.hidden) enhanceHome();
});
