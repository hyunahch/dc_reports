export const FLOW_DEFINITIONS = [
  {
    id: "closed-guard-attack-chain",
    title: "클로즈드가드 공격 체인",
    description: "상대 반응에 따라 스윕과 서브미션을 바꾸는 Closed Guard 선택 지도",
    positionId: "closed-guard",
    techniqueIds: ["scissor-sweep", "hip-bump-sweep", "guillotine", "kimura", "armbar", "triangle", "omoplata"],
  },
  {
    id: "bottom-side-control-escape-chain",
    title: "바텀 사이드컨트롤 탈출 체인",
    description: "프레임·힙 이스케이프·언더훅을 상대 반응에 맞춰 오가는 탈출 지도",
    positionId: "bottom-side-control",
    techniqueIds: ["side-control-knee-elbow-escape", "side-hip-escape", "side-underhook-reguard"],
  },
  {
    id: "mount-attack-chain",
    title: "마운트 공격 체인",
    description: "Americana 방어 반응을 이용해 Armbar로 이어지는 Mount 공격 선택 지도",
    positionId: "mount",
    techniqueIds: ["americana", "armbar", "kimura"],
  },
  {
    id: "spider-guard-attack-chain",
    title: "스파이더가드 공격 체인",
    description: "Scissor Sweep 방어와 Triangle 팔 숨기기 반응을 이용해 Sweep·Triangle·Omoplata를 잇는 Spider Guard 선택 지도",
    positionId: "spider-guard",
    techniqueIds: ["scissor-sweep", "triangle", "omoplata"],
  },
];

function renderableRouteForPosition(technique, positionId) {
  return (technique?.entryRoutes || []).find(
    route => route.status === "verified" && route.fromPositionId === positionId
  ) || null;
}

function branchIsUsable(branch) {
  return branch?.status === "verified" || branch?.video?.status === "verified";
}

export function buildLearningFlow(definition, techniques) {
  const nodes = [];
  const nodeIds = new Set(definition.techniqueIds);

  for (const techniqueId of definition.techniqueIds) {
    const technique = techniques[techniqueId];
    if (!technique) continue;
    const route = renderableRouteForPosition(technique, definition.positionId);
    if (!route) continue;
    nodes.push({
      techniqueId,
      nameKo: technique.nameKo,
      actionCategory: technique.classification?.actionCategory || null,
      selectedEntryRouteId: route.id,
      routeLabel: route.label,
      routeVideoStatus: route.video?.status || "missing",
    });
  }

  const edges = [];
  for (const node of nodes) {
    const technique = techniques[node.techniqueId];
    const route = renderableRouteForPosition(technique, definition.positionId);
    const candidates = [
      ...(route?.reactionBranches || []).map(branch => ({ scope: "route", branch })),
      ...(technique.core?.reactionBranches || []).map(branch => ({ scope: "core", branch })),
    ];

    for (const { scope, branch } of candidates) {
      if (!branchIsUsable(branch)) continue;
      const toTechniqueId = nodeIds.has(branch.nextTechniqueId) ? branch.nextTechniqueId : null;
      edges.push({
        id: `${node.techniqueId}:${scope}:${branch.id}`,
        fromTechniqueId: node.techniqueId,
        fromEntryRouteId: node.selectedEntryRouteId,
        scope,
        opponentReaction: branch.opponentReaction,
        responseSummary: branch.responseSummary,
        toTechniqueId,
        toEntryRouteId: toTechniqueId ? (branch.nextEntryRouteId || renderableRouteForPosition(techniques[toTechniqueId], definition.positionId)?.id || null) : null,
        outcomePositionId: branch.outcomePositionId || null,
        video: branch.video || null,
        status: branch.status || "partial",
      });
    }
  }

  return {
    ...definition,
    nodes,
    edges,
  };
}

export function buildAllLearningFlows(techniques, definitions = FLOW_DEFINITIONS) {
  return definitions.map(definition => buildLearningFlow(definition, techniques));
}
