export const RENDERABLE_ROUTE_STATUSES = new Set(["verified", "partial"]);

export function getRenderableRoutes(technique, { includeCandidates = false } = {}) {
  const routes = technique?.entryRoutes ?? [];
  if (includeCandidates) return routes.slice();
  return routes.filter((route) => RENDERABLE_ROUTE_STATUSES.has(route.status));
}

export function resolveLegacyTarget(legacyId, redirects) {
  const target = redirects?.[legacyId] ?? redirects?.redirects?.[legacyId];
  if (!target) return null;
  return {
    legacyId,
    techniqueId: target.techniqueId,
    selectedEntryRouteId: target.selectedEntryRouteId ?? null,
  };
}

export function resolveEntryContext(technique, selectedEntryRouteId = null, options = {}) {
  if (!technique) return { mode: "missing-technique", route: null, visibleRoutes: [] };
  const visibleRoutes = getRenderableRoutes(technique, options);
  if (!selectedEntryRouteId) return { mode: "core", route: null, visibleRoutes };
  const route = technique.entryRoutes?.find((item) => item.id === selectedEntryRouteId) ?? null;
  if (!route) return { mode: "invalid-route", route: null, visibleRoutes };
  if (!options.includeCandidates && !RENDERABLE_ROUTE_STATUSES.has(route.status)) {
    return { mode: "non-renderable-route", route, visibleRoutes };
  }
  return { mode: "route", route, visibleRoutes };
}

export function resolvePrimaryLearningVideo(technique, selectedEntryRouteId = null, options = {}) {
  const context = resolveEntryContext(technique, selectedEntryRouteId, options);
  const route = context.route;
  if (context.mode === "route" && route?.video?.status === "verified") {
    return { source: "route", video: route.video, routeId: route.id };
  }
  if (technique?.core?.primaryVideo?.status === "verified") {
    return {
      source: context.mode === "route" ? "core-fallback" : "core",
      video: technique.core.primaryVideo,
      routeId: route?.id ?? null,
    };
  }
  return { source: "missing", video: null, routeId: route?.id ?? null };
}

export function buildPositionIndex(techniques, positionId, options = {}) {
  const items = [];
  for (const technique of Object.values(techniques ?? {})) {
    for (const route of getRenderableRoutes(technique, options)) {
      if (route.fromPositionId !== positionId) continue;
      items.push({
        techniqueId: technique.id,
        selectedEntryRouteId: route.id,
        nameKo: technique.nameKo,
        nameEn: technique.nameEn ?? null,
        actionCategory: technique.classification?.actionCategory ?? null,
        routeLabel: route.label,
        routeStatus: route.status,
      });
    }
  }
  return items.sort((a, b) =>
    String(a.actionCategory).localeCompare(String(b.actionCategory), "ko") ||
    String(a.nameKo).localeCompare(String(b.nameKo), "ko")
  );
}

export function buildDetailState({
  techniques,
  redirects,
  legacyId = null,
  techniqueId = null,
  selectedEntryRouteId = null,
  includeCandidates = false,
}) {
  let resolvedTechniqueId = techniqueId;
  let resolvedRouteId = selectedEntryRouteId;
  let resolvedLegacyId = null;

  if (legacyId) {
    const target = resolveLegacyTarget(legacyId, redirects);
    if (!target) return { status: "missing-legacy-id", legacyId };
    resolvedTechniqueId = target.techniqueId;
    resolvedRouteId = target.selectedEntryRouteId;
    resolvedLegacyId = legacyId;
  }

  const technique = techniques?.[resolvedTechniqueId];
  if (!technique) return { status: "missing-technique", techniqueId: resolvedTechniqueId };

  const context = resolveEntryContext(technique, resolvedRouteId, { includeCandidates });
  const primaryLearningVideo = resolvePrimaryLearningVideo(
    technique, resolvedRouteId, { includeCandidates }
  );

  return {
    status: "ok",
    legacyId: resolvedLegacyId,
    techniqueId: technique.id,
    selectedEntryRouteId: context.mode === "route" ? context.route.id : null,
    contextMode: context.mode,
    technique,
    route: context.route,
    visibleRoutes: context.visibleRoutes,
    primaryLearningVideo,
    showEntryRouteTabs: context.visibleRoutes.length > 1,
  };
}
