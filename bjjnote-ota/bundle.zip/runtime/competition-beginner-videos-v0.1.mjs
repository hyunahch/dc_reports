const BEGINNER_COMPETITION_VIDEOS = [
  {
    id: 'vndl-first-white-belt-comp',
    youtubeId: 'bM83Qw1sMN0',
    title: '초보 4명의 첫 주짓수 대회',
    originalTitle: "A Jiu Jitsu Beginner's FIRST White Belt Competition",
    channel: 'VNDL Jiu-Jitsu',
    duration: '16:07',
    categories: ['first', 'opening', 'operation'],
    badge: '첫 대회 · 여러 경기',
    summary: '한 명의 잘 풀린 경기만 보지 않고 여러 초보자의 첫 대회 흐름과 긴장, 경기 간 차이를 비교하기 좋다.',
    watchPoints: [
      '심판 시작 신호 뒤 첫 10초에 두 선수의 발이 어떻게 움직이는지',
      '계획대로 안 풀릴 때 멈추는지, 다시 자세와 포지션을 정리하는지',
      '첫 공격보다 먼저 안정된 포지션을 만드는 순간이 언제인지',
    ],
    startSeconds: 280,
  },
  {
    id: 'vince-first-gi-commentary',
    youtubeId: 'gK3afHWlVW8',
    title: '화이트벨트 첫 Gi 대회 + 본인 해설',
    originalTitle: 'First White Belt Gi BJJ Tournament (Fuji) + Commentary',
    channel: 'Vince Nerone',
    duration: '14:30',
    categories: ['first', 'operation'],
    badge: '첫 대회 · 해설',
    summary: '경기 영상만 보는 것보다 당사자가 무엇을 느꼈고 어디서 판단이 꼬였는지 함께 들을 수 있어 복기용으로 좋다.',
    watchPoints: [
      '긴장 때문에 평소보다 빨라지거나 힘이 들어가는 구간',
      '좋은 포지션을 얻은 뒤 바로 공격하는지 먼저 고정하는지',
      '경기 후 본인이 어떤 선택을 실수로 짚는지',
    ],
    startSeconds: 0,
  },
  {
    id: 'enoch-first-match',
    youtubeId: 'b0g07etWmAI',
    title: '첫 경기에서 계획이 바로 깨진 사례',
    originalTitle: 'First BJJ Competition - White Belt Match 1',
    channel: 'Enoch Smith Jr',
    duration: '경기 영상',
    categories: ['first', 'opening', 'operation'],
    badge: '화이트벨트 · 첫 경기',
    summary: '초반 테이크다운 시도가 막힌 뒤 계획이 깨지고 바텀에서 대부분의 시간을 보낸 첫 경기라 “다음 판단”을 보는 자료로 좋다.',
    watchPoints: [
      '첫 공격이 실패한 직후 발과 자세가 어떻게 변하는지',
      '불리한 포지션에서 무리하게 뒤집으려 하는지 단계적으로 탈출하는지',
      '점수 차가 작아도 경기 흐름이 얼마나 다르게 느껴지는지',
    ],
    startSeconds: 0,
  },
  {
    id: 'gabriel-five-month-first-comp',
    youtubeId: 'arQ3SZtvLbU',
    title: '5개월 차의 첫 화이트벨트 대회',
    originalTitle: 'FIRST BJJ TOURNAMENT AS A WHITE BELT',
    channel: 'Gabriel Sey',
    duration: '첫 대회 영상',
    categories: ['first', 'opening'],
    badge: '5개월 차 · 첫 대회',
    summary: '오랫동안 수련한 선수보다 입문 초기에 첫 대회를 치르는 사람의 속도와 선택을 비교하기 좋은 사례다.',
    watchPoints: [
      '훈련 롤보다 강한 첫 접촉과 속도에 어떻게 적응하는지',
      '시작 직후 정면에 오래 머무는지 각도를 만들며 움직이는지',
      '좋은 위치를 얻었을 때 베이스를 먼저 만드는지',
    ],
    startSeconds: 0,
  },
];

const FILTERS = [
  ['all', '전체'],
  ['first', '첫 시합'],
  ['opening', '경기 시작'],
  ['operation', '경기 운영'],
];

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>'\"]/g, char => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '\"': '&quot;'
  }[char]));
}

function youtubeWatchUrl(video) {
  const start = Number(video.startSeconds || 0);
  return `https://www.youtube.com/watch?v=${video.youtubeId}${start > 0 ? `&t=${start}s` : ''}`;
}

function youtubeEmbedUrl(video) {
  const params = new URLSearchParams({ playsinline: '1', rel: '0', modestbranding: '1' });
  if (video.startSeconds) params.set('start', String(video.startSeconds));
  return `https://www.youtube.com/embed/${video.youtubeId}?${params}`;
}

function addStyles() {
  if (document.getElementById('beginner-comp-video-style')) return;
  const style = document.createElement('style');
  style.id = 'beginner-comp-video-style';
  style.textContent = `
    .beginnerVideoLibrary{margin:22px 0 4px;padding-top:18px;border-top:1px solid #E5EAEE}
    .beginnerVideoHeader{display:flex;align-items:flex-end;justify-content:space-between;gap:12px;margin-bottom:6px}
    .beginnerVideoHeader h3{margin:0;font-size:16px;letter-spacing:-.03em;color:#1C2B44}
    .beginnerVideoHeader span{font-size:9px;font-weight:800;color:#8498A8}
    .beginnerVideoIntro{margin:0 0 10px;font-size:10px;line-height:1.55;color:#667381}
    .beginnerVideoNotice{margin:0 0 11px;padding:9px 11px;border-radius:12px;background:#F2F5F7;font-size:9px;line-height:1.5;color:#667381}
    .beginnerVideoFilters{display:flex;gap:6px;overflow-x:auto;padding:0 0 9px;scrollbar-width:none}
    .beginnerVideoFilters::-webkit-scrollbar{display:none}
    .beginnerVideoFilter{flex:0 0 auto;border:1px solid #DDE4E9;background:#fff;color:#667381;border-radius:999px;padding:6px 9px;font-size:9px;font-weight:800}
    .beginnerVideoFilter.active{border-color:#1C2B44;background:#1C2B44;color:#fff}
    .beginnerVideoRail{display:flex;gap:10px;overflow-x:auto;margin-right:-20px;padding:0 20px 8px 0;scroll-snap-type:x proximity;scrollbar-width:none;-webkit-overflow-scrolling:touch}
    .beginnerVideoRail::-webkit-scrollbar{display:none}
    .beginnerVideoCard{flex:0 0 272px;scroll-snap-align:start;border:1px solid #E3E8EC;border-radius:17px;background:#fff;overflow:hidden;box-shadow:0 5px 16px rgba(28,43,68,.045)}
    .beginnerVideoCard[hidden]{display:none}
    .beginnerVideoMedia{position:relative;aspect-ratio:16/9;background:#E9EEF2;overflow:hidden}
    .beginnerVideoMedia img,.beginnerVideoMedia iframe{display:block;width:100%;height:100%;border:0;object-fit:cover}
    .beginnerVideoPlay{position:absolute;inset:0;border:0;background:linear-gradient(180deg,transparent 35%,rgba(20,31,43,.42));color:#fff;display:flex;align-items:flex-end;justify-content:flex-start;padding:11px;font-size:10px;font-weight:900;text-align:left}
    .beginnerVideoPlay::before{content:'▶';width:30px;height:30px;border-radius:50%;display:grid;place-items:center;margin-right:8px;background:rgba(28,43,68,.92);font-size:11px}
    .beginnerVideoBody{padding:12px 13px 13px}
    .beginnerVideoBody small{display:block;color:#8498A8;font-size:9px;font-weight:800}
    .beginnerVideoBody h4{margin:4px 0 5px;font-size:13px;line-height:1.4;color:#1C2B44}
    .beginnerVideoBody p{margin:0;font-size:10px;line-height:1.5;color:#667381}
    .beginnerVideoWatch{margin-top:10px;padding-top:9px;border-top:1px solid #E8ECEF}
    .beginnerVideoWatch b{display:block;font-size:9px;color:#1C2B44;margin-bottom:5px}
    .beginnerVideoWatch ul{margin:0;padding-left:16px}
    .beginnerVideoWatch li{font-size:9px;line-height:1.45;color:#667381;margin:2px 0}
    .beginnerVideoMeta{display:flex;justify-content:space-between;gap:8px;align-items:center;margin-top:10px}
    .beginnerVideoMeta span{font-size:8px;color:#8498A8;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    .beginnerVideoMeta a{flex:0 0 auto;font-size:9px;font-weight:800;color:#1C2B44;text-decoration:none}
    .guardPullVideoReference{margin:12px 14px 0;padding:12px;border-radius:14px;border:1px solid #DDE4E9;background:#fff}
    .guardPullVideoReference>small{display:block;font-size:9px;font-weight:800;color:#8498A8}
    .guardPullVideoReference>h4{margin:4px 0 4px;font-size:12px;color:#1C2B44}
    .guardPullVideoReference>p{margin:0 0 9px;font-size:9px;line-height:1.5;color:#667381}
    .guardPullVideoReference .beginnerVideoCard{width:100%;max-width:none;flex:none;box-shadow:none;border-radius:13px}
    .guardPullVideoReference .beginnerVideoBody{padding:10px 11px}
    .guardPullVideoReference .beginnerVideoWatch li:nth-child(n+3){display:none}
    @media(min-width:700px){.beginnerVideoRail{display:grid;grid-template-columns:repeat(2,1fr);overflow:visible;margin-right:0;padding-right:0}.beginnerVideoCard{min-width:0;width:auto}}
  `;
  document.head.appendChild(style);
}

function cardMarkup(video, compact = false) {
  const points = compact ? video.watchPoints.slice(0, 2) : video.watchPoints;
  return `
    <article class="beginnerVideoCard" data-beginner-video-card="${escapeHtml(video.id)}" data-video-categories="${escapeHtml(video.categories.join(' '))}">
      <div class="beginnerVideoMedia" data-beginner-video-media>
        <img src="https://i.ytimg.com/vi/${escapeHtml(video.youtubeId)}/hqdefault.jpg" alt="${escapeHtml(video.title)} YouTube 썸네일" loading="lazy" decoding="async">
        <button class="beginnerVideoPlay" type="button" data-beginner-video-play="${escapeHtml(video.id)}">인앱에서 보기</button>
      </div>
      <div class="beginnerVideoBody">
        <small>${escapeHtml(video.badge)}</small>
        <h4>${escapeHtml(video.title)}</h4>
        ${compact ? '' : `<p>${escapeHtml(video.summary)}</p>`}
        <div class="beginnerVideoWatch"><b>이 영상에서 볼 것</b><ul>${points.map(point => `<li>${escapeHtml(point)}</li>`).join('')}</ul></div>
        <div class="beginnerVideoMeta"><span>${escapeHtml(video.channel)} · ${escapeHtml(video.duration)}</span><a href="${youtubeWatchUrl(video)}" target="_blank" rel="noopener noreferrer">YouTube 열기 ↗</a></div>
      </div>
    </article>`;
}

function libraryMarkup() {
  return `
    <section class="beginnerVideoLibrary" id="beginnerCompetitionVideos" data-beginner-video-library="1">
      <div class="beginnerVideoHeader"><h3>초보자 시합 참고 영상</h3><span>${BEGINNER_COMPETITION_VIDEOS.length}개 엄선</span></div>
      <p class="beginnerVideoIntro">잘하는 선수의 정답을 외우기보다, 첫 대회에서 실제로 속도가 빨라지고 판단이 멈추는 순간을 눈에 익힙니다.</p>
      <div class="beginnerVideoNotice">같은 체급·룰셋을 그대로 따라 하는 자료가 아니라 <b>첫 접촉 · 발 움직임 · 포지션 안정 · 다음 판단</b>을 관찰하는 참고 영상입니다.</div>
      <div class="beginnerVideoFilters">${FILTERS.map(([id, label], index) => `<button type="button" class="beginnerVideoFilter ${index === 0 ? 'active' : ''}" data-beginner-video-filter="${id}">${label}</button>`).join('')}</div>
      <div class="beginnerVideoRail">${BEGINNER_COMPETITION_VIDEOS.map(video => cardMarkup(video)).join('')}</div>
    </section>`;
}

function guardPullReferenceMarkup(video) {
  return `
    <section class="guardPullVideoReference" data-guard-pull-video-reference="1">
      <small>실제 초보 경기로 비교</small>
      <h4>‘옆으로 가기’를 경기 속도에서 다시 보기</h4>
      <p>이 영상에서는 정답 동작 하나를 찾기보다 경기 시작 직후 두 선수의 <b>발이 멈추는지, 골반 위치가 바뀌는지</b>만 비교해서 봅니다.</p>
      ${cardMarkup(video, true)}
    </section>`;
}

function videoById(id) {
  return BEGINNER_COMPETITION_VIDEOS.find(video => video.id === id) || null;
}

function playVideo(button) {
  const video = videoById(button.dataset.beginnerVideoPlay);
  const media = button.closest('[data-beginner-video-media]');
  if (!video || !media || media.querySelector('iframe')) return;
  const iframe = document.createElement('iframe');
  iframe.src = youtubeEmbedUrl(video);
  iframe.title = `${video.title} YouTube 영상`;
  iframe.loading = 'eager';
  iframe.allow = 'accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share';
  iframe.allowFullscreen = true;
  iframe.referrerPolicy = 'strict-origin-when-cross-origin';
  media.replaceChildren(iframe);
}

function filterVideos(button) {
  const library = button.closest('[data-beginner-video-library]');
  if (!library) return;
  const filter = button.dataset.beginnerVideoFilter;
  library.querySelectorAll('[data-beginner-video-filter]').forEach(item => item.classList.toggle('active', item === button));
  library.querySelectorAll('[data-beginner-video-card]').forEach(card => {
    const categories = String(card.dataset.videoCategories || '').split(/\s+/);
    card.hidden = filter !== 'all' && !categories.includes(filter);
  });
  library.querySelector('.beginnerVideoRail')?.scrollTo?.({ left: 0, behavior: 'instant' });
}

function bindEvents() {
  if (document.documentElement.dataset.beginnerVideoEvents === '1') return;
  document.documentElement.dataset.beginnerVideoEvents = '1';
  document.addEventListener('click', event => {
    const play = event.target.closest?.('[data-beginner-video-play]');
    if (play) {
      event.preventDefault();
      playVideo(play);
      return;
    }
    const filter = event.target.closest?.('[data-beginner-video-filter]');
    if (filter) {
      event.preventDefault();
      filterVideos(filter);
    }
  }, true);
}

function enhanceIndex() {
  const index = document.querySelector('#firstCompetitionGuide');
  if (!index) return false;
  if (!index.querySelector('[data-beginner-video-library="1"]')) {
    index.insertAdjacentHTML('beforeend', libraryMarkup());
  }
  return true;
}

function enhanceGuardPull() {
  const learning = document.querySelector('[data-guard-pull-learning="1"]');
  if (!learning) return false;
  if (!learning.querySelector('[data-guard-pull-video-reference="1"]')) {
    const practice = learning.querySelector('.guardPullPractice');
    const html = guardPullReferenceMarkup(BEGINNER_COMPETITION_VIDEOS[0]);
    if (practice) practice.insertAdjacentHTML('beforebegin', html);
    else learning.insertAdjacentHTML('beforeend', html);
  }
  return true;
}

function enhance() {
  addStyles();
  bindEvents();
  const indexMounted = enhanceIndex();
  const guardPullMounted = enhanceGuardPull();
  globalThis.__BJJ_BEGINNER_COMP_VIDEOS__ = {
    version: 'v0.1',
    count: BEGINNER_COMPETITION_VIDEOS.length,
    indexMounted,
    guardPullMounted,
  };
  return indexMounted || guardPullMounted;
}

const observer = new MutationObserver(() => queueMicrotask(enhance));
observer.observe(document.documentElement, { childList: true, subtree: true });
enhance();

export { BEGINNER_COMPETITION_VIDEOS };
