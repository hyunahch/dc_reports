import './recovery-flow-tab.mjs';

const DRILL_URL = new URL('../data/v0.1/drills/solo-movement-drills.v0.1.json', import.meta.url);
const WALL_PROGRESSION_URL = new URL('../data/v0.1/drills/wall-guard-progression.v0.1.json', import.meta.url);

// Recovery V0.3.0's module renderer historically referenced element IDs as
// globals. That is not reliable in module scope, so register the required
// DOM handles explicitly before the parent module starts rendering.
if (typeof document !== 'undefined') {
  for (const id of [
    'techCatalog',
    'drillCatalog',
    'positions',
    'techniques',
    'drillCategories',
    'drills',
    'legacyList',
    'detailRoot',
  ]) {
    const element = document.getElementById(id);
    if (!element) throw new Error(`Missing required recovery DOM element: ${id}`);
    globalThis[id] = element;
  }
}

export async function loadSoloDrills(){
  const [response, progressionResponse] = await Promise.all([
    fetch(DRILL_URL),
    fetch(WALL_PROGRESSION_URL),
  ]);
  if(!response.ok) throw new Error(`Failed to load solo drills: ${response.status}`);
  if(!progressionResponse.ok) throw new Error(`Failed to load wall drill progression: ${progressionResponse.status}`);
  const payload = await response.json();
  const progression = await progressionResponse.json();
  if(!Array.isArray(payload.drills)) throw new Error('Invalid solo drill payload');
  if(!Array.isArray(progression.drills)) throw new Error('Invalid wall drill progression payload');

  const additions = progression.drills.filter(extra => !payload.drills.some(base => base.id === extra.id));
  const wallIndex = payload.drills.findIndex(drill => drill.id === 'wall-inversion-shoulder-roll');
  const insertAt = wallIndex >= 0 ? wallIndex : payload.drills.length;
  payload.drills.splice(insertAt, 0, ...additions);
  return payload;
}

export function groupDrillsByCategory(payload){
  const byId = new Map((payload.categories || []).map(x => [x.id, x]));
  return (payload.drills || []).reduce((acc, drill) => {
    const key = drill.categoryId || 'other';
    if(!acc[key]) acc[key] = { category: byId.get(key) || {id:key,nameKo:key}, drills:[] };
    acc[key].drills.push(drill);
    return acc;
  }, {});
}
