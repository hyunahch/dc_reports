import { FIRST_COMPETITION_GUIDES, getFirstCompetitionGuide } from './first-competition-guide-v0.1.mjs';

const CHECKLIST_STORAGE = 'bjjnote.firstCompetitionChecklist.v1';
const GUIDE_ILLUSTRATIONS = {
  'match-map': './runtime/assets/competition/match-map.webp',
  'first-10-seconds': './runtime/assets/competition/first-10-seconds.webp',
  'score-time-decisions': './runtime/assets/competition/score-time.webp',
  'competition-day-checklist': './runtime/assets/competition/competition-day-checklist.webp',
};

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>'\"]/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '\"': '&quot;' }[char]));
}

function readChecklist() {
  try { return JSON.parse(localStorage.getItem(CHECKLIST_STORAGE)) || {}; } catch { return {}; }
}

function writeChecklist(state) {
  try { localStorage.setItem(CHECKLIST_STORAGE, JSON.stringify(state)); } catch {}
}

function illustrationMarkup(guide, variant = 'detail') {
  const src = GUIDE_ILLUSTRATIONS[guide.id];
  if (!src) return '';
  const alt = `${guide.title} 일러스트`;
  return `<figure class="firstCoachIllustration ${variant === 'index' ? 'isIndex' : ''}"><img src="${src}" alt="${escapeHtml(alt)}" loading="eager" decoding="async"></figure>`;
}

function ensureStyles() {
  if (document.getElementById('first-competition-coach-style')) return;
  const style = document.createElement('style');
  style.id = 'first-competition-coach-style';
  style.textContent = `
    .firstCoachWrap{margin:18px 0 22px}.firstCoachHero{background:#1C2B44;color:#fff;border-radius:18px;padding:16px;margin-bottom:10px}.firstCoachHero small{font-size:9px;font-weight:800;opacity:.65}.firstCoachHero b{display:block;font-size:17px;margin-top:5px}.firstCoachHero p{font-size:11px;line-height:1.55;margin:6px 0 0;opacity:.8}.firstCoachGrid{display:grid;grid-template-columns:1fr 1fr;gap:8px}.firstCoachCard{border:1px solid #E3E8EC;background:#fff;border-radius:15px;padding:12px;text-align:left;color:#1A232D;min-height:112px}.firstCoachCard small{display:block;font-size:9px;color:#8498A8;font-weight:800}.firstCoachCard b{display:block;font-size:13px;line-height:1.35;margin:5px 0}.firstCoachCard p{font-size:10px;line-height:1.45;color:#667381;margin:0}.firstCoachDetail{margin-top:14px}.firstCoachIllustration{margin:0 0 14px;border-radius:18px;overflow:hidden;background:#F4F6F8;border:1px solid #E6EAED;box-shadow:0 8px 24px rgba(27,43,68,.06)}.firstCoachIllustration.isIndex{margin:10px 0 12px}.firstCoachIllustration img{display:block;width:100%;height:auto;aspect-ratio:4/3;object-fit:cover}.firstCoachNotice{background:#F2F5F7;border-radius:14px;padding:12px 14px;font-size:10px;line-height:1.55;color:#667381;margin:10px 0 18px}.firstCoachSection{margin-top:20px}.firstCoachSection h3{font-size:15px;color:#1C2B44;margin:0 0 9px}.firstCoachItems{display:grid;gap:8px}.firstCoachItem{border:1px solid #E3E8EC;border-radius:14px;padding:12px;background:#fff}.firstCoachItem b{display:block;font-size:12px;color:#1A232D}.firstCoachItem em{display:block;font-style:normal;font-size:9px;color:#8498A8;font-weight:800;margin-top:5px}.firstCoachItem p{font-size:11px;line-height:1.55;color:#667381;margin:6px 0 0}.firstCoachAvoid{margin-top:8px;padding-top:8px;border-top:1px solid #E3E8EC;font-size:10px;line-height:1.5;color:#667381}.firstCoachAvoid strong{color:#1C2B44}.firstCoachCheck{display:flex;gap:9px;align-items:flex-start;cursor:pointer}.firstCoachCheck input{width:18px;height:18px;margin:1px 0 0;accent-color:#1C2B44;flex:0 0 auto}.firstCoachCheck span{font-size:11px;line-height:1.55;color:#1A232D}.firstCoachCheck input:checked+span{text-decoration:line-through;color:#8498A8}.firstCoachReset{border:1px solid #E3E8EC;background:#fff;border-radius:999px;padding:7px 10px;font-size:10px;color:#667381;font-weight:700;margin-top:12px}
    @media(max-width:360px){.firstCoachGrid{grid-template-columns:1fr}}
  `;
  document.head.appendChild(style);
}

function guideIndexMarkup() {
  const overview = getFirstCompetitionGuide('match-map');
  return `
    <section class="firstCoachWrap" id="firstCompetitionGuide">
      <div class="firstCoachHero"><small>FIRST COMPETITION MODE</small><b>첫 시합 준비</b><p>기술을 더 외우기 전에 경기 전체 흐름, 포지션 첫 판단, 점수·시간 운영, 경기 당일 준비를 먼저 익힙니다.</p></div>
      ${overview ? illustrationMarkup(overview, 'index') : ''}
      <div class="firstCoachGrid">${FIRST_COMPETITION_GUIDES.map(guide => `
        <button class="firstCoachCard" data-first-guide="${guide.id}">
          <small>${escapeHtml(guide.badge)}</small>
          <b>${escapeHtml(guide.shortTitle || guide.title)}</b>
          <p>${escapeHtml(guide.summary)}</p>
        </button>`).join('')}</div>
    </section>`;
}

function itemMarkup(item, checklist, checked) {
  if (checklist && item.checkKey) {
    return `<div class="firstCoachItem"><label class="firstCoachCheck"><input type="checkbox" data-first-check="${item.checkKey}" ${checked ? 'checked' : ''}><span>${escapeHtml(item.title)}</span></label></div>`;
  }
  return `
    <div class="firstCoachItem">
      <b>${escapeHtml(item.title)}</b>
      ${item.cue ? `<em>${escapeHtml(item.cue)}</em>` : ''}
      ${item.body ? `<p>${escapeHtml(item.body)}</p>` : ''}
      ${item.avoid ? `<div class="firstCoachAvoid"><strong>피할 것</strong> · ${escapeHtml(item.avoid)}</div>` : ''}
    </div>`;
}

function guideDetailMarkup(guide, flavor) {
  const checklistState = readChecklist();
  const backId = flavor === 'mobile' ? 'mobileScenarioBack' : 'scenarioBack';
  const backClass = flavor === 'mobile' ? 'scenarioBack' : 'back';
  return `
    <section class="firstCoachDetail" id="firstCompetitionGuideDetail" data-first-guide-detail="${guide.id}">
      <button class="${backClass}" id="${backId}">← 첫 시합 준비</button>
      <div class="${flavor === 'mobile' ? 'scenarioHero' : 'drillHero'}"><small>${escapeHtml(guide.badge)}</small><p><b>${escapeHtml(guide.title)}</b><br>${escapeHtml(guide.summary)}</p></div>
      ${illustrationMarkup(guide)}
      <div class="firstCoachNotice">${escapeHtml(guide.notice)}</div>
      ${guide.sections.map(section => `
        <div class="firstCoachSection">
          <h3>${escapeHtml(section.title)}</h3>
          <div class="firstCoachItems">${section.items.map(item => itemMarkup(item, Boolean(guide.checklist), Boolean(checklistState[item.checkKey]))).join('')}</div>
        </div>`).join('')}
      ${guide.checklist ? '<button class="firstCoachReset" id="firstCoachReset">체크 초기화</button>' : ''}
    </section>`;
}

function findPanel() {
  const mobile = document.getElementById('flowShell');
  if (mobile) return { panel: mobile, flavor: 'mobile', list: mobile.querySelector('#mobileScenarioList'), switchEl: mobile.querySelector('#mobileFlowModeSwitch') };
  const source = document.getElementById('flowAppPanel');
  if (source) return { panel: source, flavor: 'source', list: source.querySelector('#appScenarioList'), switchEl: source.querySelector('#appFlowModeSwitch') };
  return null;
}

function restoreIndex(panel) {
  panel.querySelector('#firstCompetitionGuideDetail')?.remove();
  panel.querySelectorAll('[data-first-coach-hidden="1"]').forEach(el => {
    el.style.display = el.dataset.firstCoachDisplay || '';
    delete el.dataset.firstCoachHidden;
    delete el.dataset.firstCoachDisplay;
  });
}

function bindChecklist(detail, guide) {
  if (!guide.checklist) return;
  detail.querySelectorAll('[data-first-check]').forEach(input => {
    input.addEventListener('change', () => {
      const state = readChecklist();
      state[input.dataset.firstCheck] = input.checked;
      writeChecklist(state);
    });
  });
  detail.querySelector('#firstCoachReset')?.addEventListener('click', () => {
    writeChecklist({});
    detail.querySelectorAll('[data-first-check]').forEach(input => { input.checked = false; });
  });
}

function openGuide(panel, switchEl, flavor, guideId) {
  const guide = getFirstCompetitionGuide(guideId);
  if (!guide || !switchEl) return;
  restoreIndex(panel);
  [...panel.children].forEach(child => {
    if (child === switchEl || child.contains(switchEl)) return;
    const isHeader = flavor === 'mobile' ? child.classList.contains('shellTitle') && child.previousElementSibling == null : child.tagName === 'H2' && child.previousElementSibling == null;
    if (isHeader) return;
    child.dataset.firstCoachDisplay = child.style.display || '';
    child.dataset.firstCoachHidden = '1';
    child.style.display = 'none';
  });
  switchEl.insertAdjacentHTML('afterend', guideDetailMarkup(guide, flavor));
  const detail = panel.querySelector('#firstCompetitionGuideDetail');
  const backId = flavor === 'mobile' ? '#mobileScenarioBack' : '#scenarioBack';
  detail?.querySelector(backId)?.addEventListener('click', () => {
    restoreIndex(panel);
    window.scrollTo({ top: 0, behavior: 'instant' });
  });
  bindChecklist(detail, guide);
  window.scrollTo({ top: 0, behavior: 'instant' });
}

function enhance() {
  ensureStyles();
  const found = findPanel();
  if (!found?.panel || !found.list || !found.switchEl) return false;
  if (!found.panel.querySelector('#firstCompetitionGuide')) {
    const wrapper = document.createElement('div');
    wrapper.innerHTML = guideIndexMarkup().trim();
    const node = wrapper.firstElementChild;
    if (found.flavor === 'mobile') {
      const heading = found.list.previousElementSibling;
      found.panel.insertBefore(node, heading || found.list);
    } else {
      const section = found.list.closest('.section');
      found.panel.insertBefore(node, section || found.list);
    }
  }
  found.panel.querySelectorAll('[data-first-guide]').forEach(button => {
    if (button.dataset.firstGuideBound === '1') return;
    button.dataset.firstGuideBound = '1';
    button.addEventListener('click', () => openGuide(found.panel, found.switchEl, found.flavor, button.dataset.firstGuide));
  });
  globalThis.__BJJ_FIRST_COMPETITION_COACH__ = { version: 'v0.2', guides: FIRST_COMPETITION_GUIDES.length, illustrations: Object.keys(GUIDE_ILLUSTRATIONS).length };
  return true;
}

const observer = new MutationObserver(() => enhance());
let attempts = 0;
let observedPanel = null;
const timer = setInterval(() => {
  attempts += 1;
  const found = findPanel();
  if (found?.panel && found.panel !== observedPanel) {
    observer.disconnect();
    observer.observe(found.panel, { childList: true, subtree: true });
    observedPanel = found.panel;
  }
  if (enhance()) {
    clearInterval(timer);
  } else if (attempts >= 2400) {
    clearInterval(timer);
  }
}, 25);
