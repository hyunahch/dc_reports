const MEDIUM_BRAID_STEP_SVG = 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 180 145" role="img" aria-label="중간 길이 머리를 좌우 두피 가까이에서 두 줄로 브레이드하는 뒷모습">
  <rect width="180" height="145" rx="12" fill="#F7F8FA"/>
  <path d="M40 145c3-22 18-34 39-37h22c21 3 36 15 39 37" fill="#FFFFFF" stroke="#8498A8" stroke-width="2"/>
  <path d="M78 101v18c5 4 19 4 24 0v-18" fill="#EAC4A7" stroke="#A97E61" stroke-width="1.4"/>
  <ellipse cx="90" cy="61" rx="38" ry="45" fill="#EAC4A7"/>
  <path d="M51 65c0-34 16-53 39-53 24 0 40 19 40 53 0 15-6 28-13 36-5-17-8-34-10-55-9 6-25 9-44 7-1 19-4 35-9 48-2-7-3-18-3-36Z" fill="#302B2B" stroke="#1C2B44" stroke-width="2"/>
  <path d="M90 18v72" stroke="#8498A8" stroke-width="1.5" stroke-dasharray="4 4"/>
  <path d="M67 38c-5 9-7 18-6 28 1 12 4 23 8 35" fill="none" stroke="#1C2B44" stroke-width="8" stroke-linecap="round"/>
  <path d="M113 38c5 9 7 18 6 28-1 12-4 23-8 35" fill="none" stroke="#1C2B44" stroke-width="8" stroke-linecap="round"/>
  <g fill="#514747" stroke="#1C2B44" stroke-width="1">
    <ellipse cx="65" cy="45" rx="8" ry="5" transform="rotate(-30 65 45)"/><ellipse cx="64" cy="57" rx="8" ry="5" transform="rotate(25 64 57)"/><ellipse cx="64" cy="70" rx="8" ry="5" transform="rotate(-28 64 70)"/><ellipse cx="66" cy="83" rx="8" ry="5" transform="rotate(25 66 83)"/><ellipse cx="69" cy="96" rx="7" ry="5" transform="rotate(-25 69 96)"/>
    <ellipse cx="115" cy="45" rx="8" ry="5" transform="rotate(30 115 45)"/><ellipse cx="116" cy="57" rx="8" ry="5" transform="rotate(-25 116 57)"/><ellipse cx="116" cy="70" rx="8" ry="5" transform="rotate(28 116 70)"/><ellipse cx="114" cy="83" rx="8" ry="5" transform="rotate(-25 114 83)"/><ellipse cx="111" cy="96" rx="7" ry="5" transform="rotate(25 111 96)"/>
  </g>
  <path d="M44 52c8-8 13-12 20-14M136 52c-8-8-13-12-20-14" fill="none" stroke="#40556A" stroke-width="2" stroke-linecap="round"/>
  <path d="M44 52l7-1-2-6M136 52l-7-1 2-6" fill="none" stroke="#40556A" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>`);

export const TRAINING_GUIDES = [
  {
    id: 'hair-control',
    category: 'mat-ready',
    eyebrow: 'HAIR GUIDE · PILOT',
    title: '매트에서 머리 정리하기',
    summary: '머리 길이에 맞는 묶는 법을 골라 얼굴·목 주변의 방해를 줄이고, 롤링 전에 단단한 집게나 핀은 빼는 2분 준비 가이드입니다.',
    duration: '약 2분',
    tags: ['짧은 머리 우선', '집게핀 없이', '롤링 준비'],
    principles: [
      '한 번에 세게 묶기보다 짧은 앞·옆 가닥을 먼저 작은 구역으로 잡고 뒤에서 합칩니다.',
      '라이브 롤링 전에는 실핀·금속 핀·단단한 집게처럼 눌리거나 빠질 수 있는 부품을 제거합니다.',
      '매번 같은 위치를 과하게 당기지 말고 묶는 위치와 장력을 조금씩 바꿉니다.',
      '머리가 풀려 눈·입을 가리거나 매트에 깔리면 라운드 사이에 바로 다시 정리합니다.',
    ],
    options: [
      {
        id: 'short-layered',
        label: '짧은·애매한 길이',
        range: '낮은 포니테일이 짧거나 목선 가닥이 빠지는 길이',
        badge: '지금 먼저 해보기',
        method: '2단 분할 포니',
        why: '짧은 층을 한 번에 잡으려 하지 않고 앞·옆을 먼저 고정하면 한 개 포니테일보다 풀리는 지점을 줄일 수 있습니다.',
        illustrations: [
          { src: './runtime/assets/guides/hair/short-01.webp', alt: '짧은 머리 2단 분할 포니 1단계: 앞머리와 옆머리를 나누는 모습' },
          { src: './runtime/assets/guides/hair/short-02.webp', alt: '짧은 머리 2단 분할 포니 2단계: 윗부분을 작은 포니테일로 묶는 모습' },
          { src: './runtime/assets/guides/hair/short-03.webp', alt: '짧은 머리 2단 분할 포니 3단계: 아래 머리를 위쪽 포니와 합치는 모습' },
          { src: './runtime/assets/guides/hair/short-04.webp', alt: '짧은 머리 2단 분할 포니 4단계: 낮은 포니테일 완성 모습' },
        ],
        steps: [
          '관자놀이부터 윗머리까지 얼굴로 떨어지는 부분을 좌우 2~3구역으로 나눕니다.',
          '각 구역을 부드러운 고무줄로 뒤쪽에 작게 묶어 앞머리와 옆머리를 먼저 잡습니다.',
          '뒤까지 닿는 윗부분은 낮은 포니테일에 합치고, 목선의 아주 짧은 가닥은 억지로 핀으로 고정하지 않습니다.',
          '자유롤 전 손으로 머리 전체를 훑어 단단한 플라스틱·금속 부품이 남지 않았는지 확인합니다.',
        ],
        fallback: '분할 묶기가 번거로운 날은 양쪽 미니 포니 또는 하프업으로 얼굴 쪽 가닥만 먼저 잡고, 풀리면 라운드 사이에 다시 묶습니다.',
      },
      {
        id: 'shoulder',
        label: '턱선~어깨 아래',
        range: '한 번 묶이지만 층이 자주 빠지는 길이',
        badge: '안정성 우선',
        method: '양쪽 브레이드 또는 2단 포니',
        why: '두 갈래로 나누면 짧은 층이 빠져나오는 양이 줄고, 뒤통수 중앙에 큰 묶음 하나가 눌리는 것도 피하기 쉽습니다.',
        illustrations: [
          { src: './runtime/assets/guides/hair/medium-01.webp', alt: '중간 길이 머리 1단계: 머리를 좌우로 나누는 모습' },
          { src: MEDIUM_BRAID_STEP_SVG, alt: '중간 길이 머리 2단계: 좌우 두피 가까이에서 두 줄 브레이드를 시작한 뒷모습' },
          { src: './runtime/assets/guides/hair/medium-03.webp', alt: '중간 길이 머리 3단계: 양쪽 브레이드를 뒤로 모으는 모습' },
          { src: './runtime/assets/guides/hair/medium-04.webp', alt: '중간 길이 머리 4단계: 낮은 위치에서 함께 묶은 모습' },
        ],
        steps: [
          '가르마를 크게 두 갈래로 나눠 좌우 길이를 비슷하게 맞춥니다.',
          '가능하면 두 줄 프렌치·더치 브레이드로 두피 가까이 잡고, 어렵다면 좌우 2단 포니로 대신합니다.',
          '끝이 남으면 작은 부드러운 고무줄로 한 번 더 묶어 손가락에 걸리는 긴 꼬리를 줄입니다.',
          '라운드 사이에 느슨해진 부분만 다시 조이고 처음부터 과하게 당기지 않습니다.',
        ],
        fallback: '브레이드가 아직 어렵다면 매트 밖에서 1~2분 연습하고 수업에서는 2단 포니부터 사용합니다.',
      },
      {
        id: 'long',
        label: '어깨 아래 긴 머리',
        range: '한 갈래 브레이드가 충분히 만들어지는 길이',
        badge: '브레이드 추천',
        method: '낮은 1~2줄 브레이드',
        why: '길이를 한 덩어리로 묶어 두면 손가락·팔꿈치·매트에 넓게 깔리는 면적을 줄이고, 높은 번처럼 뒤통수에 큰 돌출점이 생기는 것도 피할 수 있습니다.',
        illustrations: [
          { src: './runtime/assets/guides/hair/long-01.webp', alt: '긴 머리 낮은 브레이드 1단계: 목덜미 아래로 머리를 모으는 모습' },
          { src: './runtime/assets/guides/hair/long-02.webp', alt: '긴 머리 낮은 브레이드 2단계: 낮은 포니테일로 묶는 모습' },
          { src: './runtime/assets/guides/hair/long-03.webp', alt: '긴 머리 낮은 브레이드 3단계: 세 가닥 브레이드를 만드는 모습' },
          { src: './runtime/assets/guides/hair/long-04.webp', alt: '긴 머리 낮은 브레이드 4단계: 끝까지 정리해 완성한 모습' },
        ],
        steps: [
          '얼굴 주변 짧은 가닥까지 포함하도록 두피 가까이에서 낮게 묶거나 브레이드를 시작합니다.',
          '가능하면 한 줄보다 두 줄로 나눠 좌우 장력을 분산합니다.',
          '끝을 부드러운 고무줄로 고정하고 너무 긴 꼬리는 한 번 접어 작은 고무줄로 다시 잡습니다.',
          '머리가 매트에 깔렸거나 상대 팔 아래 끼면 움직임을 강행하지 말고 안전하게 빼낸 뒤 계속합니다.',
        ],
        fallback: '높은 번은 빠르게 만들기 쉽지만 눕거나 헤드 포지션을 잡을 때 돌출점이 될 수 있어 기본 추천에서는 제외합니다.',
      },
    ],
    equipment: {
      recommended: ['부드러운 무금속 헤어 고무줄 3~5개', '예비 고무줄 1~2개'],
      offMatOnly: ['플랫/유연 집게핀', '일반 집게핀'],
      avoidOnMat: ['실핀·U핀', '금속 장식 고무줄', '단단한 플라스틱 집게'],
    },
    competitionNote: '대회에서는 주최 단체와 도장의 장비·복장 안내가 우선입니다. 이 가이드는 특정 대회 규정을 대신하는 문서가 아니라 매트 위 안전과 방해 최소화를 위한 개인 수련 가이드입니다.',
  },
];

export function getTrainingGuide(id) {
  return TRAINING_GUIDES.find((guide) => guide.id === id) || null;
}
