function ensureStyles() {
  if (document.getElementById('guard-pull-learning-style')) return;
  const style = document.createElement('style');
  style.id = 'guard-pull-learning-style';
  style.textContent = `
    .guardPullLearning{margin:14px 0 22px;border:1px solid #DDE4E9;border-radius:18px;background:#fff;overflow:hidden;box-shadow:0 8px 24px rgba(28,43,68,.05)}
    .guardPullHead{padding:15px 16px 13px;background:#F2F5F7}
    .guardPullHead small{display:block;font-size:9px;font-weight:800;letter-spacing:.04em;color:#8498A8}
    .guardPullHead b{display:block;margin-top:4px;font-size:16px;line-height:1.35;color:#1C2B44}
    .guardPullHead p{margin:6px 0 0;font-size:11px;line-height:1.55;color:#667381}
    .guardPullCue{margin:12px 14px 0;padding:12px 13px;border-radius:13px;background:#1C2B44;color:#fff}
    .guardPullCue span{display:block;font-size:9px;font-weight:800;opacity:.62}
    .guardPullCue strong{display:block;margin-top:3px;font-size:14px;line-height:1.4}
    .guardPullWhy{margin:10px 14px 0;padding:10px 12px;border-left:3px solid #8498A8;background:#F7F8FA;border-radius:0 11px 11px 0;font-size:10px;line-height:1.55;color:#667381}
    .guardPullWhy strong{color:#1C2B44}
    .guardPullSteps{display:grid;gap:8px;padding:12px 14px 0}
    .guardPullStep{display:grid;grid-template-columns:26px 1fr;gap:9px;align-items:start;padding:10px 11px;border:1px solid #E3E8EC;border-radius:13px}
    .guardPullNum{width:26px;height:26px;border-radius:8px;background:#1C2B44;color:#fff;display:grid;place-items:center;font-size:10px;font-weight:800}
    .guardPullStep b{display:block;font-size:12px;color:#1A232D}
    .guardPullStep p{margin:3px 0 0;font-size:10px;line-height:1.5;color:#667381}
    .guardPullBoundary{margin:12px 14px 0;padding:11px 12px;border-radius:13px;background:#F2F5F7;font-size:10px;line-height:1.55;color:#667381}
    .guardPullBoundary b{color:#1C2B44}
    .guardPullPractice{padding:14px}
    .guardPullPractice h4{margin:0 0 8px;font-size:12px;color:#1C2B44}
    .guardPullPractice p{margin:0;font-size:10px;line-height:1.55;color:#667381}
    .guardPullChecks{display:flex;gap:6px;flex-wrap:wrap;margin-top:9px}
    .guardPullChecks span{padding:5px 7px;border-radius:999px;background:#F2F5F7;font-size:9px;font-weight:700;color:#667381}
  `;
  document.head.appendChild(style);
}

function markup() {
  return `
    <section class="guardPullLearning" data-guard-pull-learning="1">
      <div class="guardPullHead">
        <small>시작 10초 · 가드 풀 대응</small>
        <b>상대가 시작과 동시에 클로즈드가드로 묶으려 할 때</b>
        <p>가드가 닫히기 전에는 기술 이름보다 먼저 상대 다리 사이 정면에서 벗어나는 발 움직임을 실행한다.</p>
      </div>
      <div class="guardPullCue"><span>실전 큐</span><strong>발 먼저 → 골반 따라 → 가슴 압박</strong></div>
      <div class="guardPullWhy"><strong>‘옆으로 가’는 결과 설명.</strong> 상체만 옆으로 기울이는 게 아니라 실제로 바깥발이 먼저 움직이고 반대발이 따라와야 내 골반이 상대 정면에서 빠진다.</div>
      <div class="guardPullSteps">
        <div class="guardPullStep"><div class="guardPullNum">1</div><div><b>상대가 앉는 순간을 본다</b><p>엉덩이가 떨어지고 다리가 내 허리 쪽으로 올라오면 가드 풀이 시작된 것이다.</p></div></div>
        <div class="guardPullStep"><div class="guardPullNum">2</div><div><b>골반을 뒤로 빼고 다리를 한쪽으로 치운다</b><p>다리가 바로 허리 뒤에서 잠기지 않게 공간을 만들고, 내가 지나갈 쪽의 무릎·다리 라인을 정리한다.</p></div></div>
        <div class="guardPullStep"><div class="guardPullNum">3</div><div><b>바깥발 한 걸음 → 뒷발 따라오기</b><p>지나갈 방향의 발을 상대 무릎 바깥으로 먼저 보내고 반대발이 따라오며 베이스를 다시 만든다.</p></div></div>
        <div class="guardPullStep"><div class="guardPullNum">4</div><div><b>정면을 벗어난 즉시 상체 압박</b><p>내 골반이 상대 다리 사이 정면을 벗어나면 다시 가드를 만들기 전에 가슴·상체 컨트롤로 탑을 안정시킨다.</p></div></div>
      </div>
      <div class="guardPullBoundary"><b>이미 상대 발목이 내 허리 뒤에서 잠겼다면?</b><br>이 대응의 타이밍은 끝났다. 옆으로 억지로 뛰지 말고 ‘상대 클로즈드가드 안’의 포스처 → 가드 오픈 단계로 전환한다.</div>
      <div class="guardPullPractice">
        <h4>훈련에서 한 가지만 확인</h4>
        <p>상대가 천천히 가드 풀을 하면 좌우로 반복한다. 패스 완성보다 <b>상대가 앉는 순간 두 발이 멈추지 않는가</b>를 먼저 체크한다.</p>
        <div class="guardPullChecks"><span>골반 뒤</span><span>다리 치우기</span><span>첫발</span><span>뒷발 따라오기</span><span>압박 연결</span></div>
      </div>
    </section>`;
}

function enhance() {
  ensureStyles();
  const detail = document.querySelector('#firstCompetitionGuideDetail[data-first-guide-detail="first-10-seconds"]');
  if (!detail) return false;
  if (detail.querySelector('[data-guard-pull-learning="1"]')) return true;
  const notice = detail.querySelector('.firstCoachNotice');
  if (!notice) return false;
  notice.insertAdjacentHTML('afterend', markup());
  globalThis.__BJJ_GUARD_PULL_LEARNING__ = { version: 'v0.1', mounted: true };
  return true;
}

const observer = new MutationObserver(() => enhance());
observer.observe(document.documentElement, { childList: true, subtree: true });
enhance();
