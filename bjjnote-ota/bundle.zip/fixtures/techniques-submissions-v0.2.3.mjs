const missingVideo = () => ({ status: "missing", youtubeId: null, title: null, channel: null, watchFor: [] });
const video = (youtubeId, title, channel = null) => ({ status: "verified", youtubeId, title, channel, watchFor: [] });
const route = (id, label, fromPositionId, status, routeVideo = missingVideo()) => ({
  id, label, fromPositionId, fromTechniqueId: null, status, video: routeVideo,
  learning: null, steps: [], reactionBranches: []
});
const technique = (id, nameKo, coreVideo, entryRoutes) => ({
  id, nameKo, nameEn: null,
  classification: { actionCategory: "submission" },
  learning: { coreIdentity: "Runtime regression fixture; full Core learning data stays in canonical migrated artifacts." },
  core: { primaryVideo: coreVideo, steps: [], reactionBranches: [] },
  entryRoutes
});

export const SUBMISSION_TECHNIQUES = {
  armbar: technique("armbar", "암바", missingVideo(), [
    route("from-closed-guard", "클로즈드가드", "closed-guard", "partial", video("XUrxSihViJI", "Closed Guard Armbar")),
    route("from-mount", "마운트에서", "mount", "partial", missingVideo())
  ]),
  omoplata: technique("omoplata", "오모플라타", video("Lk4mv2p1mz8", "How To Do The 2 Most Basic Omoplata Variations In BJJ", "Ritchie Yip"), [
    route("from-closed-guard", "클로즈드가드", "closed-guard", "partial", video("Lk4mv2p1mz8", "How To Do The 2 Most Basic Omoplata Variations In BJJ", "Ritchie Yip")),
    route("from-spider-guard", "스파이더가드에서", "spider-guard", "candidate", missingVideo()),
    { ...route("from-triangle-transition", "트라이앵글 전환에서", null, "candidate", missingVideo()), fromTechniqueId: "triangle" }
  ]),
  triangle: technique("triangle", "트라이앵글 초크", missingVideo(), [
    route("from-closed-guard", "클로즈드가드", "closed-guard", "partial", video("3r7xjdswykI", "Closed Guard Triangle"))
  ]),
  kimura: technique("kimura", "기무라", missingVideo(), [
    route("from-closed-guard", "클로즈드가드", "closed-guard", "partial", video("ZLsg4M0lHzA", "Closed Guard Kimura"))
  ])
};
