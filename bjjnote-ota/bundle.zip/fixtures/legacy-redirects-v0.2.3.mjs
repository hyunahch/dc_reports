export const REDIRECTS = {
  armbar: { techniqueId: "armbar", selectedEntryRouteId: "from-closed-guard" },
  omoplata: { techniqueId: "omoplata", selectedEntryRouteId: "from-closed-guard" },
  triangle: { techniqueId: "triangle", selectedEntryRouteId: "from-closed-guard" },
  kimura: { techniqueId: "kimura", selectedEntryRouteId: "from-closed-guard" },
  scissor: { techniqueId: "scissor-sweep", selectedEntryRouteId: "from-closed-guard" },
  hipbump: { techniqueId: "hip-bump-sweep", selectedEntryRouteId: "from-closed-guard" },
  "knee-cut": { techniqueId: "knee-cut-pass", selectedEntryRouteId: "from-top-half-guard" },
  sideescape: { techniqueId: "side-control-knee-elbow-escape", selectedEntryRouteId: "from-bottom-side-control" },
  "side-frame-knee-recovery": { techniqueId: "side-control-knee-elbow-escape", selectedEntryRouteId: "from-bottom-side-control" },
  "side-hip-escape": { techniqueId: "side-hip-escape", selectedEntryRouteId: "from-bottom-side-control" },
  "side-underhook-reguard": { techniqueId: "side-underhook-reguard", selectedEntryRouteId: "from-bottom-side-control" }
};

export const MIGRATION_STATUS = {
  armbar: { migrationStatus: "complete_fixture", unresolvedLegacyFields: [] },
  omoplata: { migrationStatus: "complete_fixture", unresolvedLegacyFields: [] },
  triangle: { migrationStatus: "complete_fixture", unresolvedLegacyFields: [] },
  kimura: { migrationStatus: "complete_fixture", unresolvedLegacyFields: [] },
  "scissor-sweep": { migrationStatus: "partial_recovery", unresolvedLegacyFields: ["motion", "steps", "variations", "followUps", "mistakes"] },
  "hip-bump-sweep": { migrationStatus: "base_only", unresolvedLegacyFields: ["motion", "steps", "mistakes", "reactionBranches"] },
  "knee-cut-pass": { migrationStatus: "base_only", unresolvedLegacyFields: ["motion", "steps", "mistakes", "reactionBranches"] },
  "side-control-knee-elbow-escape": { migrationStatus: "partial_recovery", unresolvedLegacyFields: ["motion"] },
  "side-hip-escape": { migrationStatus: "partial_recovery", unresolvedLegacyFields: ["motion"] },
  "side-underhook-reguard": { migrationStatus: "partial_recovery", unresolvedLegacyFields: ["motion"] }
};
