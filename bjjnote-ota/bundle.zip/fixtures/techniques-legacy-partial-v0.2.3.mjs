const missingVideo = () => ({ status: "missing", youtubeId: null, title: null, channel: null, watchFor: [] });
const route = (id, label, fromPositionId) => ({
  id, label, fromPositionId, fromTechniqueId: null, status: "partial", video: missingVideo(),
  learning: null, steps: [], reactionBranches: []
});
const technique = (id, nameKo, actionCategory, entryRoute) => ({
  id, nameKo, nameEn: null,
  classification: { actionCategory },
  learning: { coreIdentity: "Runtime regression fixture; full Core learning data stays in canonical migrated artifacts." },
  core: { primaryVideo: missingVideo(), steps: [], reactionBranches: [] },
  entryRoutes: [entryRoute]
});

export const PARTIAL_TECHNIQUES = {
  "scissor-sweep": technique(
    "scissor-sweep", "시저 스윕", "sweep",
    route("from-closed-guard", "클로즈드가드", "closed-guard")
  ),
  "side-control-knee-elbow-escape": technique(
    "side-control-knee-elbow-escape", "프레임 → 니 프레임 → 가드 리커버리", "escape",
    route("from-bottom-side-control", "바텀 사이드컨트롤", "bottom-side-control")
  ),
  "side-hip-escape": technique(
    "side-hip-escape", "프레임 + 힙 이스케이프", "escape",
    route("from-bottom-side-control", "바텀 사이드컨트롤", "bottom-side-control")
  ),
  "side-underhook-reguard": technique(
    "side-underhook-reguard", "언더훅 → 옆으로 돌아 가드 복귀", "escape",
    route("from-bottom-side-control", "바텀 사이드컨트롤", "bottom-side-control")
  )
};
